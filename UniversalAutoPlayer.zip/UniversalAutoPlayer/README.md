# Universal AutoPlayer (ZirexHub build) v2.16.2

An Android app that plays games for you. It takes a screenshot of whatever is on screen, decides
what to do, taps or swipes, and repeats. A small floating PLAY/STOP chip sits on top of any game.

## Two brains

| Brain | Needs | What it does |
|---|---|---|
| **AI player** | Internet + a key from any supported AI provider | Sends each screenshot (plus your rules, your last actions, and whether the screen changed) to a vision AI. It works out the game, returns 1 to 6 actions, and adapts when something does not work. |
| **Offline bot** (default) | Nothing | Reads the screen text on the phone (ML Kit OCR), presses Continue / Play / Next / Claim, closes pop-ups and X buttons, waits on loading screens, avoids buy / ad / login buttons and picks an option on level-up / reward pop-ups. When no button applies it **works out how the game is played** (see below) and plays that way. **Chess:** since v2.15 it plays a chess game by itself when PLAY is pressed at the start of the game (see v2.15). |

## Install problems ("There was a problem parsing the package" / "App not installed")

1. GitHub gives the build as a ZIP called `UniversalAutoPlayer-debug-apk`. The phone cannot install a zip. Extract it
   (Files app: tap the zip, Extract) and install the `app-debug.apk` inside. Never rename the zip to `.apk`.
2. Download again. A cut-off download gives exactly this error. The file `app-debug.apk` should be about 15 MB or more.
3. The phone needs Android 11 or newer (the screenshot function of an accessibility service starts at Android 11).
   Older phones say "problem parsing the package".
4. Open the run in the GitHub Actions tab: it must be green (a red cross has no new APK, the old one may be expired).
5. "App not installed" / "conflicts with an existing package": the installed copy was signed with a different key.
   From this build on every build uses the same fixed debug key (`app/debug-signing.p12`), so updates install over
   each other. If the installed copy came from an OLDER build, uninstall it ONCE, then install this one.
6. Uninstalling removes the accessibility permission: switch the service on again in Settings > Accessibility.

## What is new in v2.16.2 (chess.com: "it still has a problem finding the board"; the service turning itself off)

**Found by testing on the real chess.com screenshot from the log (first time the real board was visible):**
the board finder saw a regular lattice of squares and extended it upward over the coach's white speech
bubble (the bot's own chip is painted dark grey over part of that bubble, and the cells it hides count as
"probably board"). It reported **8x9** instead of **8x8**, so chess-only mode said "no chess board on screen"
on a screen that had a perfect board. Reproduced exactly (`Grid 8x9 x 0-99% y 24-75%` as in the log).

- **Checkerboard check (`ChessBoardFit`)**: a chess board's squares alternate light and dark. For every 8x8
  window inside what the finder returned (and the neighbours of an exact 8x8) the bot measures that from the
  four corners of each square (where pieces, the coordinate letters and highlights do not reach) and keeps
  the window that is clearly the best checkerboard. Squares under the chip are skipped, and when two windows
  look alike the one with more measured squares wins. Tested on the real screenshot with the chip dragged to
  146 positions and with other things above/below the board (one or no bubble, a light player bar above, below,
  both, a grey bar): right in every position where the chip does not sit on the board.
- **Direct checkerboard search**: in chess-only mode, when the lattice finder still gives no 8x8 board (a chip or a
  bubble spoiled its lines), the bot looks for the 8x8 checkerboard directly (any size from 55 % of the screen width
  to full width, any position; ~50 ms on a PC, at most once per 1.4 s). It must score high, and then ChessAuto still has to read a
  plausible chess position before anything is tapped.
- **Opening book**: a move that only one odd line plays (e.g. 1.d4 g6 2.h4) is no longer picked when better supported moves exist.
- **Better "no board" diagnostics**: the log now says what the finder saw (`The board finder saw: Grid 8x9 ...`), and
  logs `board finder saw ...: the real chess board ... is ...` when the checkerboard check corrected it.

**The service "turning itself off"** (repeated `service connected` in the log, no crash line, chip gone each time):
- the floating chip is **brought back by itself** when Android restarts the service (a memory kill, a crash, the accessibility switch). It
  stays gone only when you close it with the **X** on the chip.
- on every (re)start the log lists **why the earlier process ended** (`earlier process ended at ...: LOW_MEMORY / FREEZER /
  USER_REQUESTED / CRASH ...`, Android 11+). If it happens again this tells us whether the phone's battery manager killed the app.
- On vivo/OriginOS also: Settings > Battery > Background power consumption management > Universal AutoPlayer > Allow
  high background power consumption; Auto-start on; lock the app in the recent apps list (pull the card down / lock icon).

## What is new in v2.16.1 (chess.com: "it keeps bugging out", a board detector that plays the board only)

**What the log showed.** On chess.com the bot never saw a chess board. The text reader found only the phone's own bars
(`11:17`, `100%`, the back arrow at the bottom), nothing from the chess.com screen, and the screenshot did not change at all
(`change=0.0`). With no board the chess brain handed the screen to the offline "learn any game" bot, which then pushed a joystick,
tapped, long-pressed and swiped at random on a screen it did not understand. That is what "bugging out" was.

**What changed:**

1. **"Chess only" mode.** In this mode the other bot NEVER gets the screen: with no board, or a board it cannot follow yet, the
   bot waits and touches nothing (no taps, no joystick, no swipes). The only things it presses are the move on the board, the
   promotion piece, and the button of a "game over" box. It switches on by itself when a chess app is in front (the app's name has
   "chess" in it: chess.com, lichess ...), and there is a switch for it on the main screen ("Chess only") for any other chess app.
   The debug log says `app in front: com.chess` and `chess only: true` when PLAY is pressed.
2. **A log that shows what the bot receives** when it cannot find the board: the size and brightness of the screenshot (a black
   screenshot is reported as such: an app that blocks screenshots gives the bot a black picture), the text the reader finds, and
   a small picture of the screen made of digits (`screen-map` lines, 0 = black, 9 = white), so a board that is not found can be
   understood from the log. When a board IS found but the game cannot be followed, the log now says why (for example "the closest
   starting position differs in 9 squares", or "white and black pieces are not told apart by brightness").

**Honest limits.** The log only had the bars' text, so the reason the chess.com screen was empty is not known yet. If the next
log says "the screenshot of the app is blank", chess.com is blocking screenshots (a secure window), and then no screenshot bot
can read it: use another chess app (lichess works with screenshots) or play on the website in a browser. The game has to be at the
starting position (or 1-2 moves in) when PLAY is pressed.

## What is new in v2.16 (chess: "improve its accuracy: every move perfect, different openings, adapts to the opponent, plans")

**What the log showed.** The v2.15.2 log has about 450 steps of real chess. The bot read the board and followed the game
perfectly, but the app's engine is stronger than the old offline brain: the evaluation slid from -50 to -1795 (the bot
shuffled rooks without a plan) and it was mated. Then a "game over" box covered the board and the bot idled until you stopped it.

**"Perfect" does not exist in chess** (not even Stockfish never loses), so this build makes the bot much stronger and
measures it instead of guessing. Measured on a PC against real Stockfish 19 (the same bot at 0.6 s a move, Stockfish at 0.1 s a move):

| opponent | result |
|---|---|
| old v2.15 brain, same 0.6 s a move | the new brain won 10 of 10 games |
| Stockfish limited to about 2200 Elo | the new brain won 5, lost 1 of 6 |
| Stockfish limited to about 2800 Elo | the new brain drew 2, won 0, lost 4 of 6 |

These are PC numbers with very short Stockfish moves, not a rating. How fast your phone thinks is not measured; the bot thinks by
the clock (about 3.5 s a move at most), so a slower phone just searches fewer moves.

**What changed:**

1. **A new chess engine** (`Chess.kt` rules, `ChessEngine.kt` search). Faster rules code with incremental hashing (about
   570,000 positions a second on a PC with a much richer evaluation than before, the old engine did 330,000), and a real search: transposition table, null-move pruning, late-move reductions, futility pruning, check extensions,
   killer / history / counter-move ordering, static exchange (it does not give a queen for a pawn), a quiescence search, aspiration
   windows, a time manager (it thinks longer when the position is hard or the evaluation just dropped, and stops early when the
   move is obvious). Depth 12-18 in 1-2 s on a PC instead of 5-6.
2. **A better evaluation:** piece squares for the middle game and the ending, bishop pair, pawn structure (doubled, isolated,
   passed, connected), knight outposts, mobility, rooks on open files and on the 7th rank, king shelter and king attackers,
   "mop-up" so won endings are finished instead of shuffled, drawn material (K+N vs K ...) recognised.
3. **A different opening every game:** an opening book of about 2,900 real opening lines (6,000 moves; the free lichess
   `chess-openings` list, CC0), every line checked by Stockfish so it contains no losing gambits. Moves are chosen at random,
   weighted by how common they are, for both colours. It is looked up by position, so transpositions work. When the opponent
   leaves the book the engine takes over.
4. **It plans and adapts:** it searches the real position on the board after every opponent move, so it adapts to whatever was
   played. While the opponent is thinking it keeps searching the position after its own move ("pondering"), so the next search
   starts with the replies it already looked at (measured: depth 15 instead of 13 in the same time). It remembers the positions
   of the game, so it does not repeat a position when it is better, and accepts a draw when it is clearly worse
   (a draw is worth more or less to it depending on its last evaluation).
5. **Game over is noticed:** when the picture stops fitting for 5 s (a box over the board), or nothing happens for 25 s, the
   bot reads the text on the screen. If it says "game over / checkmate / you win / you lose / draw ...", it forgets the old game and
   presses "new game" / "play again" / "rematch" / "restart" / "ok" (in that order of preference). The text it read is written to the
   debug log, so if your app uses another word it can be added from the next log.
6. **A bug found by the tests:** if the floating chip sits on a square of the move being played, a one-square difference
   made the bot decide the move had failed. It now waits for the chip to move away.

**Honest limits.** Tested on a PC only (a simulated board and real Stockfish): the real app's game-over box, the real speed of
your phone, and pondering next to the screen capture are only known from your next log. If a move takes too long on your phone, lower
`ENGINE_MS` in `ChessAuto.kt`.

## What is new in v2.15.2 (chess: "it still didn't choose a piece when promoting")

**What the log showed (good and bad).** The v2.15.1 log has about 260 steps of real chess on your phone: the bot read the board,
followed the game, played depth 5-6 moves in 0.4-1.8 s, and never pressed RESTART. At `f7f8q` the promotion box opened and hid
the board from the board finder (`no board found`, 12 squares differ). The bot tried 4 times: the target square twice (no
effect: the queen is not listed on the target in your app), and "the first icon of the box" twice at `0.50,0.25`, a point ABOVE
the board. The text reader found no "Queen" word. After about 20 s you chose the piece by hand and the bot went on by itself
(`our move f7f8q is on the board`), so the game state was kept correctly the whole time.

**Why the box press missed:** v2.15.1 looked for the first row and first column that "had something in them" inside the box.
A box with a title and a border makes every row and column look busy, so the point it computed was the middle of the box's
top, not an icon.

**What changed:**

1. **The box is now read as separate objects.** `PromoPopup.icons` finds the pieces of the box that are NEW on the screen, keeps
   only the ones about the size of a board square (titles, borders and buttons are the wrong shape and are skipped), cuts apart
   icons that touch, and lists them in reading order (top row first, left to right).
2. **It presses the icons one by one**, never the same place twice in a round: queen text (if the screen has one), then icon 1,
   icon 2, icon 3 and so on. Any piece ends the box, because the board looks the same whichever piece is chosen, so a stuck box
   is better than nothing. Up to 8 tries, 1.4 s apart.
3. **The last board position is kept** while a box hides the board for up to 30 s, so the attempts go on (before, the tries
   stopped when the board finder's memory ran out).
4. **The log says what it saw**, so the next fix does not need guessing: `offline chess: promotion, text on the screen: ...`,
   `offline chess: promotion, box x .. y .. , icons: ...` and `pressing the queen by icon N/M at x,y`.

**Tested on a PC:** the box finder on 8 drawn layouts: column on the board, row in a dialog, dimmed screen with a 2x2 grid, tall
dialog, a dialog with border + title + 4 icons + a Cancel button (icons found in order, title and button skipped), icons that
touch, and "a plain piece move is not a box". The whole 27 suites pass.

**Not proven:** it has still never seen your app's real box. If it still does not choose, send the log lines
`offline chess: promotion, ...` and a screenshot of the box.

**Known side effect:** if the app ends up making a knight, rook or bishop instead of a queen, the bot still thinks it is a queen.
The picture looks the same, so it cannot tell; its next moves of that piece may be refused by the app, and it then picks another
move (a refused move is never repeated).

## What is new in v2.15.1 (chess: "when it tried to promote a pawn it bugged out and tried to restart the game")

**The cause (found from your old logs, not from a new one).** Your chess app has a RESTART button on the board screen (the screen
text of every earlier log shows `RESTART  PIECES  UNDO  HINT`). In v2.15, when a promotion choice box opened, the picture of the
board no longer fitted the game. After four looks (about 2 seconds) the chess brain gave up the game and handed the screen to
the old offline bot, and the old offline bot presses buttons like RESTART.

**What changed:**

1. **The old offline bot never gets a live board in the middle of a game (Offline mode).** If the picture cannot be read, or
   the board is hidden by a box, an ad or a toast, the bot waits and touches NOTHING. The old bot only gets the screen back when
   the game is over by the rules (mate / stalemate: so it can press "New game"), or after a long time without progress.
2. **It is patient.** A picture that does not fit is waited out for 40 seconds (it used to be 4 looks). When the board is
   readable again it simply goes on in the same game. Only after 40 seconds does it forget the game; then it waits for a new
   start position (up to 45 s) before the old bot may act.
3. **Promotion: it picks the queen, three ways, each tried once, at most 4 tries, 1.4 s apart:**
   - presses the target square (lichess / chess.com style apps list the queen there; it also finishes a move that only selected
     the pawn),
   - reads the screen text and presses a button that says "Queen" (also Dame, Reina, Regina, Dama, Donna, Rainha, Königin),
   - compares the screen before the move with the screen now, finds the box that opened (`PromoPopup`) and presses its FIRST
     icon (nearly every app lists the queen first). It only presses inside that box.
   A promotion whose box changed too little to be noticed is handled the same way.
4. In AI mode nothing changed for the other brain: after a lost game the AI reads the board as before.

**Tested on a PC:** a promotion box that appears over the target file, a dialog the target square does not help with (the bot
tries at most 4 times, plays nothing else, keeps the game, and goes on when the box is gone), a popup over the whole board for
10 s (kept) and for a minute (given up), and the box finder on 4 drawn layouts (column on the board, row in a dialog, 2x2 in a
dimmed screen, tall dialog) plus the "not a popup" cases.

**Not proven:** it has never seen your app's real promotion box. If the queen is still not chosen, send the log: the lines
`offline chess: promotion, pressing the queen by ...` say which way was tried and where it pressed. A screenshot of the box
helps most.

## What is new in v2.15 (chess with NO AI: "install all the chess moves into the offline bot")

**What was asked.** Can the offline bot know all the chess moves and play by itself? The rules and a search engine already
existed since v2.14 (the AI only had to READ the board). What the offline bot was missing was the eyes. Now it has them.

**How it works** (`ChessBrain`, `ChessAuto`, `Chess`; the same in Offline mode and in AI mode):

1. Every step the bot looks for an 8x8 board (the existing grid finder). If there is none, nothing changes: the offline bot or
   the AI plays as before.
2. **Learning from the first moments of a game.** From the picture of the starting position (or the starting position after
   one or two moves, which is what you see when you press PLAY a moment after the opponent opened) it learns by itself: how
   much of a square a piece covers (so it can tell a piece from an empty square or a little "you can go here" dot), how bright
   white pieces are against black ones, which colour is at the bottom (that is the colour it plays), and the colours of the
   two kinds of squares. It accepts the picture only if exactly ONE position within two moves of the start explains all 64
   squares.
3. **It follows the game with the rules instead of recognising piece shapes.** After every opponent move the bot looks for the
   ONE legal move that explains what changed on the board (piece / no piece, white / black). So it always knows exactly which
   piece is which, castling and en passant are exact, and a promotion is no problem. If two moves would look the same, or none
   fits, it does not guess: it looks again, and after four looks it forgets the game.
4. **It chooses the move with the built-in engine** (search with captures, checks, piece-square tables, 1.8 s at most) and
   presses two squares (or one when the piece is already selected).
5. **It checks every move on the screen.** A move that did not happen (the app only selected the piece, an illegal tap, a slow
   app) is judged only after the same picture was seen twice a moment apart, is never chosen again in that position, and the
   next best move is played. A piece that stayed selected costs one tap, not two.
6. **Game over** (nobody can move) hands the screen back to the other brain (so it can press "New game"), and the moment the
   starting position is on the screen again a new game is followed.
7. **Pawn promotion:** if the app asks what to promote to and the board does not look finished, the bot presses the target
   square once or twice more (most apps show the queen there). This is a guess about the app, see below.
8. The bot's own chip is moved off the board if it covers squares; squares under it are not judged meanwhile.

**Tested on a PC** with a pretend chess app that draws a board with pieces, move highlights, selected-piece tint and move dots,
plus noise: full games as white and as black (24 of our moves each, never lost, never stalled), a start with the opponent's
first move already played, an app that ignores a tap, a still-moving screen, covered squares, a popup over the board, a new game
in the middle, a board cut one pixel off, the whole path from the grid finder to the move, mate in one, and a promotion popup.

**What is NOT proven (please read):**

- It was never run on a phone and never saw a real chess app's picture. The tests use drawn discs as pieces. Real piece
  pictures, wood textures, coordinates around the board, highlight colours and animations can break a rule I assumed.
  When it cannot read a board it says nothing is wrong: it simply does not take over, and the old behaviour stays.
- It can only start a game when PLAY is pressed at the start of the game (or within the first two moves). A game that is
  already in progress cannot be joined in Offline mode, because the bot has never seen how the pieces differ. (AI mode
  still joins it: the AI reads the position, as in v2.14.)
- Boards with a very low contrast between a white piece and a light square can make a piece look like an empty square.
- The promotion handling is a guess; apps that use a different popup need the AI mode or a tap by hand.
- The engine is a small one (it searches for at most 1.8 s per move, so how deep it sees depends on the phone). It plays
  sensible chess, it is not a grandmaster.

**If it does not move:** press PLAY at the very start of a game, then send the debug log. The lines that start with
`offline chess:` or `chess:` say exactly what it saw ("the game was learned (we play black ...)", "the picture fits neither our
move nor any reply (N squares differ)" and so on).

## What is new in v2.14 (chess: "the more it moves, the slower it gets, until it stops")

**What the v2.13 debug log showed.** The one-move bug was gone (four moves in a row were detected as played). Then three things
piled up:

1. **The AI model was overloaded.** `gemini-3.5-flash-lite` answered `HTTP 503: This model is currently experiencing high demand`
   nine times in one run. Every failed call took 3 to 5 seconds, and after each one the app waited longer (2 s, 4 s, 6 s). One
   chess move took 22 seconds that way, so the game slowed down until it looked stopped.
2. **The AI misread the board and chose bad moves.** It said "capture the black pawn on f5" and gave the cell of f4, called the
   knight on e5 "a knight on e4", and tried to move a bishop straight forward. 5 of the 10 moves in the log failed.
3. **The bot's own chip sat over the top row of the board**, so the AI never saw black's back rank.

**What changed**

* **Automatic fallback when a model is overloaded** (`ModelPool`). On the first 503 (or 500/502/504) the app asks the account once
  which other models it can use (one cheap request, no generation quota), then asks the next best model AT ONCE, with no waiting.
  Order: other versions of the same family, then the other Gemini flash tiers (never Pro). The model you chose rests for 90 s,
  then 3 min, 6 min, at most 10 min while it keeps failing, and is tried again after that. The debug log says
  `model X is overloaded ...: asking Y at once`. Your chosen model in the settings is never changed.
* **A built-in chess engine picks the moves; the AI only reads the board** (`Chess.kt`, `BoardPlan.kt`). A vision AI reads a
  board well and plays chess badly. On an 8x8 board the AI now also returns `"fen"` (the pieces exactly as drawn on the screen, top
  row first, no flipping) and the engine chooses the move: legal by construction, takes free material, finds mates, looks about 5-6
  moves ahead in under 2 seconds. The move generator passes the standard perft counts (millions of positions, including
  castling, en passant and promotion). You play the colour at the bottom of the screen. Promotions are made to a queen.
* **The reading is never trusted blindly.** It must be a possible chess position (one king each, at most 8 pawns, no pawn on the
  first or last row, opponent not in check on our turn), it is compared with the picture (which squares hold a piece, squares
  under the chip are skipped), the side at the bottom is decided from where the white pieces stand (not from what the AI claims),
  and a move that already failed on the screen is never chosen again. If the reading is refused, the debug log says why
  (`chess engine not used: ...`) and the AI's own move is played as before.
* **Positions are not repeated:** a move into a position already played to costs the engine a little, so it does not shuffle.
* **A selected piece needs one tap.** After a move that only selected a piece, the next move from that same piece is one tap on
  the target (a second tap on the piece would un-select it).
* **The move check handles trades.** After a trade the opponent often takes back at once on the target square (it looks the same
  before and after) or even moves into the square the piece just left. The check now looks at the start square being empty,
  or the same piece picture standing on the target.
* **The chip moves off the board by itself.** When it covers part of a board, it is moved just above or below the board (or into
  a corner) before the AI is asked, so every square is visible. Look for `moved the chip off the board` in the debug log.
* **More log:** the debug log now lists the first 60 gestures (it was 12, so later taps looked as if nothing was pressed), the
  model that is answering, and the engine's choice with its score, depth and time.

**Tested on a PC, not on your phone.** New suites: `TestChess` (perft + tactics + self-play legality), `TestBoardPlan` (cells for white
or black at the bottom, refused readings, failed-move exclusion, one-tap rule), `TestBoardTracker`, `TestModelPool`, and
`TestChessLoop` (a pretend chess app that only moves pieces on taps, a pretend AI reading its board, with 0% and 25% reading
mistakes: 8 of 8 clean games had every move happen, noisy games 117 of 120). All 25 suites pass. NOT tested: the real app, the real
Gemini replies (does the AI return a correct `fen`?), and the phone's speed (the engine is limited to 1.8 s per move).
If a game still goes wrong, the debug lines `chess engine: ...` / `chess engine not used: ...` / `board move check: ...` say which part.

**Tip:** if chess moves are still weak or the AI misreads often, pick a bigger model in the app (for example `gemini-3.5-flash`
instead of the lite one). The engine plays the moves, so the model only has to read the board.

## What is new in v2.13 (chess: "only moved a piece one time")

**What the v2.12 debug log showed:** the first move (`cell(5,7) ; cell(5,5)`, two taps) was played. After that the AI dragged
pieces (`drag_cell`) and nothing moved: the screen changed by exactly the same `0.0025314032` as when only a piece had been
SELECTED. The app counted that selection as "the move worked", so the AI believed the pawn stood on e4 and kept answering with
the same moves. Two more things were wrong: the bot's own chip (painted dark grey over the picture, top row of the board) made
the board finder see **8x7** instead of 8x8 on some questions, and the AI was never told which moves were already played.

**What changed**

* **Pieces are moved by two taps, never by a drag.** `drag_cell` (and a swipe between two cells) is played as: tap the piece,
  tap the target. That is what moved the pawn in your app. If two moves in a row by taps do nothing and taps never worked, the
  app switches to real drags (and back after two failed drags). A way that worked once is never given up.
* **A move is checked on the board, not by "did the screen change".** `BoardCheck` compares the picture before and after on the
  two squares: after a real move the START square is empty (flat or just tinted as "last move") and the target changed;
  after a mere selection the piece still stands on the start square (only a highlight and dots were added). Result:
  MOVED / SELECTED_ONLY / NOTHING. The check runs after the opponent had time to answer.
* **Move log for the AI.** "Moves already played: your move from col 5,row 7 (e2 if white is at the bottom) to ... was played".
  A move that did not happen is reported ("the piece on e2 was only selected, it did NOT move to e4") and the same move is not
  allowed a third time (the offline bot plays instead). One move per reply: a second move in the same reply is cut.
* **The board finder ignores the bot's own chip.** The chip's zone is told to the finder: lines hidden under it are not counted
  as missing, so a chess board with the chip over its top row is still 8x8 (tested 29 of 30 chip positions). The cell numbers
  no longer change between questions: a board that is missed once is remembered while the screen stays the same, and a board of
  another shape (8x7 after 8x8) must be seen twice in a row to replace it.
* **The AI is told about the chip** when it covers the board (never press it, the cells under it still exist) and that dragging
  often only selects a piece.
* **A little thinking on boards only.** Chess is decided by the quality of the move, so on a board screen the model gets
  thinking level "low" (minimal everywhere else, so menus and action games stay fast). 2.5 models get a budget of 512 on boards.
  The debug log now shows the level and how pieces are moved: `thinking level low, moves by taps`.

**What is tested on a PC and what is not.** Tested: the move check on synthetic boards (real move, selection with dots,
capture, opponent moving elsewhere, noisy pictures 40 of 40), the tracker (move log, blocked repeats, switching taps/drag, board
memory), the parser and the requests, plus all older suites. NOT tested: your real chess app. The move check was tuned on drawn
boards, so a chess theme with very unusual highlights could fool it; if it does, the debug log line `board move check: ...`
says what it saw.

## What is new in v2.12 (chess works, but "think and move way too slow")

**What the v2.11 debug log showed:** the chess fix worked (`board found: Grid 8x8`, `cell(5,7) ; cell(5,5)` moved the pawn,
then Nc3 and Bc4 were dragged in). But every AI call took 11 to 13 seconds, a plain "wait" answer took 3.6 s, and after each
move the next question went out 1.8 s later, before the opponent had answered, so the AI could only say "wait for black".

**What changed**

* **The model's thinking is turned down.** Gemini 3.x models think before they answer (Flash defaults to medium or high), which
  is what made a move take 12 s. The request now carries `generationConfig.thinkingConfig.thinkingLevel = "minimal"`. A model
  that does not know the setting answers 400 and the app steps down by itself (minimal, then low, then no setting) and
  remembers it, so a wrong guess costs one call, once. Pro models start at "low" (they have no "minimal"), 2.5 models use
  `thinkingBudget = 0`, other providers get nothing. Trade-off: with less thinking the AI plays weaker chess. It is much faster.
* **No question before the opponent has answered.** After the AI's move in a slow game the next question waits until 2.5 s have
  passed and the screen has been still for two steps (or 6 s at most). That removes the wasted "wait for black" call every
  move, so it is faster AND uses half as many of the free key's daily calls. Real-time games are never held back.
* **The log shows the setting:** every `AI asked (...)` line now says `model <name>, thinking <level>`, and a refused setting
  is logged (`the model refused the thinking setting ...`).

Tests: `TestRequests` (the thinking JSON for each model family, no setting for other providers), `TestCopilot` (the chess
timeline: the question now goes out after black's reply, a press that did nothing is asked about after about 2.5 s, an animated
screen is held back for 6 s at most, real-time popups are never held back). All 19 suites pass.
**Not tried on a real phone yet:** how much faster it really is depends on the model and the network. The debug log will show
`took ...ms` for each answer, send it if it is still slow. The quickest further step is the model: a Flash-Lite model is the
fastest one in the list.

## What is new in v2.11 (chess: "it made one move, said pawn to e4, then nothing happened")

**What the debug log showed** (it was from build 2.9.2, so check that the app now says 2.11 on its main screen)

* The AI answered `x=567` for a picture only 461 px wide. The old parser silently cut that to the right screen edge, so the
  tap landed beside the board and the pawn never moved. It also gave pixels in the wrong scale (Gemini's own scale for
  positions in pictures is 0 to 1000) and was a few squares off even when the numbers fit.
* It could not tell that the pawn had already moved, so every call planned "move the e2 pawn" again.
* A real chess move changes the screen by only 0.0025 (two small pieces out of a whole screen). The "did my press do
  anything?" check called everything below 0.01 a failure.
* The offline bot, which stands by while the AI thinks, could poke at RESTART / UNDO / HINT between the AI's moves.

**What changed**

* **Coordinates.** Gemini is asked for a 0 to 1000 scale (independent of the picture size); other providers for pixels, and
  the OCR word positions in the message use the same scale. A reply is checked as a whole: if the numbers only fit the other
  scale, the reply is read on that one; a point that fits neither is an error, **never a tap on the screen edge**.
* **Board finder (`GridFinder`).** The screenshot is searched for a board of equal cells (evenly repeated lines: chess,
  checkers, sudoku, tic-tac-toe, match-3, ...). When one is found the AI is told "8 columns x 8 rows, covering x..y.." and can
  press `tap_cell` (col, row) or `drag_cell` (col, row, col2, row2); the app computes the exact centre of the cell, so no
  pixel guessing is left. For 8x8 boards the message also explains chess squares (white at the bottom: e2 = col 5, row 7)
  and the flipped board. The debug log shows `board found: Grid 8x8 ...`.
* **The AI is told the screen is NOW.** Describe what you see first; a move planned earlier may already be done; play one move
  per turn; if the opponent is moving or it is not your turn, answer `wait`; think about the position (no free pieces, take
  free material, checks and mates).
* **A real move counts as an effect.** The "press did nothing" limit is now 0.001 (a frozen screen is exactly 0.000). A move
  is judged as a pair of presses (piece, then target), and a drag is reported too when it did nothing.
* **The offline bot stays out of board games** while the AI thinks (a board was seen in the last 25 s): it waits instead of
  tapping RESTART / UNDO / HINT.
* **Shorter answers.** The AI is asked for at most 15 words of observation and 20 of plan: fewer words come back faster.

Tests: `TestGrid` (board finder: 39 of 40 chess boards with pieces and labels, 39 of 40 checkers, 39 of 40 tic-tac-toe, 30 of
30 sudoku, 30 of 30 match-3 boards with the cell centres within 0.3 cell; **0 false boards on 103 real frames of the Hell
Survivor video**, none on menus or three cards in a row) and `TestParser` (the exact chess-log reply, both scales, out-of-range
points, cells, drags, prompts). All 18 suites pass.
**Not tried on a real phone yet:** the board finder was built and measured on made-up boards and on the one real video; a
real chess app (other piece art, a board that touches the screen edge, animated backgrounds) may be found less often. If it
is not found the AI still works as before, only with the new coordinate scale. Send the debug log again if a move still
does nothing: it says which cell was pressed and where.

## What is new in v2.10 (AI mode: it got stuck on a button, then ran at 1.4 s per step)

**What was wrong with AI mode (v2.9.2 and before)**

* Every call to the AI blocked the whole bot for 2 to 5 seconds. Steps took about 1.4 s instead of 0.6 s, and by the time the
  answer arrived the game had moved on.
* The AI guessed button positions from the picture. Vision models are often 5 to 10 percent off, so its "click the button"
  missed, did nothing, and the AI tried the same thing again (the "stuck on a button for steps 3 to 8"). Measured in the new
  test: with a typical pointing error of +-5 % / +-7 %, only 19 % of the AI's presses landed on the button it meant, and 16 %
  landed on the wrong one ("SIGN IN BLOOD" instead of "Walk away").
* A free key allows 5 to 10 calls a minute, so asking at every step could never work anyway.

**What changed**

* **The AI runs in the background.** The bot never waits for the network. In a simulated minute the old loop made 15 steps,
  the new one 93 (the offline bot plays the steps in between).
* **The AI is asked where it helps.**
  * *Slow or not yet recognised screens* (menus, puzzles, idle games, the first seconds of a new game): the AI **leads**,
    whenever a call is allowed. While it thinks about a still screen the bot waits.
  * *Real-time games the offline bot already plays* (joystick / drag games): the AI is a **copilot**. It is asked when a
    popup with choices appears (it picks the upgrade card with reasons) and when the bot has been stuck for a while. The
    offline bot keeps doing the moving and fighting, because no AI call is fast enough for that.
* **Exact positions.** The screenshot goes to the AI together with the list of words the on-device OCR found, each with its
  exact pixel centre, and the AI names the words of the button it wants. The app moves the press onto those words
  (`Snap`): the word whose text matches, or else the button-like word nearest to the point. In the test, 400 of 400 snapped
  presses landed on the named button.
* **Old answers are dropped.** An answer is used only if the area around its press point still looks like it did when the
  question was asked (the same check the app makes right before every press), otherwise it is thrown away.
* **No repeating a press that did nothing.** The AI is told which of its presses had no effect and is not allowed to repeat
  one that failed twice (the offline bot plays instead).
* **The offline bot always looks first** and keeps learning, so the AI never starts from nothing.

In the debug log look for: `AI asked (...)`, `AI answer used after ...ms`, `AI answer dropped ...`,
`AI press had no effect`, `AI limit (...)`. The status line shows `[AI standby: ...]` while the offline bot plays.

Tests: `TestCopilot` (snapping, when to ask, hold / drop / rate-limit / timeout / wrong-key behaviour of the state machine, the
pointing-error simulation, the steps-per-minute simulation). All 16 suites pass. The real network calls to Google could not be
run here, so this is not yet tried on the phone.

## What is new in v2.9.2 (AI mode with a free Google AI Studio key kept failing)

**Cause.** A free AI Studio key has small call limits, and they differ a lot per model (Google's own rate-limit page, checked
November 2026): `gemini-3.8-flash` (the old default) 5 calls per minute and **20 per day**; `gemini-3.6-flash` the same;
`gemini-3.5-flash-lite` and `gemini-3.1-flash-lite` 10 per minute and **500 per day**. The bot made a call every second or two,
so the day was gone in under a minute and every later call came back "429 RESOURCE_EXHAUSTED". The old loop then only
waited and failed again. (Limits change; the current numbers are at aistudio.google.com/rate-limit.)

**What changed**

* The default Gemini model is now `gemini-3.5-flash-lite`. A saved `gemini-3.8-flash` is moved to it once (typing 3.8 again
  afterwards is respected, for a paid key).
* **AI + offline bot together.** The AI plays when the provider allows a call; between calls, and whenever the provider is
  busy or an answer cannot be read, the offline bot plays that step. The game never stands still, and the status line says
  `AI paused (next AI call in 9s). Offline bot: ...`.
* **A call guard that learns the limit.** The first "too many calls" answer is read (the wait the provider asks for, the
  number of calls per minute): from then on calls are spaced to fit, for example 5 per minute = one call per 13 s. A
  per-day limit, or "limit: 0" (no free quota for this model), ends AI calls for the run; the offline bot plays on. Press
  STOP and PLAY later (Google's day starts at midnight Pacific time, about 4 PM in Manila now) to use the AI again.
* **Plain-English errors.** Key not valid, key restricted, location not supported, quota used up, server busy: the test dialog
  and the log say what it means and what to do.
* **Connection test now sends a picture** (the bot always does), so it also proves the model accepts images, with one call.
* **Pasted keys are cleaned:** spaces, line breaks, quotes and a leading `key=` are removed before use.
* Gemini replies are asked to be JSON (fewer unreadable answers).

Tips for a free key: use a Flash-Lite model, set "actions per call" to 4-6 so one call carries several moves, and expect the
offline bot to do most of the playing. A paid key (billing on in AI Studio) has no such limits and is not slowed down.

Tests: `TestAi` (call-limit parsing from Google-style 429 replies, the guard, key cleaning, hints; a free-tier simulation of
10 minutes at one step per 1.5 s: 69 AI calls, 3 refusals while it learns, 531 steps played by the offline bot). All 15 suites
pass. The network side (real calls to Google) could not be run here, so it is not yet tried on the phone.

## What is new in v2.9.1 (found in the debug log of build 2.9 on a vivo V2556: "it got stuck")

The log showed the character standing still for about 20 seconds while the bot tapped the word RESCUE at the left edge of
the screen, with taps growing into bursts of 12. Three things played together:

* **Objective markers were taken for buttons.** The Inferno map shows "TREASURE 2,730 m" on the left, "RESCUE 2,669 m" on
  the right and, later, a bare "RESCUE" label that slides along the left edge. None is a button. They are now recognised
  (a number followed by a distance unit, even clipped or garbled like "pz m" or "RESCUE2692-m"; the words treasure /
  rescue / objective / waypoint at the left or right edge, also cut short like "TREA" or "RES") and are never pressed.
  A card in the middle of a popup that happens to be called "Treasure Hunter" is not caught. The debug log says which
  words were taken for HUD: `HUD text, never pressed: "treasure 2 730 m" at 16%,46%`.
* **The bot stayed in "popup mode" for ever.** A level-up popup switches it on (many words in the middle of the screen). It
  switched off only when fewer than 3 words were left, and the HUD itself now had 3 (TREASURE, RESCUE, RESCUE 2,669 m),
  so it never ended, and in popup mode every line of text is a candidate. Now the HUD words are not counted, popup mode
  also ends when the number of words falls back near the normal count, and it ends the moment our own joystick drag moves
  the picture. The debug log prints `popup mode ON / OFF`.
* **Text-reading noise counted as "the button worked".** Reading the same words twice can give a slightly different word
  set, which looked like a new screen, which counted as a real effect, which grew the burst. A new screen now needs a
  picture that really changed (a different word set with a still picture is noise). Choices picked from a popup that
  achieve nothing twice are skipped for a while (before: three times).
* **It learns the HUD of any game.** Text that stays at the same place on three readings in a row while the bot's own
  joystick is moving the picture is HUD of that game and is not pressed. Popup cards are never learned (they are seen
  once while the world moves, then the picture freezes), and words like Continue / Close are never judged HUD.

Tests: a new suite (`LogStuck`) replays the exact text lines of that log (clipped HUD labels among the level-up cards, the
bare RESCUE label, the contract at the start), and plays a closed-loop copy of that game with 9 seeds (3 of them with extra
HUD words the bot has never heard of). On build 2.9 the same test shows 18 to 33 taps on the HUD labels and only 52 to 76
percent of the steps spent moving; on 2.9.1 there are no taps on HUD text and 75 to 88 percent of the steps move (the
rest are the first looks at a new game and single exploring taps). All 14 suites pass. Not yet tried on the phone.

## What is new in v2.9 (swarms and the 3 minute mark)

Build 2.8 did well but did not survive getting swarmed. The old way of running away only looked at "where did the picture
move" in 9 big sectors, which on a real phone recording is mostly noise (measured: a standing or slowly moving character
shows 14 to 16 grey levels of difference even after the best slide is removed), and between pushes the heading was a
random walk that happily turned back into the crowd. Now the bot scans the screen and plans:

* **It finds the enemies by colour.** On the real Inferno map the imps are tiny crimson sprites (about RGB 140,40,48).
  Embers, lava and fire are orange (blue below green) and are not counted; crimson specks on or at the edge of lava are
  lava texture and are dropped; the bot's own chip and the character itself are ignored. On 30 real frames it finds
  about 6 enemies per frame (worst 21), none on the chip and none on lava.
* **It reads the health from the bar under the character.** The bright red fill is measured every step (no reading of tiny
  text any more). Checked on the real video against the numbers the game prints on the bar: 137/140 reads 100%, 90 reads
  67%, 87 reads 58%, 77 reads 58%, 29 reads 19%. A drop of 4 points or more counts as "hurt" and makes the bot run harder.
* **It plans the survivable gap.** For 16 headings it looks where the character would be after a short and a long walk
  and adds up how close the enemies would be there, counting where they will be by then (they walk toward us). Lava and
  thorn walls add a large penalty, turning a lot costs a little so the path stays smooth, and the present heading is
  kept when it is nearly as good (no zig-zag). The cheapest heading wins: away from a crowd, through the gap of a ring,
  along a wall instead of into it. With low health the enemies count 40% more.
* **When it is quiet it collects gems.** Bright green diamonds (experience) within half a screen are walked to when
  the way is clear and no crowd sits on them. More experience = more level-ups = a stronger build.
* **You can see it.** The chip shows `[enemies: running away]`, and the debug log gets `KITE` lines (what it saw and where
  it ran), `HURT (health bar)` lines, and every 12 steps `threats: enemies=N gems=N hpbar=...`.

Tested (PC): a closed-loop swarm simulation with the real planner. The bot sees the swarm through a noisy scanner (25%
of the enemies missed, position jitter, 15 random false enemies per step). Enemies speed up and more spawn every second.
Easy swarm (enemies slower than the hero): blind wandering 116 s on average, 0 of 24 runs reach 3 minutes; with the
scanner 24 of 24 runs reach the 240 s cap. Hard swarm (many more enemies, almost as fast as the hero): blind 96 s, scanner
231 s, 24 of 24 reach 3 minutes. Brutal swarm (enemies faster than the hero, nobody can outrun them): blind 67 s, scanner
96 s. With perfect detection the numbers are the same as with the noisy scanner, so the limit there is the swarm itself.

Honest limits: the swarm simulation is MY model of a swarm (enemies walk straight at the character), not the real game,
and no real frame of a 2 to 3 minute swarm was available, so the real crowd size and enemy types of the late game are
untested. Only crimson enemies are recognised; ranged attackers, bosses or bats of another colour are not seen (the bot
then falls back to the older "where did things move" guess and the health-drop reaction). The planner does not pick
upgrades by itself, it only moves. If it still dies in a swarm, record the screen from the 2 minute mark and copy the debug
log: the `KITE` and `threats:` lines say what it saw.

## What is new in v2.8 (found by measuring the video of build 2.7)

Build 2.7 played well but died to lava and kept walking into the thorn walls at the side of the map. Measured frame by
frame (the lava patch's position on screen shows the camera movement): the character drifted slowly toward a lava river,
walked onto it, and stood in it for about 2 seconds while damage ticks (-5, -6) ran, until it died. Nothing in the bot
knew that lava is bad.

* **Lava is seen and avoided.** Every step the bot now looks at the colours of the screenshot (a 96 px wide copy). Big
  areas of dark orange / red-brown (measured on the real map: RGB about 111,43,20) are lava. Small orange things (fire
  balls, the character's own glowing ring, weapon flames) are ignored because only big connected areas count, and
  yellow damage numbers and green gems are not lava colour. For 16 headings it works out how soon a walk that way hits
  lava. If the heading the strategy wanted points at lava, it is bent to the nearest clear heading (sliding along the
  edge, not turning right round). If the character already stands in lava it takes the shortest way out.
* **Thorn / spike walls are seen and avoided.** A narrow tall column full of sharp edges (checked on 3 real walls, left,
  right and in the middle of the screen) is a wall; headings toward it are bent away from it before the character gets there.
* **Stuck = turn away.** If two pushes in a row move nothing at all in a running game (rock, wall, edge of the map that
  has no visible thorns), the bot turns by 100 degrees or more and does not return to that heading for the next 8 moves.
* **The chip shows it.** When the bot bends a push you see `[lava ahead: turning]`, `[thorn wall ahead: turning]` or
  `[standing in lava: turning]` on the chip, and the debug log gets `HAZARD` and `STUCK` lines.
* **Death screen no longer read late.** In the video the "YOU DIED" screen was read about 3 seconds late (the bot only read
  the text every 5th step in a fast game, and the taunt words fade in after the screen changes). Now the text is read on
  every step while the picture is frozen, on a game-over screen or a popup, and for 3 more steps after any sudden
  change of the picture.

Tested on a PC with the real frames of the video: the lava and the three thorn walls are found where they really are,
"hero stands in lava" is found, and replaying 65 real frames of the run (780 pushes) the bot pushed into lava or thorns
0 times whenever a clear way existed. Without the map the same synthetic river was in the way for 32% of the pushes.
All older test suites still pass.

Honest limits of this: the hero is assumed to stand near the middle of the screen (camera follows the player), the lava
colour and the thorn look were measured on the Inferno map only, and other dangers (poison puddles, water, spikes on the
floor, enemy bullets) are not recognised yet. If a world is mostly orange (desert, brick) the lava check switches itself
off. If it still dies to something else, send the debug log.

## What is new in v2.7 (found by measuring the video of build 2.6)

Build 2.6 really played: it reached level 6 and survived 33 seconds (build 2.5: 22 seconds). The second video showed:

* **It signed the devil's contract.** The bot decided to press "tap to skip", but reading and thinking take about half a
  second and in that time a "SIGN IN BLOOD" button appeared exactly where the old text was. The press landed on it and
  the run started with the curse "+25% more demons hunt you". Now the service **looks once more right before every
  press that was chosen from words** and skips the press if the area around it changed (measured: a popup that just sits
  there changes 0.2 to 6 grey levels, an appearing button or a popup closing or sliding in changes 18 to 27, the limit
  is 8). It then looks again and decides on the new screen. Also, "in blood" / "sign contract" are never pressed, and
  "Walk away" is chosen (tested 40 runs, with and without "Walk away" being readable).
* **Fast characters were invisible.** The character now moves so fast the picture slides about 15 px per step; the
  detector only saw up to 8 px, so it kept losing movement mode and stood still testing hold / swipe in the middle of a
  fight. The slide search now reaches 20 px sideways and 16 px up and down (coarse then fine, only when needed) and
  catches 16 of 17 real fast-moving samples with no false alarms on 120+ real standing, frozen and popup samples.
* **Movement mode is sticky.** Once the joystick has clearly made the scene slide, a few pushes without a visible slide
  (a wall, a flash, a popup) no longer send the bot back to "learning". It is only dropped after 24 pushes in a row without
  any slide.
* **Game-over taunt.** "LEAVING SO SOON..." used to get joystick pushes. Now the bot waits for the continue button, then
  taps an empty spot to skip the taunt.
* **Cleaner pictures.** The small pictures used to measure change and slide are now made by halving the screenshot step by
  step (averaging), instead of one big sampling step that made quiet pictures flicker. This matches how the thresholds
  were measured.

## What is new in v2.6 (found by measuring a real Hell Survivor video, frame by frame)

The video showed that during real gameplay the bot almost never moved. Numbers measured on the video:

| Situation | 32x32 thumbnail change | fine picture difference |
|---|---|---|
| frozen LEVEL UP popup | 0.000 to 0.003 | 0.1 to 0.5 |
| running game, character standing still | 0.004 to 0.010 | 2 to 4 |
| joystick held, camera follows | 0.020 to 0.030 | 9 to 14 (slide 5 to 8 px) |

* **Running game vs frozen screen.** The old "is it live?" check only looked at the coarse thumbnail, so a standing
  character in a dark game looked frozen. The bot then tapped colour blobs, fired its "stuck" ladder of random swipes and
  taps and kept restarting its learning after every popup. Now a fine picture difference decides (running 2 to 4,
  popup under 1), and the service's stuck counter is overridden when the picture still moves.
* **Movement detector recalibrated** on the real frames. A real camera slide explains only 8 to 30 percent of the picture
  difference and is small in grey levels, so the old gates (gain of 1.5 grey levels, coherence 0.35) never fired. New
  gates fire on 7 of 8 real moving samples and on 0 of 36 standing samples and 0 of 37 frozen-popup samples.
* **Movement first.** Two quick looks, then joystick pushes from the very first live step (not after a 12 to 30 second
  learning phase). Popups no longer restart the learning, and the strategist never runs on a frozen popup.
* **Blobs are not buttons in gameplay.** On a calm screen only colour areas that stayed in the same place for 3 reads count.
* **LEVEL UP picker.** "LEVEL UP!" is a title, not a button (it was pressed and cost 3 to 6 seconds each time). The picker
  now needs real words, never picks HP numbers, penalises Reroll / Skip / Refresh / Shuffle / Banish, likes cards that have
  a NEW or Lv badge, and reads the small text under a card ("heals", "curse") for the survival rules.
* **Death screens.** "LEAVING SO SOON... YOU'LL NEVER ESCAPE!" counts as a death (run timed, survival style learned).
  "Descending" counts as a loading screen.
* **Better joystick gesture.** The old gesture slid the finger slowly from start to end, so the stick was only half pushed
  for the first half of the hold. Now it reaches the full push in the first 18 percent of the time and holds it there
  (tiny 2.5 px zig-zag steps), 1.2 s per push, and the next push starts before it ends, so the stick is nearly always held.
* **Swarm survival.** When enemies are on all sides, the bot runs through the quietest gap instead of dithering.
* **Calmer exploring.** In a confirmed movement game the random exploratory taps get rarer the more of them showed nothing.

Tests (on a PC, with the real measured numbers): the first push comes at step 3, 90 percent of steps are pushes, a LEVEL UP
popup gets a real card in at most 2 steps (20 of 20), the bot is pushing again right after, and the death taunt is logged.

## What is new in v2.5 (found by replaying the real Hell Survivor screen)

v2.4 was only tested on simulated games with an empty screen. The real game has a busy HUD (health bar on the character,
"RESCUE 2,550 m" text, pause button, item slots), and the bot treated those as buttons:
- It tapped the health bar, the HUD text and the pause area, and the "stuck popup" rescue (text picker, colour-area taps, Back) fired in the middle of normal gameplay.
- It spent its learning time on taps, swipes and holds while enemies killed the character.

Fixes:
- **Movement first.** After 4 short idle looks it pushes the joystick at the usual spots. As soon as the scene slides or the picture clearly changes because of the push,
  the game is "confirmed as a movement game": about 95% of moves are joystick pushes and the chip shows `Style: movement (joystick / drag)`. Taps are only re-checked ~5% of the time.
- **No HUD tapping.** Fixed colour areas count as buttons only in the lower corners, never the top bar, thin bars (health / XP / slots) or the middle where the character is.
  Coloured areas are only pressed on a calm screen. Numbers and HUD text are never "buttons".
- **Popup rescue only on real popups.** It needs at least 2 button-like words (short, no digits), nothing sliding recently, and the game style still unknown.
- **Health aware.** It reads "80 / 100" style health text. When health drops it runs from what moves with everything it has and changes direction (`HURT:` lines in the debug log).
- **Score that counts by itself** (auto-attack kills) is no longer mistaken for "tapping works".
- Bursts of taps only for things that did something real.
- The debug log now also lists what the bot reads: `TEXT #n: word@x,y | ...`.

## What is new in v2.4

**1. No more getting stuck on a popup.** Found in a screen recording: an animated "SELL YOUR SOUL?" contract popup
(a talking demon) held the bot for 35 s. Causes and fixes:
- "SIGN IN BLOOD" was treated as an account login ("sign in") and "Walk away" was not a known button. Login danger now only
  counts for real account actions ("sign in with Google", a lone "LOG IN"). Decline words (walk away, decline, refuse, no...) are always safe to press.
- Animated text made every frame look like a "new screen", so the bot never remembered which buttons did nothing. Screens are now matched
  by the words they share, so a changing speech bubble is still the same screen.
- Any change on screen counted as "the button worked". Now only a REAL effect counts (new screen, a score going up, the whole scene sliding, a big jump).
- A target that does nothing 3 times in a row is left alone for 30 steps, whatever the screen.
- The popup picker now prefers button-shaped text (short, on a wide colour area, not a question, not a speech bubble), not the big title.
- Still stuck after 8 steps: it presses Android Back once, and a screen that never changes no longer eats the 30 s learning time.

**2. Games that need pressing AND swiping/moving.** Before, the bot picked ONE best input and used it about 80% of the time, so in
mixed games it kept clicking. Now every input that clearly works stays in the mix, in proportion to how well it works.
- Joystick + buttons: the bot holds the joystick and presses a button with a second finger at the same time (move + attack).
- It finds fixed screen buttons (colour areas that never move, like skill buttons) and keeps pressing the ones that pay off.
- A score that counts up by itself (points per second) is ignored when judging which input works.

**3. Survival rules, always on (offline bot and AI).**
- Stay alive as long as possible: keep moving, run from things that move, turn away from walls, avoid curses / pacts / sacrifices, prefer defence and healing options.
- Learn from every death: it times each run (start to game over), tries a few survival styles (balanced, run-away, wanderer, big-pushes) and uses the
  styles that lasted longest more often. After game over it presses Retry and tries again. The debug log shows `DEATH #n after Xs ... next run style ...`.
- The AI prompt has the same rules built in, so they apply even when you type your own rules.

Test results in the PC simulations: popup replay escaped 20/20 (v2.3: 0/20); in a swipe+press game v2.3 locked to tapping (217 presses, 11 swipe hits)
and v2.4 uses both (155 presses, 56 swipe hits); in a hard joystick game the average life went from 33 s to 47 s.

## How the offline bot learns the game (v2.3)

When there is no menu button to press, the bot spends its first ~30 seconds finding out HOW the game is played:

1. **Watch**: two looks with no input measure how much the game moves by itself (animations).
2. **Probe**: it tries each kind of input a few times: a **joystick push** (finger down, slide, hold), taps, quick swipes and press-and-hold. It scores each by how much the screen changed ABOVE that idle level. A push that makes the whole scene slide (the camera follows the player) scores very high, a tap that makes a score number go up scores high, a swipe that moves puzzle tiles scores high.
3. **Play**: moves go to the styles that worked (several of them in a mixed game, in proportion), about 10% keep testing the others, so it adapts when the game changes.

The chip shows what it is doing, for example `Learning the game 12s/30s` and then `Style: movement (joystick / drag)`.

Joystick games: it finds where the stick is by trying a few usual spots (bottom left, bottom right, centre...), then keeps pushing in a direction that wanders, turns away when a wall stops the character, and runs away from the side of the screen where things are moving on their own (enemies). Joystick pushes are held while it looks at the next screenshot, so the character keeps moving while the bot thinks. In a movement game the slow text reading only runs every few steps or when the picture changes shape (pop-up, death screen), so it reacts faster.

Pop-ups with several options (level-up cards, rewards) are detected when words suddenly fill the middle of a live game or when the action freezes; it picks the biggest option and remembers options that do nothing.

The debug log shows the learning: `STYLE: ...` lines list the score of each input type.

## AI providers

| Provider | Notes |
|---|---|
| Google Gemini | Key from aistudio.google.com. Often has a free tier (check current limits). |
| Anthropic (Claude) | Key from console.anthropic.com. |
| OpenAI | Key from platform.openai.com. |
| OpenRouter | One key, many models, some free. |
| Groq | Fast, key from console.groq.com, has a free tier (check limits). |
| Custom (OpenAI-compatible) | Anything that speaks the OpenAI chat API: Mistral, Together, xAI, or Ollama / LM Studio on your own PC (`http://PC-IP:11434/v1`). Free if you run it yourself. |

The default model names are only suggestions and AI companies retire models, so the model name and
base URL are editable. The model MUST accept images. The model box needs the model **ID**
(for example `gemini-3.8-flash`), NOT a display name like "Gemini 3.x Flash". Paste your key, then tap
**Pick model from list** to choose a real ID from your account, then **Test AI connection**.

## Speed

- Pause between steps defaults to 0.2 s and can be 0 (as fast as the phone goes).
- AI mode: up to 6 actions per call (default 3), so far fewer round trips.
- Rapid tapping: up to 20 taps inside ONE gesture, no per-tap overhead.
- Offline bot skips the OCR when the screen did not change.
- The status line shows steps per second.
- Hard ceiling: Android only allows an accessibility service to screenshot about 3 times a second,
  and the AI itself takes a second or more per call. A future version could use screen recording for
  faster capture.

## Debug log

**Show debug log** (bottom of the app) lists what the bot did and why it stopped: every step, every
error, who called STOP, and any crash. Tap **Copy** and paste it to whoever is helping you.

## It can never press its own buttons (v2.2)

Four independent layers keep the bot off its own floating chip:

1. It finds the chip INSIDE the screenshot by the exact colours of the PLAY / STOP button, and also
   where Android says the chip is. Both spots are painted over before the screen is read.
2. Both spots are no-tap zones for the brain, with a safety margin. Text touching them is ignored.
3. Every tap, hold and swipe is checked right before it is sent. Anything near the chip is refused,
   logged, and the chip hops to the corner farthest from the target so the bot can reach what was under it.
4. If a touch still reaches the chip right when the bot was tapping there, it is ignored and logged,
   and the bot learns where the chip really is.

## Retired models heal themselves (v2.2)

AI companies retire models ("gemini-2.5-flash is no longer available"). When the provider says the
model is gone, unknown or mistyped, the app asks your account which models exist, picks the newest of
the same family (for example the newest Gemini Flash), checks that it answers, saves it and carries on.
**Test AI connection** does the same and tells you what it switched to. If nothing sensible is found it
tells you to use **Pick model from list**.

## Never stops by itself

The loop only stops when you press STOP, the API key is rejected, or the setup is wrong (bad model
name, no credit). Loading screens, frozen screens, slow networks, rate limits, screenshot errors and
unexpected exceptions (even crashes inside a step) are waited out and retried. If the AI says "finished" it keeps watching and only
pauses (with a message) after 4 "finished" answers in a row.

## Honest limits

- No app can win every game. Fast reflex games (runners, shooters, rhythm) will not work well.
- Use it on offline / single-player games. Bots in online competitive games usually break the rules
  and can get the account banned.
- Some apps block screenshots (banking apps, some video apps).
- AI mode sends screenshots of your screen to the provider you pick. Keys are stored on the phone in
  plain app storage, so use a key with a spend limit.
- The offline bot reads Latin-script text (English and similar). It will not press "Accept" / "Agree"
  on consent screens or anything that looks like buying, ads or logins. Do those yourself.
- Survival learning is simple trial and error over a few styles, not real understanding of the game. It helps in
  joystick / dodge games and does nothing for puzzle games.
- The movement detector, the liveness check and the joystick hold gesture were calibrated on ONE real video of ONE game
  (and tested on a PC with simulated games). If a game behaves differently, send the debug log (Show debug log, Copy).
- Needs Android 11+ (API 30).

## Build the APK

### A) GitHub with only the zip (phone friendly)
Keep `UniversalAutoPlayer.zip` in the root of the repo and a workflow file `.github/workflows/build.yml`
that unzips it and runs `gradle assembleDebug`. To update: upload the new zip with the SAME name, the
build runs by itself, then download the artifact from the Actions tab.

### B) GitHub with the unzipped project (PC)
Upload every file and folder (including `.github`). The included `build-apk.yml` builds it.

### C) Android Studio
Open the folder, let Gradle sync, *Build > Build APK(s)*. Output: `app/build/outputs/apk/debug/app-debug.apk`.

## First run on the phone

1. Open the app, tap **Open accessibility settings**, turn on **Universal AutoPlayer**.
   If Android says *Restricted setting*: Settings > Apps > Universal AutoPlayer > three dots >
   **Allow restricted settings**, then turn it on again.
2. Offline bot needs nothing more. For AI: switch the AI switch on, pick a provider, paste the key,
   **Save settings**, **Test AI connection**.
3. Optional: type rules in the rules box, e.g. `Match-3 game. Make combos. Never use boosters.`
4. **Pick a game and launch it**, then press **PLAY** on the floating chip.

## Code map

```
app/src/main/java/com/zirexhub/autoplayer/
  MainActivity.kt     settings screen, provider picker, game picker
  AutoPlayService.kt  accessibility service: screenshots, gestures, floating chip, the main loop
  AiBrain.kt          AI player (HTTP, error classification)
  Requests.kt         request builders + reply parsing for Anthropic / OpenAI-style / Gemini
  ActionParser.kt     AI reply text -> actions
  Prompts.kt          system + per-step prompts (safety rules live here)
  Providers.kt        provider presets
  SmartBrain.kt       offline bot (OCR + blobs + Planner)
  Planner.kt          offline thinking: rules, memory, learning, explore ladder, bursts (pure Kotlin)
  Blobs.kt            finds button-like colour areas (pure Kotlin)
  TextReader.kt       ML Kit OCR wrapper
  FrameTools.kt       thumbnails, change detection, JPEG/base64
  Brain.kt            GameAction / Decision / Brain interface
  ChipLocator.kt      finds the floating chip in a screenshot by colour (pure Kotlin)
  Motion.kt           how the scene slid between two screenshots + what moves on its own (pure Kotlin)
  Strategist.kt       30 s game-style probing, mixed games, survival styles, hazard steering, stuck turn (pure Kotlin)
  Hazards.kt          lava and thorn-wall detection from colours, 16-heading danger map and steering (pure Kotlin)
  Threats.kt          enemies, gems and the health bar from colours (pure Kotlin)
  Kiter.kt            scores 16 headings by enemy distance, lava and walls: the survivable gap (pure Kotlin)
  Hud.kt              HUD text that is never a button: distances, objective markers, learned labels (pure Kotlin)
  ApiErrors.kt        reads 429 / key errors, explains them, RateGuard keeps AI calls inside the provider limit (pure Kotlin)
  HybridBrain.kt      AI brain + offline bot: background AI calls, the offline bot plays in between
  Copilot.kt          when the AI is worth a call (lead / copilot) and the hold / use / drop state machine (pure Kotlin)
  Snap.kt             moves the AI's presses onto the OCR words they mean (pure Kotlin)
  GridFinder.kt       finds a board of equal cells (chess, checkers, sudoku...) so the AI can press "column 5, row 7" (pure Kotlin)
  ModelHealer.kt      picks a replacement for a retired model (pure Kotlin)
  Chess.kt            chess rules: positions, moves, hashing, undo (pure Kotlin, perft tested)
  ChessEngine.kt      the chess engine: search, evaluation, pondering (pure Kotlin)
  OpeningBook.kt      opening book lookup; OpeningData.kt holds its lines (pure Kotlin)
  ChessAuto.kt        follows a chess game from the screen and decides: book, engine, promotion, restarts (pure Kotlin)
  ScreenReport.kt     describes a screenshot as numbers and a digit map for the log (pure Kotlin)
  ChessBrain.kt       connects ChessAuto to the screen: board finding, taps, promotion box, game-over box
  ChessBoardFit.kt    checkerboard check on the finder's grid (picks the real 8x8 out of an 8x9), direct board search
  BoardPlan.kt / BoardTracker.kt / BoardCheck.kt / PromoPopup.kt   board reading helpers
  BuildInfo.kt        version number shown in the app and the debug log
  Prefs.kt            saved settings
  DebugLog.kt         on-device log shown by "Show debug log"
```

The pure-Kotlin parts (Planner, Blobs, Requests, ActionParser, Prompts) were unit tested on a PC.
The Android parts could not be compiled in the sandbox, so the first GitHub build is their first
real compile.

## Roadmap ideas (not built yet)

- **Live rules box**: a text box on the floating chip so you can type or change the AI's rules while
  you play ("play like this, do not do that"). The rules are already re-read every step, so this is
  only a UI addition.
- Faster capture through screen recording.
- Saving what the offline bot learned between sessions.
- More OCR languages.
