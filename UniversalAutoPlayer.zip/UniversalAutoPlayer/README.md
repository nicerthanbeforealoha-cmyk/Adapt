# Universal AutoPlayer (ZirexHub build) v2.8

An Android app that plays games for you. It takes a screenshot of whatever is on screen, decides
what to do, taps or swipes, and repeats. A small floating PLAY/STOP chip sits on top of any game.

## Two brains

| Brain | Needs | What it does |
|---|---|---|
| **AI player** | Internet + a key from any supported AI provider | Sends each screenshot (plus your rules, your last actions, and whether the screen changed) to a vision AI. It works out the game, returns 1 to 6 actions, and adapts when something does not work. |
| **Offline bot** (default) | Nothing | Reads the screen text on the phone (ML Kit OCR), presses Continue / Play / Next / Claim, closes pop-ups and X buttons, waits on loading screens, avoids buy / ad / login buttons and picks an option on level-up / reward pop-ups. When no button applies it **works out how the game is played** (see below) and plays that way. |

## What is new in v2.8 (found by measuring the video of build 2.7)

Build 2.7 played well but died to lava and kept walking into the thorn walls at the side of the map. Measured frame by
frame (the lava patch's position on screen shows the camera movement): the character drifted slowly toward a lava river,
walked onto it, and stood in it for about 2 seconds while damage ticks (-5, -6) ran, until it died. Nothing in the bot
knew that lava is bad.

* **Lava is seen and avoided.** Every step the bot now looks at the colours of the screenshot (a 96 px wide copy). Big
  areas of dark orange / red-brown (measured on the real map: RGB about 111,43,20) are lava. Small orange things (fire
  balls, the character's own glowing ring, weapon flames) are ignored because only big connected areas count, and
  yellow damage numbers and green gems are not lava colour. For 16 headings it works out how soon a walk that way hits
  lava. If the heading the strategy wanted points at lava, it is bent to the nearest clear heading (sliding along the
  edge, not turning right round). If the character already stands in lava it takes the shortest way out.
* **Thorn / spike walls are seen and avoided.** A narrow tall column full of sharp edges (checked on 3 real walls, left,
  right and in the middle of the screen) is a wall; headings toward it are bent away from it before the character gets there.
* **Stuck = turn away.** If two pushes in a row move nothing at all in a running game (rock, wall, edge of the map that
  has no visible thorns), the bot turns by 100 degrees or more and does not return to that heading for the next 8 moves.
* **The chip shows it.** When the bot bends a push you see `[lava ahead: turning]`, `[thorn wall ahead: turning]` or
  `[standing in lava: turning]` on the chip, and the debug log gets `HAZARD` and `STUCK` lines.
* **Death screen no longer read late.** In the video the "YOU DIED" screen was read about 3 seconds late (the bot only read
  the text every 5th step in a fast game, and the taunt words fade in after the screen changes). Now the text is read on
  every step while the picture is frozen, on a game-over screen or a popup, and for 3 more steps after any sudden
  change of the picture.

Tested on a PC with the real frames of the video: the lava and the three thorn walls are found where they really are,
"hero stands in lava" is found, and replaying 65 real frames of the run (780 pushes) the bot pushed into lava or thorns
0 times whenever a clear way existed. Without the map the same synthetic river was in the way for 32% of the pushes.
All older test suites still pass.

Honest limits of this: the hero is assumed to stand near the middle of the screen (camera follows the player), the lava
colour and the thorn look were measured on the Inferno map only, and other dangers (poison puddles, water, spikes on the
floor, enemy bullets) are not recognised yet. If a world is mostly orange (desert, brick) the lava check switches itself
off. If it still dies to something else, send the debug log.

## What is new in v2.7 (found by measuring the video of build 2.6)

Build 2.6 really played: it reached level 6 and survived 33 seconds (build 2.5: 22 seconds). The second video showed:

* **It signed the devil's contract.** The bot decided to press "tap to skip", but reading and thinking take about half a
  second and in that time a "SIGN IN BLOOD" button appeared exactly where the old text was. The press landed on it and
  the run started with the curse "+25% more demons hunt you". Now the service **looks once more right before every
  press that was chosen from words** and skips the press if the area around it changed (measured: a popup that just sits
  there changes 0.2 to 6 grey levels, an appearing button or a popup closing or sliding in changes 18 to 27, the limit
  is 8). It then looks again and decides on the new screen. Also, "in blood" / "sign contract" are never pressed, and
  "Walk away" is chosen (tested 40 runs, with and without "Walk away" being readable).
* **Fast characters were invisible.** The character now moves so fast the picture slides about 15 px per step; the
  detector only saw up to 8 px, so it kept losing movement mode and stood still testing hold / swipe in the middle of a
  fight. The slide search now reaches 20 px sideways and 16 px up and down (coarse then fine, only when needed) and
  catches 16 of 17 real fast-moving samples with no false alarms on 120+ real standing, frozen and popup samples.
* **Movement mode is sticky.** Once the joystick has clearly made the scene slide, a few pushes without a visible slide
  (a wall, a flash, a popup) no longer send the bot back to "learning". It is only dropped after 24 pushes in a row without
  any slide.
* **Game-over taunt.** "LEAVING SO SOON..." used to get joystick pushes. Now the bot waits for the continue button, then
  taps an empty spot to skip the taunt.
* **Cleaner pictures.** The small pictures used to measure change and slide are now made by halving the screenshot step by
  step (averaging), instead of one big sampling step that made quiet pictures flicker. This matches how the thresholds
  were measured.

## What is new in v2.6 (found by measuring a real Hell Survivor video, frame by frame)

The video showed that during real gameplay the bot almost never moved. Numbers measured on the video:

| Situation | 32x32 thumbnail change | fine picture difference |
|---|---|---|
| frozen LEVEL UP popup | 0.000 to 0.003 | 0.1 to 0.5 |
| running game, character standing still | 0.004 to 0.010 | 2 to 4 |
| joystick held, camera follows | 0.020 to 0.030 | 9 to 14 (slide 5 to 8 px) |

* **Running game vs frozen screen.** The old "is it live?" check only looked at the coarse thumbnail, so a standing
  character in a dark game looked frozen. The bot then tapped colour blobs, fired its "stuck" ladder of random swipes and
  taps and kept restarting its learning after every popup. Now a fine picture difference decides (running 2 to 4,
  popup under 1), and the service's stuck counter is overridden when the picture still moves.
* **Movement detector recalibrated** on the real frames. A real camera slide explains only 8 to 30 percent of the picture
  difference and is small in grey levels, so the old gates (gain of 1.5 grey levels, coherence 0.35) never fired. New
  gates fire on 7 of 8 real moving samples and on 0 of 36 standing samples and 0 of 37 frozen-popup samples.
* **Movement first.** Two quick looks, then joystick pushes from the very first live step (not after a 12 to 30 second
  learning phase). Popups no longer restart the learning, and the strategist never runs on a frozen popup.
* **Blobs are not buttons in gameplay.** On a calm screen only colour areas that stayed in the same place for 3 reads count.
* **LEVEL UP picker.** "LEVEL UP!" is a title, not a button (it was pressed and cost 3 to 6 seconds each time). The picker
  now needs real words, never picks HP numbers, penalises Reroll / Skip / Refresh / Shuffle / Banish, likes cards that have
  a NEW or Lv badge, and reads the small text under a card ("heals", "curse") for the survival rules.
* **Death screens.** "LEAVING SO SOON... YOU'LL NEVER ESCAPE!" counts as a death (run timed, survival style learned).
  "Descending" counts as a loading screen.
* **Better joystick gesture.** The old gesture slid the finger slowly from start to end, so the stick was only half pushed
  for the first half of the hold. Now it reaches the full push in the first 18 percent of the time and holds it there
  (tiny 2.5 px zig-zag steps), 1.2 s per push, and the next push starts before it ends, so the stick is nearly always held.
* **Swarm survival.** When enemies are on all sides, the bot runs through the quietest gap instead of dithering.
* **Calmer exploring.** In a confirmed movement game the random exploratory taps get rarer the more of them showed nothing.

Tests (on a PC, with the real measured numbers): the first push comes at step 3, 90 percent of steps are pushes, a LEVEL UP
popup gets a real card in at most 2 steps (20 of 20), the bot is pushing again right after, and the death taunt is logged.

## What is new in v2.5 (found by replaying the real Hell Survivor screen)

v2.4 was only tested on simulated games with an empty screen. The real game has a busy HUD (health bar on the character,
"RESCUE 2,550 m" text, pause button, item slots), and the bot treated those as buttons:
- It tapped the health bar, the HUD text and the pause area, and the "stuck popup" rescue (text picker, colour-area taps, Back) fired in the middle of normal gameplay.
- It spent its learning time on taps, swipes and holds while enemies killed the character.

Fixes:
- **Movement first.** After 4 short idle looks it pushes the joystick at the usual spots. As soon as the scene slides or the picture clearly changes because of the push,
  the game is "confirmed as a movement game": about 95% of moves are joystick pushes and the chip shows `Style: movement (joystick / drag)`. Taps are only re-checked ~5% of the time.
- **No HUD tapping.** Fixed colour areas count as buttons only in the lower corners, never the top bar, thin bars (health / XP / slots) or the middle where the character is.
  Coloured areas are only pressed on a calm screen. Numbers and HUD text are never "buttons".
- **Popup rescue only on real popups.** It needs at least 2 button-like words (short, no digits), nothing sliding recently, and the game style still unknown.
- **Health aware.** It reads "80 / 100" style health text. When health drops it runs from what moves with everything it has and changes direction (`HURT:` lines in the debug log).
- **Score that counts by itself** (auto-attack kills) is no longer mistaken for "tapping works".
- Bursts of taps only for things that did something real.
- The debug log now also lists what the bot reads: `TEXT #n: word@x,y | ...`.

## What is new in v2.4

**1. No more getting stuck on a popup.** Found in a screen recording: an animated "SELL YOUR SOUL?" contract popup
(a talking demon) held the bot for 35 s. Causes and fixes:
- "SIGN IN BLOOD" was treated as an account login ("sign in") and "Walk away" was not a known button. Login danger now only
  counts for real account actions ("sign in with Google", a lone "LOG IN"). Decline words (walk away, decline, refuse, no...) are always safe to press.
- Animated text made every frame look like a "new screen", so the bot never remembered which buttons did nothing. Screens are now matched
  by the words they share, so a changing speech bubble is still the same screen.
- Any change on screen counted as "the button worked". Now only a REAL effect counts (new screen, a score going up, the whole scene sliding, a big jump).
- A target that does nothing 3 times in a row is left alone for 30 steps, whatever the screen.
- The popup picker now prefers button-shaped text (short, on a wide colour area, not a question, not a speech bubble), not the big title.
- Still stuck after 8 steps: it presses Android Back once, and a screen that never changes no longer eats the 30 s learning time.

**2. Games that need pressing AND swiping/moving.** Before, the bot picked ONE best input and used it about 80% of the time, so in
mixed games it kept clicking. Now every input that clearly works stays in the mix, in proportion to how well it works.
- Joystick + buttons: the bot holds the joystick and presses a button with a second finger at the same time (move + attack).
- It finds fixed screen buttons (colour areas that never move, like skill buttons) and keeps pressing the ones that pay off.
- A score that counts up by itself (points per second) is ignored when judging which input works.

**3. Survival rules, always on (offline bot and AI).**
- Stay alive as long as possible: keep moving, run from things that move, turn away from walls, avoid curses / pacts / sacrifices, prefer defence and healing options.
- Learn from every death: it times each run (start to game over), tries a few survival styles (balanced, run-away, wanderer, big-pushes) and uses the
  styles that lasted longest more often. After game over it presses Retry and tries again. The debug log shows `DEATH #n after Xs ... next run style ...`.
- The AI prompt has the same rules built in, so they apply even when you type your own rules.

Test results in the PC simulations: popup replay escaped 20/20 (v2.3: 0/20); in a swipe+press game v2.3 locked to tapping (217 presses, 11 swipe hits)
and v2.4 uses both (155 presses, 56 swipe hits); in a hard joystick game the average life went from 33 s to 47 s.

## How the offline bot learns the game (v2.3)

When there is no menu button to press, the bot spends its first ~30 seconds finding out HOW the game is played:

1. **Watch**: two looks with no input measure how much the game moves by itself (animations).
2. **Probe**: it tries each kind of input a few times: a **joystick push** (finger down, slide, hold), taps, quick swipes and press-and-hold. It scores each by how much the screen changed ABOVE that idle level. A push that makes the whole scene slide (the camera follows the player) scores very high, a tap that makes a score number go up scores high, a swipe that moves puzzle tiles scores high.
3. **Play**: moves go to the styles that worked (several of them in a mixed game, in proportion), about 10% keep testing the others, so it adapts when the game changes.

The chip shows what it is doing, for example `Learning the game 12s/30s` and then `Style: movement (joystick / drag)`.

Joystick games: it finds where the stick is by trying a few usual spots (bottom left, bottom right, centre...), then keeps pushing in a direction that wanders, turns away when a wall stops the character, and runs away from the side of the screen where things are moving on their own (enemies). Joystick pushes are held while it looks at the next screenshot, so the character keeps moving while the bot thinks. In a movement game the slow text reading only runs every few steps or when the picture changes shape (pop-up, death screen), so it reacts faster.

Pop-ups with several options (level-up cards, rewards) are detected when words suddenly fill the middle of a live game or when the action freezes; it picks the biggest option and remembers options that do nothing.

The debug log shows the learning: `STYLE: ...` lines list the score of each input type.

## AI providers

| Provider | Notes |
|---|---|
| Google Gemini | Key from aistudio.google.com. Often has a free tier (check current limits). |
| Anthropic (Claude) | Key from console.anthropic.com. |
| OpenAI | Key from platform.openai.com. |
| OpenRouter | One key, many models, some free. |
| Groq | Fast, key from console.groq.com, has a free tier (check limits). |
| Custom (OpenAI-compatible) | Anything that speaks the OpenAI chat API: Mistral, Together, xAI, or Ollama / LM Studio on your own PC (`http://PC-IP:11434/v1`). Free if you run it yourself. |

The default model names are only suggestions and AI companies retire models, so the model name and
base URL are editable. The model MUST accept images. The model box needs the model **ID**
(for example `gemini-3.8-flash`), NOT a display name like "Gemini 3.x Flash". Paste your key, then tap
**Pick model from list** to choose a real ID from your account, then **Test AI connection**.

## Speed

- Pause between steps defaults to 0.2 s and can be 0 (as fast as the phone goes).
- AI mode: up to 6 actions per call (default 3), so far fewer round trips.
- Rapid tapping: up to 20 taps inside ONE gesture, no per-tap overhead.
- Offline bot skips the OCR when the screen did not change.
- The status line shows steps per second.
- Hard ceiling: Android only allows an accessibility service to screenshot about 3 times a second,
  and the AI itself takes a second or more per call. A future version could use screen recording for
  faster capture.

## Debug log

**Show debug log** (bottom of the app) lists what the bot did and why it stopped: every step, every
error, who called STOP, and any crash. Tap **Copy** and paste it to whoever is helping you.

## It can never press its own buttons (v2.2)

Four independent layers keep the bot off its own floating chip:

1. It finds the chip INSIDE the screenshot by the exact colours of the PLAY / STOP button, and also
   where Android says the chip is. Both spots are painted over before the screen is read.
2. Both spots are no-tap zones for the brain, with a safety margin. Text touching them is ignored.
3. Every tap, hold and swipe is checked right before it is sent. Anything near the chip is refused,
   logged, and the chip hops to the corner farthest from the target so the bot can reach what was under it.
4. If a touch still reaches the chip right when the bot was tapping there, it is ignored and logged,
   and the bot learns where the chip really is.

## Retired models heal themselves (v2.2)

AI companies retire models ("gemini-2.5-flash is no longer available"). When the provider says the
model is gone, unknown or mistyped, the app asks your account which models exist, picks the newest of
the same family (for example the newest Gemini Flash), checks that it answers, saves it and carries on.
**Test AI connection** does the same and tells you what it switched to. If nothing sensible is found it
tells you to use **Pick model from list**.

## Never stops by itself

The loop only stops when you press STOP, the API key is rejected, or the setup is wrong (bad model
name, no credit). Loading screens, frozen screens, slow networks, rate limits, screenshot errors and
unexpected exceptions (even crashes inside a step) are waited out and retried. If the AI says "finished" it keeps watching and only
pauses (with a message) after 4 "finished" answers in a row.

## Honest limits

- No app can win every game. Fast reflex games (runners, shooters, rhythm) will not work well.
- Use it on offline / single-player games. Bots in online competitive games usually break the rules
  and can get the account banned.
- Some apps block screenshots (banking apps, some video apps).
- AI mode sends screenshots of your screen to the provider you pick. Keys are stored on the phone in
  plain app storage, so use a key with a spend limit.
- The offline bot reads Latin-script text (English and similar). It will not press "Accept" / "Agree"
  on consent screens or anything that looks like buying, ads or logins. Do those yourself.
- Survival learning is simple trial and error over a few styles, not real understanding of the game. It helps in
  joystick / dodge games and does nothing for puzzle games.
- The movement detector, the liveness check and the joystick hold gesture were calibrated on ONE real video of ONE game
  (and tested on a PC with simulated games). If a game behaves differently, send the debug log (Show debug log, Copy).
- Needs Android 11+ (API 30).

## Build the APK

### A) GitHub with only the zip (phone friendly)
Keep `UniversalAutoPlayer.zip` in the root of the repo and a workflow file `.github/workflows/build.yml`
that unzips it and runs `gradle assembleDebug`. To update: upload the new zip with the SAME name, the
build runs by itself, then download the artifact from the Actions tab.

### B) GitHub with the unzipped project (PC)
Upload every file and folder (including `.github`). The included `build-apk.yml` builds it.

### C) Android Studio
Open the folder, let Gradle sync, *Build > Build APK(s)*. Output: `app/build/outputs/apk/debug/app-debug.apk`.

## First run on the phone

1. Open the app, tap **Open accessibility settings**, turn on **Universal AutoPlayer**.
   If Android says *Restricted setting*: Settings > Apps > Universal AutoPlayer > three dots >
   **Allow restricted settings**, then turn it on again.
2. Offline bot needs nothing more. For AI: switch the AI switch on, pick a provider, paste the key,
   **Save settings**, **Test AI connection**.
3. Optional: type rules in the rules box, e.g. `Match-3 game. Make combos. Never use boosters.`
4. **Pick a game and launch it**, then press **PLAY** on the floating chip.

## Code map

```
app/src/main/java/com/zirexhub/autoplayer/
  MainActivity.kt     settings screen, provider picker, game picker
  AutoPlayService.kt  accessibility service: screenshots, gestures, floating chip, the main loop
  AiBrain.kt          AI player (HTTP, error classification)
  Requests.kt         request builders + reply parsing for Anthropic / OpenAI-style / Gemini
  ActionParser.kt     AI reply text -> actions
  Prompts.kt          system + per-step prompts (safety rules live here)
  Providers.kt        provider presets
  SmartBrain.kt       offline bot (OCR + blobs + Planner)
  Planner.kt          offline thinking: rules, memory, learning, explore ladder, bursts (pure Kotlin)
  Blobs.kt            finds button-like colour areas (pure Kotlin)
  TextReader.kt       ML Kit OCR wrapper
  FrameTools.kt       thumbnails, change detection, JPEG/base64
  Brain.kt            GameAction / Decision / Brain interface
  ChipLocator.kt      finds the floating chip in a screenshot by colour (pure Kotlin)
  Motion.kt           how the scene slid between two screenshots + what moves on its own (pure Kotlin)
  Strategist.kt       30 s game-style probing, mixed games, survival styles, hazard steering, stuck turn (pure Kotlin)
  Hazards.kt          lava and thorn-wall detection from colours, 16-heading danger map and steering (pure Kotlin)
  ModelHealer.kt      picks a replacement for a retired model (pure Kotlin)
  BuildInfo.kt        version number shown in the app and the debug log
  Prefs.kt            saved settings
  DebugLog.kt         on-device log shown by "Show debug log"
```

The pure-Kotlin parts (Planner, Blobs, Requests, ActionParser, Prompts) were unit tested on a PC.
The Android parts could not be compiled in the sandbox, so the first GitHub build is their first
real compile.

## Roadmap ideas (not built yet)

- **Live rules box**: a text box on the floating chip so you can type or change the AI's rules while
  you play ("play like this, do not do that"). The rules are already re-read every step, so this is
  only a UI addition.
- Faster capture through screen recording.
- Saving what the offline bot learned between sessions.
- More OCR languages.
