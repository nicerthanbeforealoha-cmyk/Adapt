# Universal AutoPlayer (ZirexHub build) v2.2

An Android app that plays games for you. It takes a screenshot of whatever is on screen, decides
what to do, taps or swipes, and repeats. A small floating PLAY/STOP chip sits on top of any game.

## Two brains

| Brain | Needs | What it does |
|---|---|---|
| **AI player** | Internet + a key from any supported AI provider | Sends each screenshot (plus your rules, your last actions, and whether the screen changed) to a vision AI. It works out the game, returns 1 to 6 actions, and adapts when something does not work. |
| **Offline bot** (default) | Nothing | Reads the screen text on the phone (ML Kit OCR), presses Continue / Play / Next / Claim, closes pop-ups and X buttons, waits on loading screens, avoids buy / ad / login buttons, remembers what worked on each screen, and sends fast tap bursts when something pays off (clicker / tapper games). When nothing matches it explores: taps anywhere, swipes, long presses, with a learning bandit that favours spots that made the screen react. |

## AI providers

| Provider | Notes |
|---|---|
| Google Gemini | Key from aistudio.google.com. Often has a free tier (check current limits). |
| Anthropic (Claude) | Key from console.anthropic.com. |
| OpenAI | Key from platform.openai.com. |
| OpenRouter | One key, many models, some free. |
| Groq | Fast, key from console.groq.com, has a free tier (check limits). |
| Custom (OpenAI-compatible) | Anything that speaks the OpenAI chat API: Mistral, Together, xAI, or Ollama / LM Studio on your own PC (`http://PC-IP:11434/v1`). Free if you run it yourself. |

The default model names are only suggestions and AI companies retire models, so the model name and
base URL are editable. The model MUST accept images. The model box needs the model **ID**
(for example `gemini-3.8-flash`), NOT a display name like "Gemini 3.x Flash". Paste your key, then tap
**Pick model from list** to choose a real ID from your account, then **Test AI connection**.

## Speed

- Pause between steps defaults to 0.2 s and can be 0 (as fast as the phone goes).
- AI mode: up to 6 actions per call (default 3), so far fewer round trips.
- Rapid tapping: up to 20 taps inside ONE gesture, no per-tap overhead.
- Offline bot skips the OCR when the screen did not change.
- The status line shows steps per second.
- Hard ceiling: Android only allows an accessibility service to screenshot about 3 times a second,
  and the AI itself takes a second or more per call. A future version could use screen recording for
  faster capture.

## Debug log

**Show debug log** (bottom of the app) lists what the bot did and why it stopped: every step, every
error, who called STOP, and any crash. Tap **Copy** and paste it to whoever is helping you.

## It can never press its own buttons (v2.2)

Four independent layers keep the bot off its own floating chip:

1. It finds the chip INSIDE the screenshot by the exact colours of the PLAY / STOP button, and also
   where Android says the chip is. Both spots are painted over before the screen is read.
2. Both spots are no-tap zones for the brain, with a safety margin. Text touching them is ignored.
3. Every tap, hold and swipe is checked right before it is sent. Anything near the chip is refused,
   logged, and the chip hops to the corner farthest from the target so the bot can reach what was under it.
4. If a touch still reaches the chip right when the bot was tapping there, it is ignored and logged,
   and the bot learns where the chip really is.

## Retired models heal themselves (v2.2)

AI companies retire models ("gemini-2.5-flash is no longer available"). When the provider says the
model is gone, unknown or mistyped, the app asks your account which models exist, picks the newest of
the same family (for example the newest Gemini Flash), checks that it answers, saves it and carries on.
**Test AI connection** does the same and tells you what it switched to. If nothing sensible is found it
tells you to use **Pick model from list**.

## Never stops by itself

The loop only stops when you press STOP, the API key is rejected, or the setup is wrong (bad model
name, no credit). Loading screens, frozen screens, slow networks, rate limits, screenshot errors and
unexpected exceptions (even crashes inside a step) are waited out and retried. If the AI says "finished" it keeps watching and only
pauses (with a message) after 4 "finished" answers in a row.

## Honest limits

- No app can win every game. Fast reflex games (runners, shooters, rhythm) will not work well.
- Use it on offline / single-player games. Bots in online competitive games usually break the rules
  and can get the account banned.
- Some apps block screenshots (banking apps, some video apps).
- AI mode sends screenshots of your screen to the provider you pick. Keys are stored on the phone in
  plain app storage, so use a key with a spend limit.
- The offline bot reads Latin-script text (English and similar). It will not press "Accept" / "Agree"
  on consent screens or anything that looks like buying, ads or logins. Do those yourself.
- Needs Android 11+ (API 30).

## Build the APK

### A) GitHub with only the zip (phone friendly)
Keep `UniversalAutoPlayer.zip` in the root of the repo and a workflow file `.github/workflows/build.yml`
that unzips it and runs `gradle assembleDebug`. To update: upload the new zip with the SAME name, the
build runs by itself, then download the artifact from the Actions tab.

### B) GitHub with the unzipped project (PC)
Upload every file and folder (including `.github`). The included `build-apk.yml` builds it.

### C) Android Studio
Open the folder, let Gradle sync, *Build > Build APK(s)*. Output: `app/build/outputs/apk/debug/app-debug.apk`.

## First run on the phone

1. Open the app, tap **Open accessibility settings**, turn on **Universal AutoPlayer**.
   If Android says *Restricted setting*: Settings > Apps > Universal AutoPlayer > three dots >
   **Allow restricted settings**, then turn it on again.
2. Offline bot needs nothing more. For AI: switch the AI switch on, pick a provider, paste the key,
   **Save settings**, **Test AI connection**.
3. Optional: type rules in the rules box, e.g. `Match-3 game. Make combos. Never use boosters.`
4. **Pick a game and launch it**, then press **PLAY** on the floating chip.

## Code map

```
app/src/main/java/com/zirexhub/autoplayer/
  MainActivity.kt     settings screen, provider picker, game picker
  AutoPlayService.kt  accessibility service: screenshots, gestures, floating chip, the main loop
  AiBrain.kt          AI player (HTTP, error classification)
  Requests.kt         request builders + reply parsing for Anthropic / OpenAI-style / Gemini
  ActionParser.kt     AI reply text -> actions
  Prompts.kt          system + per-step prompts (safety rules live here)
  Providers.kt        provider presets
  SmartBrain.kt       offline bot (OCR + blobs + Planner)
  Planner.kt          offline thinking: rules, memory, learning, explore ladder, bursts (pure Kotlin)
  Blobs.kt            finds button-like colour areas (pure Kotlin)
  TextReader.kt       ML Kit OCR wrapper
  FrameTools.kt       thumbnails, change detection, JPEG/base64
  Brain.kt            GameAction / Decision / Brain interface
  ChipLocator.kt      finds the floating chip in a screenshot by colour (pure Kotlin)
  ModelHealer.kt      picks a replacement for a retired model (pure Kotlin)
  BuildInfo.kt        version number shown in the app and the debug log
  Prefs.kt            saved settings
  DebugLog.kt         on-device log shown by "Show debug log"
```

The pure-Kotlin parts (Planner, Blobs, Requests, ActionParser, Prompts) were unit tested on a PC.
The Android parts could not be compiled in the sandbox, so the first GitHub build is their first
real compile.

## Roadmap ideas (not built yet)

- **Live rules box**: a text box on the floating chip so you can type or change the AI's rules while
  you play ("play like this, do not do that"). The rules are already re-read every step, so this is
  only a UI addition.
- Faster capture through screen recording.
- Saving what the offline bot learned between sessions.
- More OCR languages.
