package com.zirexhub.autoplayer

/** What the AI read from a chess board: the pieces as drawn on the screen (top row first) and which colour is at the bottom. */
class BoardRead(val fen: String, val whiteAt: String)

/** A move chosen by the chess engine: the cells it goes between (col1,row1,col2,row2) and the key of the position after it. */
class ChessPlay(val cells: IntArray, val afterKey: String)

/**
 * From "what the AI read" to "which cells to press" (pure Kotlin, no Android, tested on a PC).
 *
 * The AI is good at reading a board and bad at choosing chess moves: in a real game it mixed up ranks (f5 for f4), moved a bishop
 * straight, or described a piece that was not there. So the AI only READS the position, in the order it is drawn on the screen
 * (no flipping in its head), and the chess engine ([ChessEngine]) chooses the move. Nothing the AI says is trusted blindly: the
 * reading must be a possible chess position, it must roughly agree with the picture (which squares hold a piece), and a move
 * that already failed on the screen is never chosen again.
 *
 * Which side we play: the colour at the bottom of the screen (the human's side in every chess app seen so far).
 */
object BoardPlan {

    class Plan(
        val actions: List<GameAction>,
        val cells: IntArray, // col1, row1, col2, row2 (1 = left column / top row)
        val choice: ChessChoice,
        val afterKey: String,
        val note: String,
        val label: String,
    )

    /** Either a [plan] or the reason there is none ([why], for the log; the AI's own move is used then). */
    class Outcome(val plan: Plan?, val why: String)

    /** The pieces of a FEN placement as drawn: result[row][col], row 0 = top of the screen. Null if it is not 8x8. */
    fun parseDisplay(fen: String): Array<IntArray>? {
        val placement = fen.trim().split(Regex("\\s+")).firstOrNull() ?: return null
        val rows = placement.split('/')
        if (rows.size != 8) return null
        val out = Array(8) { IntArray(8) }
        for ((r, text) in rows.withIndex()) {
            var c = 0
            for (ch in text) {
                if (ch in '1'..'8') {
                    c += ch - '0'
                } else {
                    val v = ChessPos.pieceOf(ch)
                    if (v == 0 || c > 7) return null
                    out[r][c] = v
                    c++
                }
                if (c > 8) return null
            }
            if (c != 8) return null
        }
        return out
    }

    /** White at the bottom? Decided by where the white pieces stand on the screen, not by what the AI claims. */
    fun whiteAtBottom(disp: Array<IntArray>, claim: String): Boolean? {
        var wSum = 0.0
        var wN = 0
        var bSum = 0.0
        var bN = 0
        for (r in 0 until 8) for (c in 0 until 8) {
            val v = disp[r][c]
            if (v > 0) { wSum += r; wN++ } else if (v < 0) { bSum += r; bN++ }
        }
        if (wN == 0 || bN == 0) return null
        val w = wSum / wN
        val b = bSum / bN
        if (Math.abs(w - b) < 0.3) return !claim.lowercase().contains("top")
        return w > b
    }

    /** The cell (col 1..8, row 1..8) of a real square (0..63), and back. */
    fun cellOf(sq: Int, whiteBottom: Boolean): IntArray {
        val file = sq and 7
        val rank = sq shr 3
        return if (whiteBottom) intArrayOf(file + 1, 8 - rank) else intArrayOf(8 - file, rank + 1)
    }

    fun squareOf(col: Int, row: Int, whiteBottom: Boolean): Int =
        if (whiteBottom) (8 - row) * 8 + (col - 1) else (row - 1) * 8 + (8 - col)

    /** Why this position cannot be a chess position, or null when it can. */
    fun problem(pos: ChessPos): String? {
        var wK = 0
        var bK = 0
        var w = 0
        var bl = 0
        var wP = 0
        var bP = 0
        for (sq in 0 until 64) {
            val v = pos.b[sq]
            if (v == 0) continue
            if (v == 6) wK++
            if (v == -6) bK++
            if (v > 0) w++ else bl++
            if (v == 1) wP++
            if (v == -1) bP++
            if (Math.abs(v) == 1 && (sq shr 3 == 0 || sq shr 3 == 7)) return "a pawn on the first or last row"
        }
        if (wK != 1 || bK != 1) return "there must be exactly one king of each colour (read $wK white, $bK black)"
        if (w > 16 || bl > 16) return "more than 16 pieces of one colour"
        if (wP > 8 || bP > 8) return "more than 8 pawns of one colour"
        // the side that just moved cannot have left its own king attacked
        if (pos.attacked(pos.kingSq(-pos.side), pos.side)) return "the opponent's king is in check while it is our turn (a misread)"
        return null
    }

    /**
     * How many of the 64 squares disagree between the picture (piece or no piece, judged by how much the square varies) and the
     * reading. Squares under the bot's own chip are not judged. Returns (judged, differing).
     */
    fun occupancy(picture: Gray, grid: Grid, disp: Array<IntArray>, blocked: List<Zone>): Pair<Int, Int> {
        val stds = FloatArray(64)
        for (r in 0 until 8) for (c in 0 until 8) stds[r * 8 + c] = BoardCheck.cellStd(picture, grid, c + 1, r + 1)
        val sorted = stds.sorted()
        val q25 = sorted[16]
        val threshold = maxOf(OCC_MIN_STD, q25 * 2.5f + 2f)
        var judged = 0
        var differ = 0
        for (r in 0 until 8) for (c in 0 until 8) {
            val cx = grid.cx(c + 1)
            val cy = grid.cy(r + 1)
            if (blocked.any { it.contains(cx, cy) }) continue
            judged++
            val image = stds[r * 8 + c] > threshold
            val read = disp[r][c] != 0
            if (image != read) differ++
        }
        return Pair(judged, differ)
    }

    /**
     * The move to play for [read], or the reason there is none. [failed] = cell moves (col1,row1,col2,row2) that did not
     * happen on the screen since the last move that did; [avoid] = positions already played to; [selected] = the cell of a
     * piece that is believed to be selected already (then one tap on the target is enough: a second tap on the piece would
     * un-select it).
     */
    fun plan(
        read: BoardRead,
        grid: Grid,
        picture: Gray?,
        blocked: List<Zone>,
        failed: List<IntArray>,
        avoid: Set<String>,
        selected: Pair<Int, Int>?,
        engine: ChessEngine,
        timeMs: Long,
    ): Outcome {
        if (grid.cols != 8 || grid.rows != 8) return Outcome(null, "the board is ${grid.cols}x${grid.rows}, not 8x8")
        val disp = parseDisplay(read.fen) ?: return Outcome(null, "the reading is not 8 rows of 8 squares: \"${read.fen.take(60)}\"")
        val whiteBottom = whiteAtBottom(disp, read.whiteAt) ?: return Outcome(null, "the reading has no pieces of one colour")

        val pos = ChessPos()
        for (r in 0 until 8) for (c in 0 until 8) {
            val v = disp[r][c]
            if (v != 0) pos.b[squareOf(c + 1, r + 1, whiteBottom)] = v
        }
        pos.side = if (whiteBottom) 1 else -1
        // castling is allowed only where the king and the rook still stand on their home squares
        if (pos.b[4] == 6 && pos.b[7] == 4) pos.castle = pos.castle or 1
        if (pos.b[4] == 6 && pos.b[0] == 4) pos.castle = pos.castle or 2
        if (pos.b[60] == -6 && pos.b[63] == -4) pos.castle = pos.castle or 4
        if (pos.b[60] == -6 && pos.b[56] == -4) pos.castle = pos.castle or 8
        pos.refreshKings()
        problem(pos)?.let { return Outcome(null, "impossible position: $it") }

        var occText = ""
        if (picture != null) {
            val (judged, differ) = occupancy(picture, grid, disp, blocked)
            occText = ", picture agrees on ${judged - differ}/$judged squares"
            if (judged >= 40 && differ > MAX_OCC_DIFFER) {
                return Outcome(null, "the reading does not match the picture ($differ of $judged squares differ)")
            }
        }

        val exclude = HashSet<String>()
        for (f in failed) {
            if (f.size < 4) continue
            val base = ChessPos.name(squareOf(f[0], f[1], whiteBottom)) + ChessPos.name(squareOf(f[2], f[3], whiteBottom))
            exclude.add(base)
            for (p in "qrbn") exclude.add(base + p)
        }
        val choice = engine.best(pos, timeMs, 40, exclude, avoid) ?: return Outcome(null, "the engine has no move (game over, or every move failed)")

        val from = cellOf(choice.move and 63, whiteBottom)
        val to = cellOf((choice.move shr 6) and 63, whiteBottom)
        val tapTo = GameAction.Tap(grid.cx(to[0]), grid.cy(to[1]), 1, "cell(${to[0]},${to[1]})", true)
        val actions: List<GameAction> =
            if (selected != null && selected.first == from[0] && selected.second == from[1]) {
                listOf(tapTo)
            } else {
                listOf(GameAction.Tap(grid.cx(from[0]), grid.cy(from[1]), 1, "cell(${from[0]},${from[1]})", true), tapTo)
            }
        pos.make(choice.move)
        val after = pos.key()
        val scoreText = if (Math.abs(choice.score) > ChessEngine.MATE - 100) "mate" else (if (choice.score >= 0) "+" else "") + choice.score
        val note = "chess engine: ${choice.uci} ($scoreText cp, depth ${choice.depth}, ${choice.nodes / 1000}k nodes; we play ${if (whiteBottom) "white" else "black"}$occText)"
        val label = actions.joinToString(" ; ") { (it as GameAction.Tap).label }
        return Outcome(Plan(actions, intArrayOf(from[0], from[1], to[0], to[1]), choice, after, note, label), "")
    }

    private const val OCC_MIN_STD = 6f
    private const val MAX_OCC_DIFFER = 14
}
