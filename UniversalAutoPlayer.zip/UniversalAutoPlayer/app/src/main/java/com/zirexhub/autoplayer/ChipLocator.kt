package com.zirexhub.autoplayer

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Finds the floating chip's PLAY / STOP button INSIDE a screenshot, by its two exact colours
 * (green when stopped, red when running). Pure Kotlin, no Android.
 *
 * Why: Android's idea of where the chip window is and where it really is in the screenshot can
 * disagree (status bar, notch, vendor skins). The screenshot is the ground truth, so the bot looks for
 * its own button there and hides / avoids exactly that spot.
 */
object ChipLocator {

    const val GREEN = 0xFF35E0A1.toInt()
    const val RED = 0xFFFF6B6B.toInt()

    /** Pixel box, [l, r) x [t, b). */
    class Box(val l: Int, val t: Int, val r: Int, val b: Int) {
        val w: Int get() = r - l
        val h: Int get() = b - t
        val cx: Float get() = (l + r) / 2f
        val cy: Float get() = (t + b) / 2f
    }

    private fun near(c: Int, target: Int, tol: Int): Boolean =
        abs(((c shr 16) and 0xFF) - ((target shr 16) and 0xFF)) <= tol &&
            abs(((c shr 8) and 0xFF) - ((target shr 8) and 0xFF)) <= tol &&
            abs((c and 0xFF) - (target and 0xFF)) <= tol

    /**
     * @param px        ARGB pixels of the (downscaled) frame, [gw] x [gh]
     * @param expectW   expected button width in grid pixels, or <= 0 if unknown
     * @param expectH   expected button height in grid pixels, or <= 0 if unknown
     * @param hintCx    where Android says the button is (grid pixels), or < 0 if unknown
     * @param hintCy    same, vertical
     * @return the button's box in grid pixels, or null if it is not found
     */
    fun find(
        px: IntArray,
        gw: Int,
        gh: Int,
        expectW: Float,
        expectH: Float,
        hintCx: Float,
        hintCy: Float,
        tol: Int = 30,
    ): Box? {
        val n = gw * gh
        if (n == 0 || px.size < n) return null

        val hit = BooleanArray(n)
        var any = false
        for (i in 0 until n) {
            val c = px[i]
            if (near(c, GREEN, tol) || near(c, RED, tol)) {
                hit[i] = true
                any = true
            }
        }
        if (!any) return null

        val seen = BooleanArray(n)
        val stack = IntArray(n)
        val haveHint = hintCx >= 0f && hintCy >= 0f
        val maxDist = 0.16f * max(gw, gh) // Android's idea may be off by a status bar, not by half the screen

        var best: Box? = null
        var bestScore = -1e9f

        for (start in 0 until n) {
            if (!hit[start] || seen[start]) continue

            var sp = 0
            stack[sp++] = start
            seen[start] = true
            var count = 0
            var minX = gw
            var maxX = 0
            var minY = gh
            var maxY = 0

            while (sp > 0) {
                val cur = stack[--sp]
                val x = cur % gw
                val y = cur / gw
                count++
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                if (x > 0 && hit[cur - 1] && !seen[cur - 1]) {
                    seen[cur - 1] = true
                    stack[sp++] = cur - 1
                }
                if (x < gw - 1 && hit[cur + 1] && !seen[cur + 1]) {
                    seen[cur + 1] = true
                    stack[sp++] = cur + 1
                }
                if (y > 0 && hit[cur - gw] && !seen[cur - gw]) {
                    seen[cur - gw] = true
                    stack[sp++] = cur - gw
                }
                if (y < gh - 1 && hit[cur + gw] && !seen[cur + gw]) {
                    seen[cur + gw] = true
                    stack[sp++] = cur + gw
                }
            }

            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            if (bw < 5 || bh < 4) continue
            val fill = count.toFloat() / (bw * bh)
            if (fill < 0.35f) continue // the button is a solid pill with only the label cut out of it
            if (bw < bh) continue // our button is wider than tall

            if (expectW > 0f && expectH > 0f) {
                if (bw < expectW * 0.55f || bw > expectW * 1.8f) continue
                if (bh < expectH * 0.55f || bh > expectH * 1.8f) continue
            }

            val box = Box(minX, minY, maxX + 1, maxY + 1)
            var score = count.toFloat() / n // bigger solid area wins when there is no hint
            if (haveHint) {
                val dx = box.cx - hintCx
                val dy = box.cy - hintCy
                val d = sqrt(dx * dx + dy * dy)
                if (d > maxDist) continue
                score = -d
            }
            if (score > bestScore) {
                bestScore = score
                best = box
            }
        }
        return best
    }

    /**
     * Turns the found button into the whole chip box. [apiBox] and [apiBtn] are where Android says the
     * chip and its button are (same coordinate system as each other). Only the button's real position
     * and size are trusted from the screenshot, the layout around it comes from Android.
     * All numbers are in pixels of the same frame.
     */
    fun chipFromButton(
        found: Box,
        apiBox: IntArray,
        apiBtn: IntArray,
    ): IntArray {
        val bw = (apiBtn[2] - apiBtn[0]).coerceAtLeast(1)
        val s = (found.w.toFloat() / bw).coerceIn(0.5f, 2f)
        val left = found.l + ((apiBox[0] - apiBtn[0]) * s).toInt()
        val top = found.t + ((apiBox[1] - apiBtn[1]) * s).toInt()
        val right = found.l + ((apiBox[2] - apiBtn[0]) * s).toInt()
        val bottom = found.t + ((apiBox[3] - apiBtn[1]) * s).toInt()
        return intArrayOf(left, top, right, bottom)
    }

    /** True if (x, y) is inside any of the pixel rects [l, t, r, b], grown by [margin] pixels. */
    fun hitsAny(x: Float, y: Float, rects: List<IntArray>, margin: Int): Boolean {
        for (r in rects) {
            if (x >= r[0] - margin && x <= r[2] + margin && y >= r[1] - margin && y <= r[3] + margin) return true
        }
        return false
    }
}
