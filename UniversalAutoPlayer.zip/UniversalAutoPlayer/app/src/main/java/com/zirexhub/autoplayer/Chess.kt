package com.zirexhub.autoplayer

import kotlin.math.abs

/**
 * Chess rules and a small engine (pure Kotlin, no Android, tested with the standard "perft" move counts).
 *
 * Why it exists: in a real game the AI picked its own chess moves and often got them wrong: it called a knight on e5 "a knight
 * on e4", moved a bishop straight forward, or "captured" a piece that was not there. A vision AI reads a board well (what stands
 * where) but plays chess badly. So the AI only READS the position (as a FEN) and this engine picks the move: legal by
 * construction, never leaves a piece hanging within its search depth, takes free material, finds mates in a few moves.
 *
 * Squares: 0..63 = rank * 8 + file, rank 0 = the "1" rank, file 0 = the "a" file. Pieces: +1..+6 = white P N B R Q K, negative =
 * black. A move is an Int: from | to << 6 | promotion piece type << 12 (0 = none).
 */
class ChessPos {
    val b = IntArray(64)
    var side = 1 // 1 = white to move, -1 = black
    var castle = 0 // 1 white O-O, 2 white O-O-O, 4 black O-O, 8 black O-O-O
    var ep = -1 // the square a pawn can capture onto en passant, or -1
    private val king = intArrayOf(-1, -1) // [0] white, [1] black

    // undo stack
    private val uPiece = IntArray(MAX_PLY)
    private val uCap = IntArray(MAX_PLY)
    private val uCapSq = IntArray(MAX_PLY)
    private val uCastle = IntArray(MAX_PLY)
    private val uEp = IntArray(MAX_PLY)
    private var sp = 0

    fun copy(): ChessPos {
        val c = ChessPos()
        System.arraycopy(b, 0, c.b, 0, 64)
        c.side = side
        c.castle = castle
        c.ep = ep
        c.king[0] = king[0]
        c.king[1] = king[1]
        return c
    }

    fun kingSq(color: Int): Int = king[if (color > 0) 0 else 1]

    fun refreshKings() {
        king[0] = -1
        king[1] = -1
        for (i in 0 until 64) {
            if (b[i] == 6) king[0] = i
            if (b[i] == -6) king[1] = i
        }
    }

    // ------------------------------------------------------------------ FEN

    companion object {
        const val MAX_PLY = 128
        private val DIRS_N = arrayOf(intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(2, -1), intArrayOf(1, -2), intArrayOf(-1, -2), intArrayOf(-2, -1), intArrayOf(-2, 1), intArrayOf(-1, 2))
        private val DIRS_K = arrayOf(intArrayOf(1, 0), intArrayOf(1, 1), intArrayOf(0, 1), intArrayOf(-1, 1), intArrayOf(-1, 0), intArrayOf(-1, -1), intArrayOf(0, -1), intArrayOf(1, -1))
        private val DIRS_B = arrayOf(intArrayOf(1, 1), intArrayOf(-1, 1), intArrayOf(-1, -1), intArrayOf(1, -1))
        private val DIRS_R = arrayOf(intArrayOf(1, 0), intArrayOf(0, 1), intArrayOf(-1, 0), intArrayOf(0, -1))

        /** A FEN, e.g. "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" (only the placement is needed). Null if it is not one. */
        fun fromFen(fen: String): ChessPos? {
            val parts = fen.trim().split(Regex("\\s+"))
            val rows = parts[0].split('/')
            if (rows.size != 8) return null
            val p = ChessPos()
            for ((i, row) in rows.withIndex()) {
                val rank = 7 - i
                var file = 0
                for (ch in row) {
                    if (ch in '1'..'8') {
                        file += ch - '0'
                    } else {
                        val v = pieceOf(ch)
                        if (v == 0 || file > 7) return null
                        p.b[rank * 8 + file] = v
                        file++
                    }
                    if (file > 8) return null
                }
                if (file != 8) return null
            }
            p.side = if (parts.getOrNull(1) == "b") -1 else 1
            val c = parts.getOrNull(2) ?: "-"
            if ('K' in c) p.castle = p.castle or 1
            if ('Q' in c) p.castle = p.castle or 2
            if ('k' in c) p.castle = p.castle or 4
            if ('q' in c) p.castle = p.castle or 8
            val e = parts.getOrNull(3) ?: "-"
            if (e.length == 2 && e[0] in 'a'..'h' && e[1] in '1'..'8') p.ep = (e[1] - '1') * 8 + (e[0] - 'a')
            p.refreshKings()
            return p
        }

        fun pieceOf(ch: Char): Int = when (ch) {
            'P' -> 1; 'N' -> 2; 'B' -> 3; 'R' -> 4; 'Q' -> 5; 'K' -> 6
            'p' -> -1; 'n' -> -2; 'b' -> -3; 'r' -> -4; 'q' -> -5; 'k' -> -6
            else -> 0
        }

        fun charOf(v: Int): Char {
            val c = when (abs(v)) { 1 -> 'p'; 2 -> 'n'; 3 -> 'b'; 4 -> 'r'; 5 -> 'q'; 6 -> 'k'; else -> '?' }
            return if (v > 0) c.uppercaseChar() else c
        }

        fun name(sq: Int): String = "${'a' + (sq and 7)}${'1' + (sq shr 3)}"

        fun uci(m: Int): String {
            val promo = (m shr 12) and 7
            return name(m and 63) + name((m shr 6) and 63) + (if (promo != 0) "nbrq"[promo - 2].toString() else "")
        }

        fun move(from: Int, to: Int, promo: Int = 0): Int = from or (to shl 6) or (promo shl 12)
    }

    fun toFen(): String = buildString {
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val v = b[rank * 8 + file]
                if (v == 0) {
                    empty++
                } else {
                    if (empty > 0) append(empty)
                    empty = 0
                    append(charOf(v))
                }
            }
            if (empty > 0) append(empty)
            if (rank > 0) append('/')
        }
        append(if (side > 0) " w " else " b ")
        val c = (if (castle and 1 != 0) "K" else "") + (if (castle and 2 != 0) "Q" else "") + (if (castle and 4 != 0) "k" else "") + (if (castle and 8 != 0) "q" else "")
        append(if (c.isEmpty()) "-" else c)
        append(' ')
        append(if (ep >= 0) name(ep) else "-")
    }

    /** Placement and side only: what makes two positions the same for "have I been here before". */
    fun key(): String = toFen().substringBeforeLast(' ').substringBeforeLast(' ')

    // ------------------------------------------------------------------ attacks

    /** Is [sq] attacked by a piece of colour [by] (1 or -1)? */
    fun attacked(sq: Int, by: Int): Boolean {
        val f = sq and 7
        val r = sq shr 3
        // pawns: a pawn of colour `by` standing one rank behind (from its own point of view) and one file aside
        val pr = r - by
        if (pr in 0..7) {
            if (f > 0 && b[pr * 8 + f - 1] == by) return true
            if (f < 7 && b[pr * 8 + f + 1] == by) return true
        }
        for (d in DIRS_N) {
            val nf = f + d[0]
            val nr = r + d[1]
            if (nf in 0..7 && nr in 0..7 && b[nr * 8 + nf] == 2 * by) return true
        }
        for (d in DIRS_K) {
            val nf = f + d[0]
            val nr = r + d[1]
            if (nf in 0..7 && nr in 0..7 && b[nr * 8 + nf] == 6 * by) return true
        }
        for (d in DIRS_B) {
            var nf = f + d[0]
            var nr = r + d[1]
            while (nf in 0..7 && nr in 0..7) {
                val v = b[nr * 8 + nf]
                if (v != 0) {
                    if (v == 3 * by || v == 5 * by) return true
                    break
                }
                nf += d[0]
                nr += d[1]
            }
        }
        for (d in DIRS_R) {
            var nf = f + d[0]
            var nr = r + d[1]
            while (nf in 0..7 && nr in 0..7) {
                val v = b[nr * 8 + nf]
                if (v != 0) {
                    if (v == 4 * by || v == 5 * by) return true
                    break
                }
                nf += d[0]
                nr += d[1]
            }
        }
        return false
    }

    fun inCheck(color: Int = side): Boolean {
        val k = kingSq(color)
        return k >= 0 && attacked(k, -color)
    }

    // ------------------------------------------------------------------ move generation

    /** Pseudo-legal moves (the own king may be left in check: [legal] filters them) into [out]; returns how many. */
    fun gen(out: IntArray, capturesOnly: Boolean = false): Int {
        var n = 0
        val me = side
        for (from in 0 until 64) {
            val v = b[from]
            if (v == 0 || (v > 0) != (me > 0)) continue
            val t = abs(v)
            val f = from and 7
            val r = from shr 3
            when (t) {
                1 -> {
                    val promoRank = if (me > 0) 6 else 1 // the rank a pawn stands on one step before promoting
                    val startRank = if (me > 0) 1 else 6
                    val one = from + 8 * me
                    if (one in 0..63 && b[one] == 0) {
                        if (r == promoRank) {
                            for (pr in 5 downTo 2) out[n++] = move(from, one, pr)
                        } else if (!capturesOnly) {
                            out[n++] = move(from, one)
                            val two = from + 16 * me
                            if (r == startRank && b[two] == 0) out[n++] = move(from, two)
                        }
                    }
                    for (df in intArrayOf(-1, 1)) {
                        val nf = f + df
                        val nr = r + me
                        if (nf !in 0..7 || nr !in 0..7) continue
                        val to = nr * 8 + nf
                        val target = b[to]
                        if (target != 0 && (target > 0) != (me > 0)) {
                            if (r == promoRank) {
                                for (pr in 5 downTo 2) out[n++] = move(from, to, pr)
                            } else {
                                out[n++] = move(from, to)
                            }
                        } else if (target == 0 && to == ep) {
                            out[n++] = move(from, to)
                        }
                    }
                }
                2, 6 -> {
                    val dirs = if (t == 2) DIRS_N else DIRS_K
                    for (d in dirs) {
                        val nf = f + d[0]
                        val nr = r + d[1]
                        if (nf !in 0..7 || nr !in 0..7) continue
                        val to = nr * 8 + nf
                        val target = b[to]
                        if (target == 0) {
                            if (!capturesOnly) out[n++] = move(from, to)
                        } else if ((target > 0) != (me > 0)) {
                            out[n++] = move(from, to)
                        }
                    }
                    if (t == 6 && !capturesOnly) n = genCastle(out, n, from, me)
                }
                else -> {
                    val bishop = t == 3 || t == 5
                    val rook = t == 4 || t == 5
                    if (bishop) n = slide(out, n, from, DIRS_B, me, capturesOnly)
                    if (rook) n = slide(out, n, from, DIRS_R, me, capturesOnly)
                }
            }
        }
        return n
    }

    private fun slide(out: IntArray, start: Int, from: Int, dirs: Array<IntArray>, me: Int, capturesOnly: Boolean): Int {
        var n = start
        val f = from and 7
        val r = from shr 3
        for (d in dirs) {
            var nf = f + d[0]
            var nr = r + d[1]
            while (nf in 0..7 && nr in 0..7) {
                val to = nr * 8 + nf
                val target = b[to]
                if (target == 0) {
                    if (!capturesOnly) out[n++] = move(from, to)
                } else {
                    if ((target > 0) != (me > 0)) out[n++] = move(from, to)
                    break
                }
                nf += d[0]
                nr += d[1]
            }
        }
        return n
    }

    private fun genCastle(out: IntArray, start: Int, from: Int, me: Int): Int {
        var n = start
        val home = if (me > 0) 4 else 60
        if (from != home) return n
        val kingSide = if (me > 0) 1 else 4
        val queenSide = if (me > 0) 2 else 8
        val rookV = 4 * me
        if (castle and (kingSide or queenSide) == 0) return n
        if (attacked(from, -me)) return n
        if (castle and kingSide != 0 && b[home + 3] == rookV && b[home + 1] == 0 && b[home + 2] == 0 &&
            !attacked(home + 1, -me) && !attacked(home + 2, -me)
        ) {
            out[n++] = move(from, home + 2)
        }
        if (castle and queenSide != 0 && b[home - 4] == rookV && b[home - 1] == 0 && b[home - 2] == 0 && b[home - 3] == 0 &&
            !attacked(home - 1, -me) && !attacked(home - 2, -me)
        ) {
            out[n++] = move(from, home - 2)
        }
        return n
    }

    // ------------------------------------------------------------------ make / unmake

    fun make(m: Int) {
        val from = m and 63
        val to = (m shr 6) and 63
        val promo = (m shr 12) and 7
        val piece = b[from]
        val t = abs(piece)
        var cap = b[to]
        var capSq = to
        uPiece[sp] = piece
        uCastle[sp] = castle
        uEp[sp] = ep
        if (t == 1 && to == ep && (from and 7) != (to and 7) && cap == 0) {
            capSq = if (side > 0) to - 8 else to + 8
            cap = b[capSq]
            b[capSq] = 0
        }
        uCap[sp] = cap
        uCapSq[sp] = capSq
        sp++
        b[to] = if (promo != 0) side * promo else piece
        b[from] = 0
        if (t == 6) {
            king[if (side > 0) 0 else 1] = to
            if (to - from == 2) {
                b[to - 1] = b[to + 1]
                b[to + 1] = 0
            } else if (from - to == 2) {
                b[to + 1] = b[to - 2]
                b[to - 2] = 0
            }
        }
        // castling rights go when a king or rook moves, or a rook is taken on its square
        castle = castle and RIGHTS_KEEP[from] and RIGHTS_KEEP[to]
        ep = if (t == 1 && abs(to - from) == 16) (from + to) / 2 else -1
        side = -side
    }

    fun unmake(m: Int) {
        sp--
        side = -side
        val from = m and 63
        val to = (m shr 6) and 63
        val piece = uPiece[sp]
        val cap = uCap[sp]
        val capSq = uCapSq[sp]
        castle = uCastle[sp]
        ep = uEp[sp]
        val t = abs(piece)
        b[from] = piece
        b[to] = 0
        if (cap != 0) b[capSq] = cap
        if (t == 6) {
            king[if (side > 0) 0 else 1] = from
            if (to - from == 2) {
                b[to + 1] = b[to - 1]
                b[to - 1] = 0
            } else if (from - to == 2) {
                b[to - 2] = b[to + 1]
                b[to + 1] = 0
            }
        }
    }

    /** Fills [out] with the legal moves, returns how many. */
    fun legal(out: IntArray): Int {
        val tmp = IntArray(256)
        val n = gen(tmp)
        var k = 0
        val me = side
        for (i in 0 until n) {
            val m = tmp[i]
            make(m)
            val ok = !inCheck(me)
            unmake(m)
            if (ok) out[k++] = m
        }
        return k
    }

    /** Counts the leaf positions [depth] plies deep (the standard test of a move generator). */
    fun perft(depth: Int): Long {
        if (depth == 0) return 1L
        val tmp = IntArray(256)
        val n = gen(tmp)
        var total = 0L
        val me = side
        for (i in 0 until n) {
            val m = tmp[i]
            make(m)
            if (!inCheck(me)) total += if (depth == 1) 1L else perft(depth - 1)
            unmake(m)
        }
        return total
    }
}

private val RIGHTS_KEEP = IntArray(64) { sq ->
    when (sq) {
        0 -> 15 and 2.inv()
        7 -> 15 and 1.inv()
        4 -> 15 and 3.inv()
        56 -> 15 and 8.inv()
        63 -> 15 and 4.inv()
        60 -> 15 and 12.inv()
        else -> 15
    }
}

/** The result of a search. [score] is in centipawns from the point of view of the side to move; mates are about +-30000. */
class ChessChoice(val move: Int, val score: Int, val depth: Int, val nodes: Long) {
    val uci: String get() = ChessPos.uci(move)
}

/** A small alpha-beta searcher with iterative deepening, quiescence and a time limit. */
class ChessEngine(private val clock: () -> Long) {

    private var deadline = 0L
    private var stop = false
    private var nodes = 0L
    private val killers = Array(MAX_DEPTH + 2) { IntArray(2) }
    private val bufs = Array(MAX_DEPTH + 40) { IntArray(256) }
    private val scores = Array(MAX_DEPTH + 40) { IntArray(256) }

    /**
     * The best move for the side to move, or null when there is none (checkmate, stalemate) or every move is in [exclude]
     * (as UCI text, "e2e4"). [avoid] holds position keys ([ChessPos.key]) seen before: a move into one costs a little, so a
     * game does not shuffle back and forth.
     */
    fun best(root: ChessPos, timeMs: Long, maxDepth: Int = 6, exclude: Set<String> = emptySet(), avoid: Set<String> = emptySet()): ChessChoice? {
        val pos = root.copy()
        val all = IntArray(256)
        val n = pos.legal(all)
        val moves = ArrayList<Int>()
        for (i in 0 until n) if (ChessPos.uci(all[i]) !in exclude) moves.add(all[i])
        if (moves.isEmpty()) return null
        if (moves.size == 1) return ChessChoice(moves[0], 0, 0, 0)

        val realDeadline = clock() + timeMs
        deadline = Long.MAX_VALUE // depth 1 always finishes: a move is always found
        stop = false
        nodes = 0
        for (k in killers) { k[0] = 0; k[1] = 0 }
        orderRoot(pos, moves)
        var bestMove = moves[0]
        var bestScore = -INF
        var doneDepth = 0
        for (depth in 1..maxDepth.coerceAtMost(MAX_DEPTH)) {
            var alpha = -INF
            var iterBest = -1
            var iterScore = -INF
            for (m in moves) {
                pos.make(m)
                var s = -negamax(pos, depth - 1, -INF, -alpha, 1)
                // "later" looks as good as "now" for any move that wins something for sure (a promotion could be put off for
                // ever by a search that sees the same material at its horizon): now is better
                if ((m shr 12) and 7 != 0) s += PROMOTE_NOW
                if (avoid.isNotEmpty() && pos.key() in avoid) s -= REPEAT_PENALTY
                pos.unmake(m)
                if (stop) break
                if (s > iterScore) {
                    iterScore = s
                    iterBest = m
                }
                if (s > alpha) alpha = s
            }
            if (stop) {
                // a half finished depth still counts when it already found something better than the last full one
                if (iterBest >= 0 && iterScore > bestScore && doneDepth > 0) {
                    bestMove = iterBest
                    bestScore = iterScore
                }
                break
            }
            bestMove = iterBest
            bestScore = iterScore
            doneDepth = depth
            deadline = realDeadline
            moves.remove(iterBest)
            moves.add(0, iterBest) // the best move first at the next depth
            if (abs(bestScore) > MATE - 100) break // mate found
            if (clock() >= realDeadline) break
        }
        return ChessChoice(bestMove, bestScore, doneDepth, nodes)
    }

    private fun orderRoot(pos: ChessPos, moves: ArrayList<Int>) {
        val sc = HashMap<Int, Int>()
        for (m in moves) sc[m] = moveScore(pos, m, 0)
        moves.sortByDescending { sc[it] }
    }

    private fun moveScore(pos: ChessPos, m: Int, ply: Int): Int {
        val from = m and 63
        val to = (m shr 6) and 63
        val promo = (m shr 12) and 7
        val victim = abs(pos.b[to])
        val attacker = abs(pos.b[from])
        var s = 0
        if (victim != 0) s += 10_000 + VALUE[victim] * 10 - VALUE[attacker]
        else if (attacker == 1 && to == pos.ep && (from and 7) != (to and 7)) s += 10_000 + 1000 - 100
        if (promo != 0) s += 9_000 + VALUE[promo]
        if (ply < killers.size && (m == killers[ply][0] || m == killers[ply][1])) s += 5_000
        return s
    }

    private fun negamax(pos: ChessPos, depthIn: Int, alphaIn: Int, beta: Int, ply: Int): Int {
        if ((++nodes and 1023L) == 0L && clock() >= deadline) stop = true
        if (stop) return 0
        var depth = depthIn
        val me = pos.side
        val check = pos.inCheck(me)
        if (check && ply < MAX_DEPTH + 10) depth++
        if (depth <= 0) return quiesce(pos, alphaIn, beta, ply)
        var alpha = alphaIn
        val buf = bufs[ply]
        val n = pos.gen(buf)
        val sc = scores[ply]
        for (i in 0 until n) sc[i] = moveScore(pos, buf[i], ply)
        var legalCount = 0
        var best = -INF
        for (i in 0 until n) {
            // selection sort: the best of the rest to the front
            var bi = i
            for (j in i + 1 until n) if (sc[j] > sc[bi]) bi = j
            if (bi != i) {
                val tm = buf[i]; buf[i] = buf[bi]; buf[bi] = tm
                val ts = sc[i]; sc[i] = sc[bi]; sc[bi] = ts
            }
            val m = buf[i]
            pos.make(m)
            if (pos.inCheck(me)) {
                pos.unmake(m)
                continue
            }
            legalCount++
            val s = -negamax(pos, depth - 1, -beta, -alpha, ply + 1)
            pos.unmake(m)
            if (stop) return 0
            if (s > best) best = s
            if (s > alpha) {
                alpha = s
                if (alpha >= beta) {
                    if (pos.b[(m shr 6) and 63] == 0 && ply < killers.size && killers[ply][0] != m) {
                        killers[ply][1] = killers[ply][0]
                        killers[ply][0] = m
                    }
                    break
                }
            }
        }
        if (legalCount == 0) return if (check) -MATE + ply else 0
        return best
    }

    private fun quiesce(pos: ChessPos, alphaIn: Int, beta: Int, ply: Int): Int {
        if ((++nodes and 1023L) == 0L && clock() >= deadline) stop = true
        if (stop) return 0
        var alpha = alphaIn
        val stand = evaluate(pos)
        if (stand >= beta) return stand
        if (stand > alpha) alpha = stand
        if (ply >= bufs.size - 1) return stand
        val me = pos.side
        val buf = bufs[ply]
        val n = pos.gen(buf, capturesOnly = true)
        val sc = scores[ply]
        for (i in 0 until n) sc[i] = moveScore(pos, buf[i], 1000)
        var best = stand
        for (i in 0 until n) {
            var bi = i
            for (j in i + 1 until n) if (sc[j] > sc[bi]) bi = j
            if (bi != i) {
                val tm = buf[i]; buf[i] = buf[bi]; buf[bi] = tm
                val ts = sc[i]; sc[i] = sc[bi]; sc[bi] = ts
            }
            val m = buf[i]
            pos.make(m)
            if (pos.inCheck(me)) {
                pos.unmake(m)
                continue
            }
            val s = -quiesce(pos, -beta, -alpha, ply + 1)
            pos.unmake(m)
            if (stop) return 0
            if (s > best) best = s
            if (s > alpha) {
                alpha = s
                if (alpha >= beta) break
            }
        }
        return best
    }

    /** Material and square values, in centipawns, from the point of view of the side to move. */
    fun evaluate(pos: ChessPos): Int {
        var score = 0
        var nonPawn = 0
        var queens = 0
        var wBishops = 0
        var bBishops = 0
        for (sq in 0 until 64) {
            val v = pos.b[sq]
            if (v == 0) continue
            val t = abs(v)
            if (t in 2..5) nonPawn += VALUE[t]
            if (t == 5) queens++
            if (v == 3) wBishops++
            if (v == -3) bBishops++
        }
        val endgame = queens == 0 || nonPawn < 2600
        for (sq in 0 until 64) {
            val v = pos.b[sq]
            if (v == 0) continue
            val t = abs(v)
            val f = sq and 7
            val r = sq shr 3
            // the tables are written as seen by white with rank 8 on top
            val idx = if (v > 0) (7 - r) * 8 + f else r * 8 + f
            val table = if (t == 6 && endgame) PST_KING_END else PST[t]
            val s = VALUE[t] + table[idx]
            score += if (v > 0) s else -s
        }
        if (wBishops >= 2) score += 30
        if (bBishops >= 2) score -= 30
        return if (pos.side > 0) score else -score
    }

    companion object {
        const val INF = 1_000_000
        const val MATE = 30_000
        const val MAX_DEPTH = 12
        const val REPEAT_PENALTY = 40
        const val PROMOTE_NOW = 40

        val VALUE = intArrayOf(0, 100, 320, 330, 500, 900, 20_000)

        private val PST_P = intArrayOf(
            0, 0, 0, 0, 0, 0, 0, 0,
            50, 50, 50, 50, 50, 50, 50, 50,
            10, 10, 20, 30, 30, 20, 10, 10,
            5, 5, 10, 25, 25, 10, 5, 5,
            0, 0, 0, 20, 20, 0, 0, 0,
            5, -5, -10, 0, 0, -10, -5, 5,
            5, 10, 10, -20, -20, 10, 10, 5,
            0, 0, 0, 0, 0, 0, 0, 0,
        )
        private val PST_N = intArrayOf(
            -50, -40, -30, -30, -30, -30, -40, -50,
            -40, -20, 0, 0, 0, 0, -20, -40,
            -30, 0, 10, 15, 15, 10, 0, -30,
            -30, 5, 15, 20, 20, 15, 5, -30,
            -30, 0, 15, 20, 20, 15, 0, -30,
            -30, 5, 10, 15, 15, 10, 5, -30,
            -40, -20, 0, 5, 5, 0, -20, -40,
            -50, -40, -30, -30, -30, -30, -40, -50,
        )
        private val PST_B = intArrayOf(
            -20, -10, -10, -10, -10, -10, -10, -20,
            -10, 0, 0, 0, 0, 0, 0, -10,
            -10, 0, 5, 10, 10, 5, 0, -10,
            -10, 5, 5, 10, 10, 5, 5, -10,
            -10, 0, 10, 10, 10, 10, 0, -10,
            -10, 10, 10, 10, 10, 10, 10, -10,
            -10, 5, 0, 0, 0, 0, 5, -10,
            -20, -10, -10, -10, -10, -10, -10, -20,
        )
        private val PST_R = intArrayOf(
            0, 0, 0, 0, 0, 0, 0, 0,
            5, 10, 10, 10, 10, 10, 10, 5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            0, 0, 0, 5, 5, 0, 0, 0,
        )
        private val PST_Q = intArrayOf(
            -20, -10, -10, -5, -5, -10, -10, -20,
            -10, 0, 0, 0, 0, 0, 0, -10,
            -10, 0, 5, 5, 5, 5, 0, -10,
            -5, 0, 5, 5, 5, 5, 0, -5,
            0, 0, 5, 5, 5, 5, 0, -5,
            -10, 5, 5, 5, 5, 5, 0, -10,
            -10, 0, 5, 0, 0, 0, 0, -10,
            -20, -10, -10, -5, -5, -10, -10, -20,
        )
        private val PST_K = intArrayOf(
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -20, -30, -30, -40, -40, -30, -30, -20,
            -10, -20, -20, -20, -20, -20, -20, -10,
            20, 20, 0, 0, 0, 0, 20, 20,
            20, 30, 10, 0, 0, 10, 30, 20,
        )
        private val PST_KING_END = intArrayOf(
            -50, -40, -30, -20, -20, -30, -40, -50,
            -30, -20, -10, 0, 0, -10, -20, -30,
            -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30,
            -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -30, 0, 0, 0, 0, -30, -30,
            -50, -30, -30, -30, -30, -30, -30, -50,
        )
        private val PST = arrayOf(IntArray(64), PST_P, PST_N, PST_B, PST_R, PST_Q, PST_K)
    }
}
