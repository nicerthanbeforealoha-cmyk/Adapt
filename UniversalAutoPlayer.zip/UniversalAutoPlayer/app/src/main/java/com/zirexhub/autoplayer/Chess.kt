package com.zirexhub.autoplayer

import kotlin.math.abs

/**
 * Chess rules (pure Kotlin, no Android, tested with the standard "perft" move counts). The engine that chooses moves is in
 * ChessEngine.kt, the opening book in OpeningBook.kt.
 *
 * Why it exists: in a real game the AI picked its own chess moves and often got them wrong: it called a knight on e5 "a knight
 * on e4", moved a bishop straight forward, or "captured" a piece that was not there. A vision AI reads a board well (what stands
 * where) but plays chess badly. So the screen reader only READS the position and this code plays: legal by construction.
 *
 * Squares: 0..63 = rank * 8 + file, rank 0 = the "1" rank, file 0 = the "a" file. Pieces: +1..+6 = white P N B R Q K, negative =
 * black. A move is an Int: from | to << 6 | promotion piece type << 12 (0 = none).
 */
object ChessTables {
    /** Squares a knight / king on a square can go to. */
    @JvmField val KN: Array<IntArray>
    @JvmField val KG: Array<IntArray>

    /** PAT[0][sq] = the squares a WHITE pawn on sq attacks, PAT[1][sq] = the squares a BLACK pawn on sq attacks. */
    @JvmField val PAT: Array<Array<IntArray>>

    /** RAYS[sq * 8 + dir]: the squares from sq outwards. dir 0 N, 1 NE, 2 E, 3 SE, 4 S, 5 SW, 6 W, 7 NW (odd = diagonal). */
    @JvmField val RAYS: Array<IntArray>

    @JvmField val Z: LongArray = LongArray(13 * 64) // piece (+6) * 64 + square
    @JvmField val ZS: Long
    @JvmField val ZC: LongArray = LongArray(16)
    @JvmField val ZE: LongArray = LongArray(8)

    /** Material + square value for a piece (+6) on a square, from white's point of view (black pieces are negative). */
    @JvmField val MGT: IntArray = IntArray(13 * 64)
    @JvmField val EGT: IntArray = IntArray(13 * 64)

    /** How much a piece type counts for the game phase (24 = all pieces on). */
    @JvmField val PHASE = intArrayOf(0, 0, 1, 1, 2, 4, 0)

    @JvmField val RIGHTS_KEEP = IntArray(64) { sq ->
        when (sq) {
            0 -> 15 and 2.inv()
            7 -> 15 and 1.inv()
            4 -> 15 and 3.inv()
            56 -> 15 and 8.inv()
            63 -> 15 and 4.inv()
            60 -> 15 and 12.inv()
            else -> 15
        }
    }

    private val DF = intArrayOf(0, 1, 1, 1, 0, -1, -1, -1)
    private val DR = intArrayOf(1, 1, 0, -1, -1, -1, 0, 1)

    init {
        val kn = Array(64) { IntArray(0) }
        val kg = Array(64) { IntArray(0) }
        val pw = Array(64) { IntArray(0) }
        val pb = Array(64) { IntArray(0) }
        val rays = Array(64 * 8) { IntArray(0) }
        val kd = arrayOf(intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(2, -1), intArrayOf(1, -2), intArrayOf(-1, -2), intArrayOf(-2, -1), intArrayOf(-2, 1), intArrayOf(-1, 2))
        for (sq in 0 until 64) {
            val f = sq and 7
            val r = sq shr 3
            val l1 = ArrayList<Int>()
            for (d in kd) { val nf = f + d[0]; val nr = r + d[1]; if (nf in 0..7 && nr in 0..7) l1.add(nr * 8 + nf) }
            kn[sq] = l1.toIntArray()
            val l2 = ArrayList<Int>()
            for (dir in 0 until 8) { val nf = f + DF[dir]; val nr = r + DR[dir]; if (nf in 0..7 && nr in 0..7) l2.add(nr * 8 + nf) }
            kg[sq] = l2.toIntArray()
            val l3 = ArrayList<Int>()
            val l4 = ArrayList<Int>()
            for (df in intArrayOf(-1, 1)) {
                if (f + df in 0..7 && r + 1 in 0..7) l3.add((r + 1) * 8 + f + df)
                if (f + df in 0..7 && r - 1 in 0..7) l4.add((r - 1) * 8 + f + df)
            }
            pw[sq] = l3.toIntArray()
            pb[sq] = l4.toIntArray()
            for (dir in 0 until 8) {
                val l = ArrayList<Int>()
                var nf = f + DF[dir]
                var nr = r + DR[dir]
                while (nf in 0..7 && nr in 0..7) { l.add(nr * 8 + nf); nf += DF[dir]; nr += DR[dir] }
                rays[sq * 8 + dir] = l.toIntArray()
            }
        }
        KN = kn; KG = kg; PAT = arrayOf(pw, pb); RAYS = rays

        // Zobrist keys (fixed seed: the same numbers on every run, so tests and the book agree)
        var x = 0x9E3779B97F4A7C15uL.toLong()
        fun next(): Long {
            x = x xor (x shl 13); x = x xor (x ushr 7); x = x xor (x shl 17)
            return x * 0x2545F4914F6CDD1DL
        }
        for (i in Z.indices) Z[i] = next()
        for (i in 0 until 13) for (sq in 0 until 64) if (i == 6) Z[i * 64 + sq] = 0L
        ZS = next()
        for (i in ZC.indices) ZC[i] = next()
        for (i in ZE.indices) ZE[i] = next()

        // piece-square tables
        val matMg = intArrayOf(0, 100, 325, 340, 500, 975, 0)
        val matEg = intArrayOf(0, 115, 300, 315, 520, 940, 0)
        val mg = arrayOf(IntArray(64), PST_P, PST_N, PST_B, PST_R, PST_Q, PST_K)
        val eg = arrayOf(IntArray(64), PST_P_EG, PST_N_EG, PST_B, PST_R, PST_Q_EG, PST_KING_END)
        for (t in 1..6) for (sq in 0 until 64) {
            val r = sq shr 3
            val f = sq and 7
            val iw = (7 - r) * 8 + f // the tables are written as seen by white with rank 8 on top
            val ib = r * 8 + f
            MGT[(t + 6) * 64 + sq] = matMg[t] + mg[t][iw]
            EGT[(t + 6) * 64 + sq] = matEg[t] + eg[t][iw]
            MGT[(6 - t) * 64 + sq] = -(matMg[t] + mg[t][ib])
            EGT[(6 - t) * 64 + sq] = -(matEg[t] + eg[t][ib])
        }
    }

    private val PST_P get() = P_MG
    private val PST_N get() = N_MG
    private val PST_B get() = B_MG
    private val PST_R get() = R_MG
    private val PST_Q get() = Q_MG
    private val PST_K get() = K_MG
    private val PST_P_EG get() = P_EG
    private val PST_N_EG get() = N_EG
    private val PST_Q_EG get() = Q_EG
    private val PST_KING_END get() = K_EG
}

private val P_MG = intArrayOf(
    0, 0, 0, 0, 0, 0, 0, 0,
    50, 50, 50, 50, 50, 50, 50, 50,
    10, 10, 20, 30, 30, 20, 10, 10,
    5, 5, 10, 25, 25, 10, 5, 5,
    0, 0, 0, 20, 20, 0, 0, 0,
    5, -5, -10, 0, 0, -10, -5, 5,
    5, 10, 10, -20, -20, 10, 10, 5,
    0, 0, 0, 0, 0, 0, 0, 0,
)
private val P_EG = intArrayOf(
    0, 0, 0, 0, 0, 0, 0, 0,
    70, 70, 70, 70, 70, 70, 70, 70,
    35, 35, 35, 35, 35, 35, 35, 35,
    18, 18, 18, 18, 18, 18, 18, 18,
    8, 8, 8, 8, 8, 8, 8, 8,
    3, 3, 3, 3, 3, 3, 3, 3,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
)
private val N_MG = intArrayOf(
    -50, -40, -30, -30, -30, -30, -40, -50,
    -40, -20, 0, 0, 0, 0, -20, -40,
    -30, 0, 10, 15, 15, 10, 0, -30,
    -30, 5, 15, 20, 20, 15, 5, -30,
    -30, 0, 15, 20, 20, 15, 0, -30,
    -30, 5, 10, 15, 15, 10, 5, -30,
    -40, -20, 0, 5, 5, 0, -20, -40,
    -50, -40, -30, -30, -30, -30, -40, -50,
)
private val N_EG = intArrayOf(
    -60, -45, -35, -30, -30, -35, -45, -60,
    -45, -25, -5, 0, 0, -5, -25, -45,
    -35, -5, 10, 15, 15, 10, -5, -35,
    -30, 0, 15, 20, 20, 15, 0, -30,
    -30, 0, 15, 20, 20, 15, 0, -30,
    -35, -5, 10, 15, 15, 10, -5, -35,
    -45, -25, -5, 0, 0, -5, -25, -45,
    -60, -45, -35, -30, -30, -35, -45, -60,
)
private val B_MG = intArrayOf(
    -20, -10, -10, -10, -10, -10, -10, -20,
    -10, 0, 0, 0, 0, 0, 0, -10,
    -10, 0, 5, 10, 10, 5, 0, -10,
    -10, 5, 5, 10, 10, 5, 5, -10,
    -10, 0, 10, 10, 10, 10, 0, -10,
    -10, 10, 10, 10, 10, 10, 10, -10,
    -10, 5, 0, 0, 0, 0, 5, -10,
    -20, -10, -10, -10, -10, -10, -10, -20,
)
private val R_MG = intArrayOf(
    0, 0, 0, 0, 0, 0, 0, 0,
    5, 10, 10, 10, 10, 10, 10, 5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    0, 0, 0, 5, 5, 0, 0, 0,
)
private val Q_MG = intArrayOf(
    -20, -10, -10, -5, -5, -10, -10, -20,
    -10, 0, 0, 0, 0, 0, 0, -10,
    -10, 0, 5, 5, 5, 5, 0, -10,
    -5, 0, 5, 5, 5, 5, 0, -5,
    0, 0, 5, 5, 5, 5, 0, -5,
    -10, 5, 5, 5, 5, 5, 0, -10,
    -10, 0, 5, 0, 0, 0, 0, -10,
    -20, -10, -10, -5, -5, -10, -10, -20,
)
private val Q_EG = intArrayOf(
    -30, -20, -10, -10, -10, -10, -20, -30,
    -20, -5, 5, 5, 5, 5, -5, -20,
    -10, 5, 10, 12, 12, 10, 5, -10,
    -10, 5, 12, 15, 15, 12, 5, -10,
    -10, 5, 12, 15, 15, 12, 5, -10,
    -10, 5, 10, 12, 12, 10, 5, -10,
    -20, -5, 5, 5, 5, 5, -5, -20,
    -30, -20, -10, -10, -10, -10, -20, -30,
)
private val K_MG = intArrayOf(
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -20, -30, -30, -40, -40, -30, -30, -20,
    -10, -20, -20, -20, -20, -20, -20, -10,
    20, 20, 0, 0, 0, 0, 20, 20,
    20, 30, 10, 0, 0, 10, 30, 20,
)
private val K_EG = intArrayOf(
    -50, -40, -30, -20, -20, -30, -40, -50,
    -30, -20, -10, 0, 0, -10, -20, -30,
    -30, -10, 20, 30, 30, 20, -10, -30,
    -30, -10, 30, 40, 40, 30, -10, -30,
    -30, -10, 30, 40, 40, 30, -10, -30,
    -30, -10, 20, 30, 30, 20, -10, -30,
    -30, -30, 0, 0, 0, 0, -30, -30,
    -50, -30, -30, -30, -30, -30, -30, -50,
)

class ChessPos {
    @JvmField val b = IntArray(64)
    @JvmField var side = 1 // 1 = white to move, -1 = black
    @JvmField var castle = 0 // 1 white O-O, 2 white O-O-O, 4 black O-O, 8 black O-O-O
    @JvmField var ep = -1 // the square a pawn can capture onto en passant, or -1
    @JvmField var half = 0 // moves since the last capture or pawn move (the fifty-move rule counts these)

    /** Zobrist hash, kept up to date by make/unmake. Call [recompute] (or [refreshKings]) after changing [b], [side], [castle] or [ep] by hand. */
    @JvmField var hash = 0L
    @JvmField var mg = 0 // material + square values, white minus black (middle game / end game)
    @JvmField var eg = 0
    @JvmField var phase = 0
    private val king = intArrayOf(-1, -1) // [0] white, [1] black

    // undo stack (grows when a long game needs it)
    private var uPiece = IntArray(32)
    private var uCap = IntArray(32)
    private var uCapSq = IntArray(32)
    private var uCastle = IntArray(32)
    private var uEp = IntArray(32)
    private var uHalf = IntArray(32)
    private var uMg = IntArray(32)
    private var uEg = IntArray(32)
    private var uPh = IntArray(32)
    private var uHash = LongArray(32)
    private var sp = 0

    private fun grow() {
        val n = uPiece.size * 2
        uPiece = uPiece.copyOf(n); uCap = uCap.copyOf(n); uCapSq = uCapSq.copyOf(n); uCastle = uCastle.copyOf(n); uEp = uEp.copyOf(n)
        uHalf = uHalf.copyOf(n); uMg = uMg.copyOf(n); uEg = uEg.copyOf(n); uPh = uPh.copyOf(n); uHash = uHash.copyOf(n)
    }

    /** A copy of the position (without the undo history). */
    fun copy(): ChessPos {
        val c = ChessPos()
        System.arraycopy(b, 0, c.b, 0, 64)
        c.side = side
        c.castle = castle
        c.ep = ep
        c.half = half
        c.king[0] = king[0]
        c.king[1] = king[1]
        c.recompute()
        return c
    }

    fun kingSq(color: Int): Int = king[if (color > 0) 0 else 1]

    fun refreshKings() {
        king[0] = -1
        king[1] = -1
        for (i in 0 until 64) {
            if (b[i] == 6) king[0] = i
            if (b[i] == -6) king[1] = i
        }
        recompute()
    }

    /** Rebuilds the hash and the incremental scores from the board. */
    fun recompute() {
        var h = 0L
        var m = 0
        var e = 0
        var ph = 0
        for (sq in 0 until 64) {
            val v = b[sq]
            if (v == 0) continue
            val i = (v + 6) * 64 + sq
            h = h xor ChessTables.Z[i]
            m += ChessTables.MGT[i]
            e += ChessTables.EGT[i]
            ph += ChessTables.PHASE[abs(v)]
        }
        if (side < 0) h = h xor ChessTables.ZS
        h = h xor ChessTables.ZC[castle and 15]
        if (epHashed(side)) h = h xor ChessTables.ZE[ep and 7]
        hash = h
        mg = m
        eg = e
        phase = ph
    }

    /**
     * Is the en passant square part of the hash? Only when a pawn of [mover] (the side to move) really stands next to the pawn that
     * just moved two squares: then two positions that differ only by that square are the same position (transpositions match).
     */
    private fun epHashed(mover: Int): Boolean {
        if (ep < 0) return false
        val pawnSq = if (mover > 0) ep - 8 else ep + 8
        if (pawnSq < 1 || pawnSq > 62) return false
        val f = ep and 7
        return (f > 0 && b[pawnSq - 1] == mover) || (f < 7 && b[pawnSq + 1] == mover)
    }

    /** The position's hash, fresh (use it to remember positions of a game). */
    fun zobrist(): Long {
        recompute()
        return hash
    }

    // ------------------------------------------------------------------ FEN

    companion object {
        /** A FEN, e.g. "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" (only the placement is needed). Null if it is not one. */
        fun fromFen(fen: String): ChessPos? {
            val parts = fen.trim().split(Regex("\\s+"))
            val rows = parts[0].split('/')
            if (rows.size != 8) return null
            val p = ChessPos()
            for ((i, row) in rows.withIndex()) {
                val rank = 7 - i
                var file = 0
                for (ch in row) {
                    if (ch in '1'..'8') {
                        file += ch - '0'
                    } else {
                        val v = pieceOf(ch)
                        if (v == 0 || file > 7) return null
                        p.b[rank * 8 + file] = v
                        file++
                    }
                    if (file > 8) return null
                }
                if (file != 8) return null
            }
            p.side = if (parts.getOrNull(1) == "b") -1 else 1
            val c = parts.getOrNull(2) ?: "-"
            if ('K' in c) p.castle = p.castle or 1
            if ('Q' in c) p.castle = p.castle or 2
            if ('k' in c) p.castle = p.castle or 4
            if ('q' in c) p.castle = p.castle or 8
            val e = parts.getOrNull(3) ?: "-"
            if (e.length == 2 && e[0] in 'a'..'h' && e[1] in '1'..'8') p.ep = (e[1] - '1') * 8 + (e[0] - 'a')
            p.half = parts.getOrNull(4)?.toIntOrNull()?.coerceIn(0, 200) ?: 0
            p.refreshKings()
            return p
        }

        fun pieceOf(ch: Char): Int = when (ch) {
            'P' -> 1; 'N' -> 2; 'B' -> 3; 'R' -> 4; 'Q' -> 5; 'K' -> 6
            'p' -> -1; 'n' -> -2; 'b' -> -3; 'r' -> -4; 'q' -> -5; 'k' -> -6
            else -> 0
        }

        fun charOf(v: Int): Char {
            val c = when (abs(v)) { 1 -> 'p'; 2 -> 'n'; 3 -> 'b'; 4 -> 'r'; 5 -> 'q'; 6 -> 'k'; else -> '?' }
            return if (v > 0) c.uppercaseChar() else c
        }

        fun name(sq: Int): String = "${'a' + (sq and 7)}${'1' + (sq shr 3)}"

        fun uci(m: Int): String {
            val promo = (m shr 12) and 7
            return name(m and 63) + name((m shr 6) and 63) + (if (promo != 0) "nbrq"[promo - 2].toString() else "")
        }

        fun move(from: Int, to: Int, promo: Int = 0): Int = from or (to shl 6) or (promo shl 12)

        /** The start position of a game. */
        fun start(): ChessPos = fromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")!!
    }

    fun toFen(): String = buildString {
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val v = b[rank * 8 + file]
                if (v == 0) {
                    empty++
                } else {
                    if (empty > 0) append(empty)
                    empty = 0
                    append(charOf(v))
                }
            }
            if (empty > 0) append(empty)
            if (rank > 0) append('/')
        }
        append(if (side > 0) " w " else " b ")
        val c = (if (castle and 1 != 0) "K" else "") + (if (castle and 2 != 0) "Q" else "") + (if (castle and 4 != 0) "k" else "") + (if (castle and 8 != 0) "q" else "")
        append(if (c.isEmpty()) "-" else c)
        append(' ')
        append(if (ep >= 0) name(ep) else "-")
    }

    /** Placement and side only: what makes two positions the same for "have I been here before". */
    fun key(): String = toFen().substringBeforeLast(' ').substringBeforeLast(' ')

    // ------------------------------------------------------------------ attacks

    /** Is [sq] attacked by a piece of colour [by] (1 or -1)? */
    fun attacked(sq: Int, by: Int): Boolean {
        val b = b
        for (s in ChessTables.PAT[if (by > 0) 1 else 0][sq]) if (b[s] == by) return true
        val n = 2 * by
        for (s in ChessTables.KN[sq]) if (b[s] == n) return true
        val k = 6 * by
        for (s in ChessTables.KG[sq]) if (b[s] == k) return true
        val bi = 3 * by
        val ro = 4 * by
        val qu = 5 * by
        val rays = ChessTables.RAYS
        var d = 1
        while (d < 8) {
            for (s in rays[sq * 8 + d]) {
                val v = b[s]
                if (v != 0) {
                    if (v == bi || v == qu) return true
                    break
                }
            }
            d += 2
        }
        d = 0
        while (d < 8) {
            for (s in rays[sq * 8 + d]) {
                val v = b[s]
                if (v != 0) {
                    if (v == ro || v == qu) return true
                    break
                }
            }
            d += 2
        }
        return false
    }

    fun inCheck(color: Int = side): Boolean {
        val k = kingSq(color)
        return k >= 0 && attacked(k, -color)
    }

    // ------------------------------------------------------------------ move generation

    /**
     * Pseudo-legal moves (the own king may be left in check: [legal] filters them) into [out]; returns how many. With
     * [capturesOnly] only captures and queen promotions (what a quiescence search wants).
     */
    fun gen(out: IntArray, capturesOnly: Boolean = false): Int {
        var n = 0
        val me = side
        val b = b
        val rays = ChessTables.RAYS
        for (from in 0 until 64) {
            val v = b[from]
            if (v == 0 || (v > 0) != (me > 0)) continue
            val t = if (v > 0) v else -v
            when (t) {
                1 -> {
                    val r = from shr 3
                    val promoRank = if (me > 0) 6 else 1 // the rank a pawn stands on one step before promoting
                    val one = from + 8 * me
                    if (one in 0..63 && b[one] == 0) {
                        if (r == promoRank) {
                            if (capturesOnly) out[n++] = from or (one shl 6) or (5 shl 12)
                            else for (pr in 5 downTo 2) out[n++] = from or (one shl 6) or (pr shl 12)
                        } else if (!capturesOnly) {
                            out[n++] = from or (one shl 6)
                            if (r == (if (me > 0) 1 else 6) && b[one + 8 * me] == 0) out[n++] = from or ((one + 8 * me) shl 6)
                        }
                    }
                    for (to in ChessTables.PAT[if (me > 0) 0 else 1][from]) {
                        val target = b[to]
                        if (target != 0 && (target > 0) != (me > 0)) {
                            if (r == promoRank) {
                                if (capturesOnly) out[n++] = from or (to shl 6) or (5 shl 12)
                                else for (pr in 5 downTo 2) out[n++] = from or (to shl 6) or (pr shl 12)
                            } else {
                                out[n++] = from or (to shl 6)
                            }
                        } else if (target == 0 && to == ep) {
                            out[n++] = from or (to shl 6)
                        }
                    }
                }
                2 -> for (to in ChessTables.KN[from]) {
                    val target = b[to]
                    if (target == 0) {
                        if (!capturesOnly) out[n++] = from or (to shl 6)
                    } else if ((target > 0) != (me > 0)) {
                        out[n++] = from or (to shl 6)
                    }
                }
                6 -> {
                    for (to in ChessTables.KG[from]) {
                        val target = b[to]
                        if (target == 0) {
                            if (!capturesOnly) out[n++] = from or (to shl 6)
                        } else if ((target > 0) != (me > 0)) {
                            out[n++] = from or (to shl 6)
                        }
                    }
                    if (!capturesOnly) n = genCastle(out, n, from, me)
                }
                else -> {
                    var d = if (t == 3) 1 else 0 // bishops use the odd directions, rooks the even, queens both
                    val step = if (t == 5) 1 else 2
                    while (d < 8) {
                        for (to in rays[from * 8 + d]) {
                            val target = b[to]
                            if (target == 0) {
                                if (!capturesOnly) out[n++] = from or (to shl 6)
                            } else {
                                if ((target > 0) != (me > 0)) out[n++] = from or (to shl 6)
                                break
                            }
                        }
                        d += step
                    }
                }
            }
        }
        return n
    }

    private fun genCastle(out: IntArray, start: Int, from: Int, me: Int): Int {
        var n = start
        val home = if (me > 0) 4 else 60
        if (from != home) return n
        val kingSide = if (me > 0) 1 else 4
        val queenSide = if (me > 0) 2 else 8
        val rookV = 4 * me
        if (castle and (kingSide or queenSide) == 0) return n
        if (attacked(from, -me)) return n
        if (castle and kingSide != 0 && b[home + 3] == rookV && b[home + 1] == 0 && b[home + 2] == 0 &&
            !attacked(home + 1, -me) && !attacked(home + 2, -me)
        ) {
            out[n++] = move(from, home + 2)
        }
        if (castle and queenSide != 0 && b[home - 4] == rookV && b[home - 1] == 0 && b[home - 2] == 0 && b[home - 3] == 0 &&
            !attacked(home - 1, -me) && !attacked(home - 2, -me)
        ) {
            out[n++] = move(from, home - 2)
        }
        return n
    }

    // ------------------------------------------------------------------ make / unmake

    fun make(m: Int) {
        if (sp == uPiece.size) grow()
        val T = ChessTables
        val from = m and 63
        val to = (m shr 6) and 63
        val promo = (m shr 12) and 7
        val piece = b[from]
        val t = abs(piece)
        var cap = b[to]
        var capSq = to
        uPiece[sp] = piece
        uCastle[sp] = castle
        uEp[sp] = ep
        uHash[sp] = hash
        uMg[sp] = mg
        uEg[sp] = eg
        uPh[sp] = phase
        uHalf[sp] = half
        if (t == 1 && to == ep && (from and 7) != (to and 7) && cap == 0) {
            capSq = if (side > 0) to - 8 else to + 8
            cap = b[capSq]
        }
        uCap[sp] = cap
        uCapSq[sp] = capSq
        sp++
        var h = hash
        if (epHashed(side)) h = h xor T.ZE[ep and 7] // the old en passant square goes (the board is still the one it was computed on)
        var m2 = mg
        var e2 = eg
        var ph = phase
        if (cap != 0) {
            b[capSq] = 0
            val ci = (cap + 6) * 64 + capSq
            h = h xor T.Z[ci]
            m2 -= T.MGT[ci]
            e2 -= T.EGT[ci]
            ph -= T.PHASE[abs(cap)]
        }
        val placed = if (promo != 0) side * promo else piece
        b[to] = placed
        b[from] = 0
        val fi = (piece + 6) * 64 + from
        val ti = (placed + 6) * 64 + to
        h = h xor T.Z[fi] xor T.Z[ti]
        m2 += T.MGT[ti] - T.MGT[fi]
        e2 += T.EGT[ti] - T.EGT[fi]
        if (promo != 0) ph += T.PHASE[promo]
        if (t == 6) {
            king[if (side > 0) 0 else 1] = to
            if (to - from == 2) {
                val rook = b[to + 1]
                b[to - 1] = rook
                b[to + 1] = 0
                val a = (rook + 6) * 64 + to + 1
                val c = (rook + 6) * 64 + to - 1
                h = h xor T.Z[a] xor T.Z[c]
                m2 += T.MGT[c] - T.MGT[a]
                e2 += T.EGT[c] - T.EGT[a]
            } else if (from - to == 2) {
                val rook = b[to - 2]
                b[to + 1] = rook
                b[to - 2] = 0
                val a = (rook + 6) * 64 + to - 2
                val c = (rook + 6) * 64 + to + 1
                h = h xor T.Z[a] xor T.Z[c]
                m2 += T.MGT[c] - T.MGT[a]
                e2 += T.EGT[c] - T.EGT[a]
            }
        }
        // castling rights go when a king or rook moves, or a rook is taken on its square
        h = h xor T.ZC[castle]
        castle = castle and T.RIGHTS_KEEP[from] and T.RIGHTS_KEEP[to]
        h = h xor T.ZC[castle]
        ep = if (t == 1 && abs(to - from) == 16) (from + to) / 2 else -1
        if (epHashed(-side)) h = h xor T.ZE[ep and 7]
        h = h xor T.ZS
        half = if (t == 1 || cap != 0) 0 else half + 1
        side = -side
        hash = h
        mg = m2
        eg = e2
        phase = ph
    }

    fun unmake(m: Int) {
        sp--
        side = -side
        val from = m and 63
        val to = (m shr 6) and 63
        val piece = uPiece[sp]
        val cap = uCap[sp]
        val capSq = uCapSq[sp]
        castle = uCastle[sp]
        ep = uEp[sp]
        hash = uHash[sp]
        mg = uMg[sp]
        eg = uEg[sp]
        phase = uPh[sp]
        half = uHalf[sp]
        val t = abs(piece)
        b[from] = piece
        b[to] = 0
        if (cap != 0) b[capSq] = cap
        if (t == 6) {
            king[if (side > 0) 0 else 1] = from
            if (to - from == 2) {
                b[to + 1] = b[to - 1]
                b[to - 1] = 0
            } else if (from - to == 2) {
                b[to - 2] = b[to + 1]
                b[to + 1] = 0
            }
        }
    }

    /** Passes the move (the "null move" of a search). */
    fun makeNull() {
        if (sp == uPiece.size) grow()
        uPiece[sp] = 0
        uCap[sp] = 0
        uCapSq[sp] = 0
        uCastle[sp] = castle
        uEp[sp] = ep
        uHash[sp] = hash
        uMg[sp] = mg
        uEg[sp] = eg
        uPh[sp] = phase
        uHalf[sp] = half
        sp++
        if (epHashed(side)) hash = hash xor ChessTables.ZE[ep and 7]
        ep = -1
        hash = hash xor ChessTables.ZS
        half++
        side = -side
    }

    fun unmakeNull() {
        sp--
        side = -side
        ep = uEp[sp]
        hash = uHash[sp]
        half = uHalf[sp]
    }

    /** The piece the last [make] took (0 = none). */
    fun lastCapture(): Int = if (sp > 0) uCap[sp - 1] else 0

    /** Has this position (same hash) occurred before since the last capture or pawn move, in the moves made on this object? */
    fun repeated(): Boolean {
        var i = sp - 2
        val lo = if (sp - half > 0) sp - half else 0
        while (i >= lo) {
            if (uHash[i] == hash) return true
            i -= 2
        }
        return false
    }

    /** Fills [out] with the legal moves, returns how many. */
    fun legal(out: IntArray): Int {
        val tmp = IntArray(256)
        val n = gen(tmp)
        var k = 0
        val me = side
        for (i in 0 until n) {
            val m = tmp[i]
            make(m)
            val ok = !inCheck(me)
            unmake(m)
            if (ok) out[k++] = m
        }
        return k
    }

    /** Counts the leaf positions [depth] plies deep (the standard test of a move generator). */
    fun perft(depth: Int): Long {
        if (depth == 0) return 1L
        val tmp = IntArray(256)
        val n = gen(tmp)
        var total = 0L
        val me = side
        for (i in 0 until n) {
            val m = tmp[i]
            make(m)
            if (!inCheck(me)) total += if (depth == 1) 1L else perft(depth - 1)
            unmake(m)
        }
        return total
    }
}

/** The result of a search. [score] is in centipawns from the point of view of the side to move; mates are about +-30000. [pv] is the line the engine expects. */
class ChessChoice(val move: Int, val score: Int, val depth: Int, val nodes: Long, val pv: IntArray = IntArray(0)) {
    val uci: String get() = ChessPos.uci(move)
}
