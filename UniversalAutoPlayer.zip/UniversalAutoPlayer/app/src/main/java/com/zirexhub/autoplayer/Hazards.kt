package com.zirexhub.autoplayer

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * What can hurt or block the character, seen from the colours of one screenshot (pure Kotlin, no Android).
 *
 *  - LAVA / FIRE GROUND: big areas of dark orange or red-brown (calibrated on a real dark game: cracked lava rivers are
 *    about RGB 110,43,20 once the picture is shrunk). Small orange things (fire balls, the character's own ring, flames
 *    of a weapon) are not ground, so only big connected areas count.
 *  - THORN / SPIKE WALLS: narrow tall columns full of sharp edges, usually at the side of the map.
 *
 * The character is assumed to stand where the camera keeps it, near the middle of the screen. For 16 headings
 * ([DIRS], 22.5 degrees apart, angle 0 = right, y down like the screen) it tells how soon a walk that way hits something.
 */
class HazardInfo(
    val gw: Int,
    val gh: Int,
    /** Grid cells that are lava (after the small stuff was dropped). */
    val lava: BooleanArray,
    /** Grid columns that belong to a thorn / spike wall. */
    val wallCol: BooleanArray,
    val aspect: Float,
    val heroX: Float,
    val heroY: Float,
) {
    /** 0..1 per heading: 1 = a hazard right in front of the character, 0 = clear as far as we can see. */
    val danger = FloatArray(Hazards.DIRS)

    /** The same, but only lava / only thorn walls (to tell the player what the bot is avoiding). */
    val lavaDanger = FloatArray(Hazards.DIRS)
    val wallDanger = FloatArray(Hazards.DIRS)

    /** Per heading, how far (in screen widths) the walk is still inside lava; only filled when [onLava]. */
    val exit = FloatArray(Hazards.DIRS)

    /** The character stands in (or right at the edge of) lava. */
    var onLava = false

    /** Share of the screen that is lava, 0..1. */
    var lavaFrac = 0f

    /** True when a thorn wall was found. */
    var hasWall = false

    fun lavaAt(x: Float, y: Float): Boolean {
        val cx = (x * gw).toInt()
        val cy = (y * gh).toInt()
        if (cx < 0 || cy < 0 || cx >= gw || cy >= gh) return false
        return lava[cy * gw + cx]
    }

    /** Short text for the debug log. */
    fun describe(): String {
        val worst = danger.indices.maxByOrNull { danger[it] } ?: 0
        val walls = wallCol.indices.filter { wallCol[it] }
        val wallTxt = if (walls.isEmpty()) "no wall" else "wall at x=${walls.first() * 100 / gw}..${(walls.last() + 1) * 100 / gw}%"
        return "lava=${(lavaFrac * 100).toInt()}%${if (onLava) " ON-LAVA" else ""} worst=${Hazards.angleName(worst)}:${"%.2f".format(danger[worst])} $wallTxt"
    }
}

object Hazards {
    const val DIRS = 16

    /**
     * The character's own glow / weapon ring (an orange circle about 0.15 screen widths from the character on the
     * real game) is not lava. Colours inside this radius are ignored, lava is looked for outside of it.
     */
    private const val DISC = 0.18f

    /** Looked at this far from the character, in screen widths. */
    private const val NEAR = DISC + 0.01f
    private const val FAR = 0.56f
    private const val STEP = 0.025f

    /** Hazard colours at this distance or closer count fully; further out they fade away. */
    private const val FULL = 0.30f
    private const val FADE = 0.26f

    /** Smallest lava area that is ground and not a fire ball, as a share of the picture. */
    private const val MIN_AREA = 0.012f

    fun angleOf(k: Int): Double = k * (2 * PI / DIRS)

    private val NAMES = arrayOf(
        "right", "right-down", "down-right", "down-down", "down", "down-left", "left-down", "left-left",
        "left", "left-up", "up-left", "up-up", "up", "up-right", "right-up", "right-right",
    )

    fun angleName(k: Int): String = when (k) {
        0 -> "right"; 2 -> "down-right"; 4 -> "down"; 6 -> "down-left"; 8 -> "left"; 10 -> "up-left"; 12 -> "up"; 14 -> "up-right"
        else -> NAMES[k % NAMES.size]
    }

    /** Dark orange / red-brown, the colour of lava on a shrunk picture. Dull greys, yellow text and green gems do not pass. */
    fun isLavaColour(c: Int): Boolean {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        if (r < 75) return false
        val mx = r
        val mn = min(g, b)
        if (g * 4 < r || g * 4 > r * 3) return false // green between a quarter and three quarters of red
        if (b > g * 0.55f + 10f) return false
        return (mx - mn) * 100 > mx * 55 // saturated
    }

    /**
     * [px] is the shrunk screenshot as ARGB ints (a good size is 96 wide), [aspect] the screen height / width.
     * [heroX] / [heroY] is where the character stands on the screen (0..1).
     */
    fun analyze(px: IntArray, gw: Int, gh: Int, aspect: Float, heroX: Float = 0.5f, heroY: Float = 0.49f): HazardInfo? {
        if (gw < 16 || gh < 16 || px.size < gw * gh) return null
        val n = gw * gh

        // 1) lava colour, then close the little cracks of the lava texture
        val raw = BooleanArray(n)
        val hudRows = (gh * 0.16f).toInt()
        val hx = heroX * gw
        val hy = heroY * gh
        val dr = DISC * gw
        for (y in hudRows until gh) for (x in 0 until gw) {
            val ddx = x + 0.5f - hx
            val ddy = y + 0.5f - hy // grid cells are square, so columns and rows count the same
            if (ddx * ddx + ddy * ddy < dr * dr) continue
            raw[y * gw + x] = isLavaColour(px[y * gw + x])
        }
        val closed = erode(dilate(raw, gw, gh), gw, gh)

        // 2) keep only big areas: weapon fire balls and the character's own ring are small
        val lava = BooleanArray(n)
        val seen = BooleanArray(n)
        val stack = IntArray(n)
        var lavaCount = 0
        for (start in 0 until n) {
            if (!closed[start] || seen[start]) continue
            var sp = 0
            stack[sp++] = start
            seen[start] = true
            val members = ArrayList<Int>()
            var minX = gw
            var maxX = 0
            while (sp > 0) {
                val cur = stack[--sp]
                members.add(cur)
                val x = cur % gw
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (x > 0 && closed[cur - 1] && !seen[cur - 1]) { seen[cur - 1] = true; stack[sp++] = cur - 1 }
                if (x < gw - 1 && closed[cur + 1] && !seen[cur + 1]) { seen[cur + 1] = true; stack[sp++] = cur + 1 }
                if (cur >= gw && closed[cur - gw] && !seen[cur - gw]) { seen[cur - gw] = true; stack[sp++] = cur - gw }
                if (cur + gw < n && closed[cur + gw] && !seen[cur + gw]) { seen[cur + gw] = true; stack[sp++] = cur + gw }
            }
            val widthFrac = (maxX - minX + 1).toFloat() / gw
            val big = members.size >= MIN_AREA * n || (members.size >= 0.006f * n && widthFrac >= 0.35f)
            if (big) {
                for (m in members) lava[m] = true
                lavaCount += members.size
            }
        }

        // a picture that is mostly "lava coloured" is just the colour of that world (desert, brick), not a river of lava
        if (lavaCount > 0.70f * n) {
            lava.fill(false)
            lavaCount = 0
        }

        val wall = thornColumns(px, gw, gh, lava)
        val info = HazardInfo(gw, gh, lava, wall, aspect, heroX, heroY)
        info.lavaFrac = lavaCount.toFloat() / n
        info.hasWall = wall.any { it }
        castRays(info)
        return info
    }

    private fun dilate(a: BooleanArray, w: Int, h: Int): BooleanArray {
        val out = BooleanArray(a.size)
        for (y in 0 until h) for (x in 0 until w) {
            var v = false
            loop@ for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx
                val yy = y + dy
                if (xx in 0 until w && yy in 0 until h && a[yy * w + xx]) {
                    v = true
                    break@loop
                }
            }
            out[y * w + x] = v
        }
        return out
    }

    private fun erode(a: BooleanArray, w: Int, h: Int): BooleanArray {
        val out = BooleanArray(a.size)
        for (y in 0 until h) for (x in 0 until w) {
            var v = true
            loop@ for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx
                val yy = y + dy
                if (xx in 0 until w && yy in 0 until h && !a[yy * w + xx]) {
                    v = false
                    break@loop
                }
            }
            out[y * w + x] = v
        }
        return out
    }

    /**
     * Thorn / spike walls: a narrow band of columns that is full of sharp horizontal edges from top to bottom.
     * The ordinary floor (cracked stone) has about a third of that, lava is left out.
     */
    private fun thornColumns(px: IntArray, gw: Int, gh: Int, lava: BooleanArray): BooleanArray {
        val out = BooleanArray(gw)
        val g = IntArray(gw * gh)
        for (i in g.indices) {
            val c = px[i]
            g[i] = (((c shr 16) and 0xFF) * 77 + ((c shr 8) and 0xFF) * 150 + (c and 0xFF) * 29) shr 8
        }
        val y0 = (gh * 0.20f).toInt()
        val y1 = (gh * 0.90f).toInt()
        if (y1 - y0 < 16) return out
        val gx = IntArray(gw * gh)
        val hist = IntArray(256)
        var total = 0
        for (y in y0 until y1) for (x in 0 until gw) {
            val xa = max(0, x - 1)
            val xb = min(gw - 1, x + 1)
            val v = min(255, abs(g[y * gw + xb] - g[y * gw + xa]) * (if (xb - xa == 2) 1 else 2))
            gx[y * gw + x] = v
            hist[v]++
            total++
        }
        var acc = 0
        var median = 0
        for (v in 0 until 256) {
            acc += hist[v]
            if (acc * 2 >= total) {
                median = v
                break
            }
        }
        val ref = max(3f, median.toFloat())
        val bw = max(2, gw / 24)
        val bands = gw / bw
        val cover = FloatArray(bands)
        for (b in 0 until bands) {
            var hits = 0
            for (y in y0 until y1) {
                var s = 0
                var lv = 0
                for (x in b * bw until (b + 1) * bw) {
                    s += gx[y * gw + x]
                    if (lava[y * gw + x]) lv++
                }
                if (s.toFloat() / bw > 2.2f * ref && lv * 10 < bw * 3) hits++
            }
            cover[b] = hits.toFloat() / (y1 - y0)
        }
        var b = 0
        while (b < bands) {
            if (cover[b] < 0.55f) {
                b++
                continue
            }
            var e = b
            var peak = 0f
            while (e < bands && cover[e] >= 0.55f) {
                peak = max(peak, cover[e])
                e++
            }
            // a wall is narrow (at most about a fifth of the screen) and clearly stronger than ordinary floor in at least one band
            if (peak >= 0.75f && e - b <= 5) {
                for (x in (b * bw) until min(gw, e * bw)) out[x] = true
            }
            b = e
        }
        return out
    }

    private fun weight(d: Float): Float = if (d <= FULL) 1f else max(0f, 1f - (d - FULL) / FADE)

    private fun castRays(info: HazardInfo) {
        val gw = info.gw
        val gh = info.gh
        val raw = FloatArray(DIRS)
        val rawLava = FloatArray(DIRS)
        val rawWall = FloatArray(DIRS)
        var lavaUnder = 0
        for (k in 0 until DIRS) {
            val a = angleOf(k)
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            var dangerK = 0f
            var free = 0
            var exitD = -1f
            var d = NEAR
            var inLava = false
            while (d <= FAR + 1e-4f) {
                val x = info.heroX + d * ca
                val y = info.heroY + d * sa / info.aspect
                val gxI = (x * gw).toInt()
                val gyI = (y * gh).toInt()
                if (gxI in 0 until gw && gyI in 0 until gh) {
                    val l = info.lava[gyI * gw + gxI]
                    val w = info.wallCol[gxI]
                    if (l || w) dangerK = max(dangerK, weight(d))
                    if (l) rawLava[k] = max(rawLava[k], weight(d))
                    if (w) rawWall[k] = max(rawWall[k], weight(d))
                    if (d <= NEAR + 0.03f && l) inLava = true
                    if (l) free = 0 else free++
                    if (exitD < 0f && !l && free >= 2) exitD = d
                }
                d += STEP
            }
            if (inLava) lavaUnder++
            raw[k] = dangerK
            info.exit[k] = if (exitD < 0f) FAR + 0.1f else exitD
        }
        // the character is not a point: a hazard a step to the side of the heading counts a little too
        for (k in 0 until DIRS) {
            val l = raw[(k + DIRS - 1) % DIRS]
            val r = raw[(k + 1) % DIRS]
            info.danger[k] = max(raw[k], 0.75f * max(l, r))
            info.lavaDanger[k] = max(rawLava[k], 0.75f * max(rawLava[(k + DIRS - 1) % DIRS], rawLava[(k + 1) % DIRS]))
            info.wallDanger[k] = max(rawWall[k], 0.75f * max(rawWall[(k + DIRS - 1) % DIRS], rawWall[(k + 1) % DIRS]))
        }
        info.onLava = lavaUnder >= 7
    }

    /** Smallest turn between two angles, 0..PI. */
    fun angDiff(a: Double, b: Double): Double {
        var d = (a - b) % (2 * PI)
        if (d > PI) d -= 2 * PI
        if (d < -PI) d += 2 * PI
        return abs(d)
    }

    /** Danger of walking along angle [h] (between the two nearest of the 16 headings). */
    fun dangerAt(info: HazardInfo, h: Double): Float {
        var a = h % (2 * PI)
        if (a < 0) a += 2 * PI
        val f = a / (2 * PI / DIRS)
        val k0 = f.toInt() % DIRS
        val k1 = (k0 + 1) % DIRS
        val frac = f - f.toInt()
        if (frac < 0.12) return info.danger[k0]
        if (frac > 0.88) return info.danger[k1]
        return max(info.danger[k0], info.danger[k1])
    }

    /** What the bot is turning away from when it wants to walk along angle [h]. */
    fun whatIsAhead(info: HazardInfo, h: Double): String {
        if (info.onLava) return "standing in lava"
        var a = h % (2 * PI)
        if (a < 0) a += 2 * PI
        val k = ((a / (2 * PI / DIRS)) + 0.5).toInt() % DIRS
        return if (info.lavaDanger[k] >= info.wallDanger[k]) "lava ahead" else "thorn wall ahead"
    }

    /**
     * Takes the heading the strategist wanted and bends it away from lava and thorn walls:
     *  - standing in lava: take the shortest way out;
     *  - a hazard ahead: the nearest heading that is clear (sliding along the edge beats turning right around);
     *  - nothing ahead: the heading is left alone.
     */
    fun steer(h: Double, info: HazardInfo): Double {
        if (info.onLava) {
            var best = 0
            var bc = Double.MAX_VALUE
            for (k in 0 until DIRS) {
                val c = info.exit[k] + 0.04 * angDiff(h, angleOf(k)) + 0.15 * info.danger[k]
                if (c < bc) {
                    bc = c
                    best = k
                }
            }
            return angleOf(best)
        }
        if (dangerAt(info, h) < 0.25f) return h
        var best = h
        var bc = Double.MAX_VALUE
        for (k in 0 until DIRS) {
            val a = angleOf(k)
            val c = 0.4 * angDiff(h, a) + 3.0 * info.danger[k]
            if (c < bc) {
                bc = c
                best = a
            }
        }
        return best
    }
}
