package com.zirexhub.autoplayer

import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** On-device OCR (Google ML Kit, bundled Latin model). Works offline, nothing leaves the phone. */
class TextReader {

    private val recognizer: TextRecognizer? = try {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    } catch (_: Throwable) {
        null
    }

    /** Returns every text line on the screen with its normalized (0..1) bounding box. */
    fun read(frame: Bitmap): List<TextLine> {
        val rec = recognizer ?: return emptyList()
        val scale = min(1f, 1280f / max(frame.width, frame.height))
        val bmp = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                frame,
                (frame.width * scale).roundToInt().coerceAtLeast(1),
                (frame.height * scale).roundToInt().coerceAtLeast(1),
                true,
            )
        } else {
            frame
        }
        try {
            val bw = bmp.width.toFloat()
            val bh = bmp.height.toFloat()
            val result = Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)), 4, TimeUnit.SECONDS)
            val out = ArrayList<TextLine>()
            for (block in result.textBlocks) {
                for (line in block.lines) {
                    val box = line.boundingBox ?: continue
                    out.add(TextLine(line.text, box.left / bw, box.top / bh, box.right / bw, box.bottom / bh))
                }
            }
            return out
        } catch (e: InterruptedException) {
            throw e
        } catch (_: Exception) {
            return emptyList()
        } finally {
            if (bmp !== frame) bmp.recycle()
        }
    }

    fun close() {
        try {
            recognizer?.close()
        } catch (_: Throwable) {
        }
    }
}
