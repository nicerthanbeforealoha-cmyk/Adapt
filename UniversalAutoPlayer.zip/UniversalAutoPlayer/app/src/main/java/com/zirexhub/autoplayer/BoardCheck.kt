package com.zirexhub.autoplayer

import kotlin.math.abs

/**
 * Did a move on a board really happen? (pure Kotlin, no Android)
 *
 * Found in a real chess log: the AI dragged a pawn, the whole screen changed by 0.0025 and the "did my press work" check said
 * yes. But the same 0.0025 had been measured in an earlier log where the pawn never moved: the app only SELECTED the pawn
 * (a highlight on its square). A move changes TWO squares clearly: the one the piece left and the one it arrived on. A
 * selection changes only the first (and shows small dots on the squares it could go to). So the two squares are compared
 * between the picture before and after the move.
 */
object BoardCheck {
    enum class Result {
        /** The target square changed about as much as the start square: the piece arrived. */
        MOVED,

        /** The start square changed (highlight) but the target square did not: the piece was only selected. */
        SELECTED_ONLY,

        /** Neither square changed. */
        NOTHING,
    }

    /** Mean brightness change (0..255) over the inner 70 % of cell ([col], [row]), same-sized pictures. */
    fun cellDiff(a: Gray, b: Gray, grid: Grid, col: Int, row: Int): Float {
        if (a.w != b.w || a.h != b.h) return 0f
        val cw = (grid.r - grid.l) / grid.cols
        val ch = (grid.b - grid.t) / grid.rows
        val cx = grid.cx(col)
        val cy = grid.cy(row)
        val x0 = ((cx - 0.35f * cw) * a.w).toInt().coerceIn(0, a.w - 1)
        val x1 = ((cx + 0.35f * cw) * a.w).toInt().coerceIn(x0 + 1, a.w)
        val y0 = ((cy - 0.35f * ch) * a.h).toInt().coerceIn(0, a.h - 1)
        val y1 = ((cy + 0.35f * ch) * a.h).toInt().coerceIn(y0 + 1, a.h)
        var sum = 0L
        var n = 0
        for (y in y0 until y1) for (x in x0 until x1) {
            sum += abs(a.px[y * a.w + x] - b.px[y * b.w + x])
            n++
        }
        return if (n == 0) 0f else sum.toFloat() / n
    }

    /** Spread (standard deviation of brightness) over the inner 70 % of cell ([col], [row]): a piece on a square is high, a bare or tinted square is flat. */
    fun cellStd(a: Gray, grid: Grid, col: Int, row: Int): Float {
        val cw = (grid.r - grid.l) / grid.cols
        val ch = (grid.b - grid.t) / grid.rows
        val cx = grid.cx(col)
        val cy = grid.cy(row)
        val x0 = ((cx - 0.35f * cw) * a.w).toInt().coerceIn(0, a.w - 1)
        val x1 = ((cx + 0.35f * cw) * a.w).toInt().coerceIn(x0 + 1, a.w)
        val y0 = ((cy - 0.35f * ch) * a.h).toInt().coerceIn(0, a.h - 1)
        val y1 = ((cy + 0.35f * ch) * a.h).toInt().coerceIn(y0 + 1, a.h)
        var sum = 0.0
        var sq = 0.0
        var n = 0
        for (y in y0 until y1) for (x in x0 until x1) {
            val v = a.px[y * a.w + x].toDouble()
            sum += v
            sq += v * v
            n++
        }
        if (n == 0) return 0f
        val mean = sum / n
        return kotlin.math.sqrt((sq / n - mean * mean).coerceAtLeast(0.0)).toFloat()
    }

    /**
     * What happened to a move from ([c1],[r1]) to ([c2],[r2]), judged from the pictures taken before and after it.
     *
     * The telling sign is the START square: after a real move it is EMPTY (flat, maybe tinted as "last move"), after a mere
     * selection the piece is still standing on it (only a highlight was added, and dots appeared on the squares it can go
     * to). How much the squares changed is not telling: a tint alone changes a square as much as a small pawn arriving.
     */
    fun verdict(before: Gray, after: Gray, grid: Grid, c1: Int, r1: Int, c2: Int, r2: Int): Result {
        if (before.w != after.w || before.h != after.h) return Result.NOTHING
        val s = cellDiff(before, after, grid, c1, r1)
        val d = cellDiff(before, after, grid, c2, r2)
        if (s < QUIET && d < QUIET) return Result.NOTHING
        val sb = cellStd(before, grid, c1, r1)
        val sa = cellStd(after, grid, c1, r1)
        val emptied = sb >= PIECE_STD && sa <= 0.5f * sb
        return if (emptied && d >= QUIET) Result.MOVED else Result.SELECTED_ONLY
    }

    private const val QUIET = 3f
    private const val PIECE_STD = 6f
}
