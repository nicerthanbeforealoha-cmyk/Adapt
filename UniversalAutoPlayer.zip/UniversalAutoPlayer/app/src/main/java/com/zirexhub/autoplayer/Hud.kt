package com.zirexhub.autoplayer

/**
 * Text that belongs to the picture of a running game and is never a button (pure Kotlin, no Android).
 *
 * Found in a real log of the Inferno map: the screen edges carry objective markers ("TREASURE 2,700 m" on the left,
 * "RESCUE 2,669 m" on the right, and a bare "RESCUE" label that slides along the edge). The bot took them for menu
 * buttons, stood still and tapped them for 20 seconds. Two kinds of protection:
 *
 *  - [isStatic]: wording that is clearly a distance ("2,700 m", "2692-m", even a clipped "pz m") or an objective marker
 *    at the edge of the screen. These are never buttons, in any game.
 *  - [HudMemory]: text that stays at the same place on several readings WHILE the bot's own joystick is moving the world
 *    is part of the HUD of THIS game (a label, a counter, a pause icon). Learned, so it also covers games the static
 *    words do not know.
 */
object Hud {
    private val DISTANCE = Regex("\\d\\s*-?\\s*(km|m)$|\\d\\s*-?\\s*(km|m)\\s")
    private val FRAGMENT = Regex("^[a-z0-9]{1,3} m$")
    private val MARKER_STARTS = listOf("trea", "resc", "objective", "waypoint")

    /** "2,700 m", "2692-m", "00m": a number followed by a distance unit (the text is already [Planner.normalize]d). */
    fun isDistance(norm: String): Boolean = norm.isNotEmpty() && (DISTANCE.containsMatchIn(norm) || FRAGMENT.matches(norm))

    /** The start of an objective marker, also when OCR clipped or garbled it ("trea", "tre s", "res", "resclje"). */
    private fun markerWord(norm: String): Boolean {
        if (MARKER_STARTS.any { norm.startsWith(it) }) return true
        val first = norm.substringBefore(' ')
        return first == "res" || first == "tre" || norm.startsWith("tre ")
    }

    /**
     * True for text that cannot be a menu button: a distance, or an objective marker at the left / right edge of the
     * screen (cards and buttons of a popup sit in the middle, so a card named "Treasure Hunter" is not caught).
     */
    fun isStatic(ln: TextLine, norm: String): Boolean {
        if (norm.isEmpty()) return false
        if (isDistance(norm)) return true
        if (markerWord(norm) && (ln.cx < 0.24f || ln.cx > 0.76f)) return true
        return false
    }
}

/**
 * Learns which lines of text are the HUD of the game being played.
 *
 * A line counts as HUD when the same place on the screen carries text on [NEED] fresh readings in a row, and each of those
 * readings came right after the bot's own joystick drag with a clearly moving picture. A popup that appears is only seen
 * once while the world moves (the next readings come after a button press or a frozen picture), so cards of a level-up
 * popup are not learned, even when the same layout comes back many times. A place that carries no text on two later fresh
 * readings in a row is forgotten again.
 */
class HudMemory {
    private val streak = HashMap<Int, Int>()
    private val missed = HashMap<Int, Int>()
    private var lastSeq = -1

    private fun cell(ln: TextLine): Int = (ln.cx * 3f).toInt().coerceIn(0, 2) * 100 + (ln.cy * 40f).toInt().coerceIn(0, 39)

    /**
     * [seq] identifies one OCR reading (the same lines are handed over again on steps without a new reading, those must
     * not count twice). [worldMoving] = the last action was a joystick drag and the picture changed clearly.
     */
    fun observe(lines: List<TextLine>, seq: Int, worldMoving: Boolean) {
        if (seq == lastSeq && seq >= 0) return
        lastSeq = seq
        val present = HashSet<Int>()
        for (ln in lines) {
            if (ln.cy < 0.05f || ln.cy > 0.97f) continue
            present.add(cell(ln))
        }
        if (!worldMoving) return // a frozen picture or a popup says nothing about the HUD
        // A learned place without text is forgotten only after two such readings in a row: the first reading of a popup that
        // has just covered the HUD is one of them, and the label is still there when the popup is gone.
        val it = streak.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (e.key in present) continue
            if (e.value < NEED) { // not learned yet: a gap in the readings breaks the run at once
                it.remove()
                missed.remove(e.key)
                continue
            }
            val m = (missed[e.key] ?: 0) + 1
            if (m >= 2) {
                it.remove()
                missed.remove(e.key)
            } else {
                missed[e.key] = m
            }
        }
        for (c in present) {
            streak[c] = (streak[c] ?: 0) + 1
            missed.remove(c)
        }
    }

    fun isHud(ln: TextLine): Boolean = (streak[cell(ln)] ?: 0) >= NEED

    companion object {
        const val NEED = 3
    }
}
