package com.zirexhub.autoplayer

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** A small grayscale picture (values 0..255) used for motion maths. */
class Gray(val w: Int, val h: Int, val px: IntArray)

/**
 * What moved between two screenshots.
 *
 *  - [dx], [dy]: the whole scene slid by this many grid pixels (content moved right / down when positive).
 *  - [coherence] 0..1: how much of the difference between the two frames is explained by that ONE slide
 *    (scaled so that a third of it counts as 1.0). A camera that follows a moving player, a scrolling road,
 *    a panning map => 0.3 and up. Menus, popups and local animation => 0.
 *  - [magnitude]: length of the slide in grid pixels.
 *  - [meanDiff]: average brightness change between the frames (grey levels, 0..255).
 *  - [residual]: leftover motion per screen sector (3x3, row-major) AFTER the slide is removed, 0..1.
 *    That is "things moving on their own": enemies, projectiles, particles.
 */
class MotionInfo(
    val dx: Int,
    val dy: Int,
    val coherence: Float,
    val magnitude: Float,
    val meanDiff: Float,
    val saturated: Boolean,
    val residual: FloatArray,
)

/** Pure Kotlin, no Android. Works on the [Gray] pictures made by FrameTools.gray. */
object Motion {
    /**
     * The biggest slide that can be measured between two steps, in pixels of the 64 px wide grey picture.
     * A real game with a fast character slides 15 px per step (a quarter of the screen width per second); the first
     * version of this only saw 8 px, so fast movement looked like "nothing moved" and the bot lost movement mode.
     */
    const val RX = 20
    const val RY = 16

    /**
     * Below this average brightness change the screen counts as still (a frozen popup is 0.1 to 0.5 on a real phone,
     * a running dark game with the character standing still is 2 to 4, and a moving camera is 9 to 25).
     */
    private const val STILL = 1.0f

    /**
     * Average brightness change inside the box around a tap point (grey levels, 0..255) between two pictures.
     * Used right before pressing a button: if the area around it changed since the decision was made, the screen is
     * not the one the decision was made on (a button appeared exactly where the old text was), so do not press.
     */
    fun regionDiff(a: Gray, b: Gray, cx: Float, cy: Float, halfW: Float = 0.25f, halfH: Float = 0.05f): Float {
        if (a.w != b.w || a.h != b.h) return 0f
        val x0 = ((cx - halfW) * a.w).toInt().coerceIn(0, a.w - 1)
        val x1 = ((cx + halfW) * a.w).toInt().coerceIn(x0 + 1, a.w)
        val y0 = ((cy - halfH) * a.h).toInt().coerceIn(0, a.h - 1)
        val y1 = ((cy + halfH) * a.h).toInt().coerceIn(y0 + 1, a.h)
        var sum = 0L
        var n = 0
        for (y in y0 until y1) for (x in x0 until x1) {
            sum += abs(a.px[y * a.w + x] - b.px[y * b.w + x])
            n++
        }
        return if (n == 0) 0f else sum.toFloat() / n
    }

    /** 3x3 box blur: a slide that is not an exact multiple of the coarse search step still matches within one pixel. */
    private fun blur(g: Gray): Gray {
        val w = g.w
        val h = g.h
        val out = IntArray(w * h)
        for (y in 0 until h) {
            val ya = max(0, y - 1)
            val yb = min(h - 1, y + 1)
            for (x in 0 until w) {
                val xa = max(0, x - 1)
                val xb = min(w - 1, x + 1)
                var s = 0
                for (yy in ya..yb) for (xx in xa..xb) s += g.px[yy * w + xx]
                out[y * w + x] = s / ((yb - ya + 1) * (xb - xa + 1))
            }
        }
        return Gray(w, h, out)
    }

    /** Result of one slide search: where the picture slid to, and how much of the difference that explains. */
    private class Found(val dx: Int, val dy: Int, val sad0: Float, val best: Float)

    /**
     * Searches slides inside a window that keeps [mx] / [my] pixels of margin (so every candidate slide stays inside the
     * picture). With [farOnly] only slides bigger than 8 pixels are tried (the small ones were already tried).
     */
    private fun search(prev: Gray, cur: Gray, mx: Int, my: Int, rx: Int, ry: Int, farOnly: Boolean): Found? {
        val w = cur.w
        val h = cur.h
        val x0 = mx
        val x1 = w - mx
        val y0 = max(my, (h * 0.12f).toInt()) // skip the top bar (score, pause) ...
        val y1 = min(h - my, (h * 0.88f).toInt()) // ... and the bottom bar (controls)
        if (x1 - x0 < 8 || y1 - y0 < 8) return null

        fun sad(dx: Int, dy: Int): Float {
            var s = 0L
            var n = 0
            var y = y0
            while (y < y1) {
                val rowC = y * w
                val rowP = (y - dy) * w - dx
                var x = x0
                while (x < x1) {
                    s += abs(cur.px[rowC + x] - prev.px[rowP + x])
                    n++
                    x += 2
                }
                y += 2
            }
            return if (n == 0) 0f else s.toFloat() / n
        }

        val sad0 = sad(0, 0)
        var bestDx = 0
        var bestDy = 0
        var best = if (farOnly) Float.MAX_VALUE else sad0
        if (!farOnly) {
            for (dy in -ry..ry) for (dx in -rx..rx) {
                if (dx == 0 && dy == 0) continue
                val s = sad(dx, dy)
                if (s < best) {
                    best = s
                    bestDx = dx
                    bestDy = dy
                }
            }
        } else {
            // coarse: every 2nd pixel, only the far slides; then refine around the best one
            var dy = -ry
            while (dy <= ry) {
                var dx = -rx
                while (dx <= rx) {
                    if (max(abs(dx), abs(dy)) > 8) {
                        val s = sad(dx, dy)
                        if (s < best) {
                            best = s
                            bestDx = dx
                            bestDy = dy
                        }
                    }
                    dx += 2
                }
                dy += 2
            }
            if (best == Float.MAX_VALUE) return null
            val cx = bestDx
            val cy = bestDy
            for (fy in -1..1) for (fx in -1..1) {
                if (fx == 0 && fy == 0) continue
                val tx = (cx + fx).coerceIn(-rx, rx)
                val ty = (cy + fy).coerceIn(-ry, ry)
                val s = sad(tx, ty)
                if (s < best) {
                    best = s
                    bestDx = tx
                    bestDy = ty
                }
            }
        }
        return Found(bestDx, bestDy, sad0, best)
    }

    fun analyze(prev: Gray, cur: Gray): MotionInfo? {
        if (prev.w != cur.w || prev.h != cur.h) return null
        val w = cur.w
        val h = cur.h

        // 1) slow and medium slides (up to 8 px), judged over most of the picture
        val near = search(prev, cur, 8, 8, 8, 8, false) ?: return null
        if (near.sad0 < STILL) return MotionInfo(0, 0, 0f, 0f, near.sad0, false, FloatArray(9))

        // Calibrated on real dark games: when the camera really follows the character, ONE slide explains only 8 to 60
        // percent of the picture difference (enemies, particles and the HUD keep moving on their own), and the gain is
        // small in grey levels. When nothing slides, the best "slide" is no slide at all (gain 0).
        var dx = near.dx
        var dy = near.dy
        var sad0 = near.sad0
        var gain = near.sad0 - near.best
        var rel = gain / near.sad0
        var ok = gain >= 0.35f && rel >= 0.06f
        var mx = 8
        var my = 8

        // 2) a fast character: the picture slides 9 to 20 px per step (seen on a real phone: 15 px). Tried whenever the
        // picture clearly moved, and it wins when it explains more than the small slide did: a strong sprite (an enemy)
        // can match a small slide by chance while the whole background really slid much further.
        if (near.sad0 >= 3f) {
            val far = search(blur(prev), blur(cur), RX, RY, RX, RY, true)
            if (far != null) {
                val g = far.sad0 - far.best
                val r = g / far.sad0
                // many more places for a chance match out here, so ask for a clearer result
                if (g >= 0.5f && r >= 0.10f && (!ok || r > rel)) {
                    ok = true
                    dx = far.dx
                    dy = far.dy
                    sad0 = far.sad0
                    gain = g
                    rel = r
                    mx = RX
                    my = RY
                }
            }
        }

        val coherence = if (!ok) 0f else (rel * 3f).coerceIn(0f, 1f)
        val mag = if (!ok) 0f else sqrt((dx * dx + dy * dy).toFloat())
        val sx = if (!ok) 0 else dx
        val sy = if (!ok) 0 else dy

        // what is still moving once the slide is taken out
        val x0 = mx
        val x1 = w - mx
        val y0 = max(my, (h * 0.12f).toInt())
        val y1 = min(h - my, (h * 0.88f).toInt())
        val sum = FloatArray(9)
        val cnt = IntArray(9)
        var y = y0
        while (y < y1) {
            val sectorY = min(2, (y - y0) * 3 / (y1 - y0))
            val rowC = y * w
            val rowP = (y - sy) * w - sx
            var x = x0
            while (x < x1) {
                val sectorX = min(2, (x - x0) * 3 / (x1 - x0))
                val k = sectorY * 3 + sectorX
                sum[k] += abs(cur.px[rowC + x] - prev.px[rowP + x]).toFloat()
                cnt[k]++
                x += 2
            }
            y += 2
        }
        val residual = FloatArray(9) { if (cnt[it] == 0) 0f else sum[it] / cnt[it] / 255f }

        return MotionInfo(sx, sy, coherence, mag, near.sad0, abs(dx) >= RX || abs(dy) >= RY, residual)
    }
}
