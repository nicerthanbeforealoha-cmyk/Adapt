package com.zirexhub.autoplayer

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** A small grayscale picture (values 0..255) used for motion maths. */
class Gray(val w: Int, val h: Int, val px: IntArray)

/**
 * What moved between two screenshots.
 *
 *  - [dx], [dy]: the whole scene slid by this many grid pixels (content moved right / down when positive).
 *  - [coherence] 0..1: how much of the difference between the two frames is explained by that ONE slide
 *    (scaled so that a third of it counts as 1.0). A camera that follows a moving player, a scrolling road,
 *    a panning map => 0.3 and up. Menus, popups and local animation => 0.
 *  - [magnitude]: length of the slide in grid pixels.
 *  - [meanDiff]: average brightness change between the frames (grey levels, 0..255).
 *  - [residual]: leftover motion per screen sector (3x3, row-major) AFTER the slide is removed, 0..1.
 *    That is "things moving on their own": enemies, projectiles, particles.
 */
class MotionInfo(
    val dx: Int,
    val dy: Int,
    val coherence: Float,
    val magnitude: Float,
    val meanDiff: Float,
    val saturated: Boolean,
    val residual: FloatArray,
)

/** Pure Kotlin, no Android. Works on the [Gray] pictures made by FrameTools.gray. */
object Motion {
    const val RADIUS = 8

    /**
     * Below this average brightness change the screen counts as still (a frozen popup is 0.1 to 0.5 on a real phone,
     * a running dark game with the character standing still is 2 to 4, and a moving camera is 9 to 14).
     */
    private const val STILL = 1.0f

    fun analyze(prev: Gray, cur: Gray): MotionInfo? {
        if (prev.w != cur.w || prev.h != cur.h) return null
        val w = cur.w
        val h = cur.h
        val r = RADIUS
        val x0 = r
        val x1 = w - r
        val y0 = max(r, (h * 0.12f).toInt()) // skip the top bar (score, pause) ...
        val y1 = min(h - r, (h * 0.88f).toInt()) // ... and the bottom bar (controls)
        if (x1 - x0 < 8 || y1 - y0 < 8) return null

        fun sad(dx: Int, dy: Int): Float {
            var s = 0L
            var n = 0
            var y = y0
            while (y < y1) {
                val rowC = y * w
                val rowP = (y - dy) * w - dx
                var x = x0
                while (x < x1) {
                    s += abs(cur.px[rowC + x] - prev.px[rowP + x])
                    n++
                    x += 2
                }
                y += 2
            }
            return if (n == 0) 0f else s.toFloat() / n
        }

        val sad0 = sad(0, 0)
        if (sad0 < STILL) return MotionInfo(0, 0, 0f, 0f, sad0, false, FloatArray(9))

        var bestDx = 0
        var bestDy = 0
        var best = sad0
        for (dy in -r..r) {
            for (dx in -r..r) {
                if (dx == 0 && dy == 0) continue
                val s = sad(dx, dy)
                if (s < best) {
                    best = s
                    bestDx = dx
                    bestDy = dy
                }
            }
        }

        // Calibrated on a real dark game: when the camera really follows the character, ONE slide explains only 8 to 30
        // percent of the picture difference (enemies, particles and the HUD keep moving on their own), and the gain is
        // small in grey levels. When nothing slides, the best "slide" is no slide at all (gain 0).
        val gain = sad0 - best
        val rel = gain / sad0
        val coherence = if (gain < 0.35f || rel < 0.06f) 0f else (rel * 3f).coerceIn(0f, 1f)
        val mag = if (coherence == 0f) 0f else sqrt((bestDx * bestDx + bestDy * bestDy).toFloat())
        val sx = if (coherence == 0f) 0 else bestDx
        val sy = if (coherence == 0f) 0 else bestDy

        // what is still moving once the slide is taken out
        val sum = FloatArray(9)
        val cnt = IntArray(9)
        var y = y0
        while (y < y1) {
            val sectorY = min(2, (y - y0) * 3 / (y1 - y0))
            val rowC = y * w
            val rowP = (y - sy) * w - sx
            var x = x0
            while (x < x1) {
                val sectorX = min(2, (x - x0) * 3 / (x1 - x0))
                val k = sectorY * 3 + sectorX
                sum[k] += abs(cur.px[rowC + x] - prev.px[rowP + x]).toFloat()
                cnt[k]++
                x += 2
            }
            y += 2
        }
        val residual = FloatArray(9) { if (cnt[it] == 0) 0f else sum[it] / cnt[it] / 255f }

        return MotionInfo(sx, sy, coherence, mag, sad0, abs(bestDx) == r || abs(bestDy) == r, residual)
    }
}
