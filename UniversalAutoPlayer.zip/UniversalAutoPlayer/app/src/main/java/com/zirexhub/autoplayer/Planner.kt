package com.zirexhub.autoplayer

import java.util.Random
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** One line of on-screen text with its box, all values 0..1 of the screen. */
data class TextLine(val text: String, val l: Float, val t: Float, val r: Float, val b: Float) {
    val cx: Float get() = (l + r) / 2f
    val cy: Float get() = (t + b) / 2f
}

/** A colourful, button-like area of the screen (0..1). */
data class Blob(val cx: Float, val cy: Float, val w: Float, val h: Float, val score: Float)

/** A rectangle (0..1) the bot must never tap, e.g. its own floating chip. */
data class Zone(val l: Float, val t: Float, val r: Float, val b: Float) {
    fun contains(x: Float, y: Float, margin: Float = 0f): Boolean =
        x >= l - margin && x <= r + margin && y >= t - margin && y <= b + margin

    /** True if the box (l, t, r, b) touches this zone at all. */
    fun intersects(bl: Float, bt: Float, br: Float, bb: Float): Boolean =
        bl <= r && br >= l && bt <= b && bb >= t
}

/** Everything the offline brain "sees" in one frame. */
class Reading(val lines: List<TextLine>, val blobs: List<Blob>, val blocked: List<Zone> = emptyList())

/**
 * The offline brain's thinking. Pure Kotlin (no Android), so it can be unit tested.
 *
 *  1. READ   : on-screen text (from OCR) and button-like colour blobs.
 *  2. RULES  : close pop-ups, press Continue/Play/Next/Claim..., wait on loading screens,
 *              never touch anything that looks like buying / ads / logins.
 *  3. LEARN  : remembers per screen which targets changed something and which did nothing,
 *              and keeps global stats per button word. Score going up counts as a win too.
 *  4. EXPLORE: when no rule fits, an escalating ladder of ideas (tap test, swipes, centre taps,
 *              long press, wait) driven by a bandit that favours areas that made the screen react.
 *  5. BURST  : if the same target keeps working (clicker / tapper games) it sends fast tap bursts.
 */
class Planner(private val rnd: Random = Random()) {

    private class Stat {
        var tries = 0
        var hits = 0
    }

    private enum class Kind { TEXT, BLOB, GRID, SWIPE, CENTER, LONG }

    private class Target(
        val kind: Kind,
        val key: String,
        val x: Float,
        val y: Float,
        var score: Float,
        val why: String,
        val x2: Float = x,
        val y2: Float = y,
    )

    private val cols = 8
    private val rows = 14
    private val cells = cols * rows
    private val armValue = FloatArray(cells + 4)
    private val uses = IntArray(cells + 4)

    private val wordStat = HashMap<String, Stat>()
    private val screenStat = HashMap<String, Stat>()
    private val recentChanges = ArrayList<Float>()

    private var last: Target? = null
    private var lastSig = ""
    private var lastScore: Long? = null
    private var sameCount = 0
    private var streakKey: String? = null
    private var streak = 0
    private var loadingWaits = 0
    private var t = 1

    /** Short human-readable "what I plan to do and why" for the status line. */
    var lastPlan: String = ""
        private set

    fun decide(r: Reading, change: Float?, stuck: Int): Decision {
        t++
        val sig = signature(r)
        val score = scoreOf(r)
        val prevScore = lastScore
        val scoreUp = score != null && prevScore != null && score > prevScore
        val sigChanged = lastSig.isNotEmpty() && sig != lastSig
        val worked = (change != null && change > changeThreshold()) || scoreUp || sigChanged
        if (change != null) recordChange(change)

        creditLast(change, worked, scoreUp)

        sameCount = if (sig == lastSig) sameCount + 1 else 0
        val stuckLevel = max(stuck, sameCount)
        if (stuckLevel >= 10 && stuckLevel % 10 == 0) forgetScreen(sig)

        val decision = choose(r, sig, stuckLevel)
        lastSig = sig
        if (score != null) lastScore = score
        return decision
    }

    // ------------------------------------------------------------------ learning

    private fun creditLast(change: Float?, worked: Boolean, scoreUp: Boolean) {
        val prev = last ?: return
        if (change == null) return

        val ss = screenStat.getOrPut(lastSig + "|" + prev.key) { Stat() }
        ss.tries++
        if (worked) ss.hits++

        if (prev.kind == Kind.TEXT) {
            val ws = wordStat.getOrPut(prev.key) { Stat() }
            ws.tries++
            if (worked) ws.hits++
        }
        if (prev.kind == Kind.GRID || prev.kind == Kind.SWIPE) {
            val arm = armOf(prev)
            if (arm in armValue.indices) {
                uses[arm]++
                val reward = min(change, 0.5f) * 2f + (if (scoreUp) 0.6f else 0f)
                armValue[arm] += (reward - armValue[arm]) * max(1f / uses[arm], 0.25f)
                if (change > 0.45f) forgetHalf() // brand new scene: old knowledge is less reliable
            }
        }

        if (worked) {
            if (prev.key == streakKey) {
                streak++
            } else {
                streakKey = prev.key
                streak = 1
            }
        } else {
            streakKey = null
            streak = 0
        }
    }

    private fun armOf(tg: Target): Int = when (tg.kind) {
        Kind.GRID -> tg.key.substring(1).toIntOrNull() ?: -1
        Kind.SWIPE -> cells + (tg.key.substring(1).toIntOrNull() ?: -1)
        else -> -1
    }

    private fun forgetHalf() {
        for (i in armValue.indices) {
            armValue[i] *= 0.5f
            uses[i] = uses[i] / 2
        }
    }

    private fun forgetScreen(sig: String) {
        val prefix = "$sig|"
        val iter = screenStat.keys.iterator()
        while (iter.hasNext()) {
            if (iter.next().startsWith(prefix)) iter.remove()
        }
    }

    private fun recordChange(c: Float) {
        recentChanges.add(c)
        if (recentChanges.size > 15) recentChanges.removeAt(0)
    }

    /** Games with constant idle animation always "change"; only count clear spikes as an effect. */
    private fun changeThreshold(): Float {
        if (recentChanges.size < 4) return 0.02f
        val sorted = recentChanges.sorted()
        val median = sorted[sorted.size / 2]
        return (median * 1.6f).coerceIn(0.02f, 0.2f)
    }

    private fun learnBonus(key: String): Float {
        val s = wordStat[key] ?: return 0f
        return 30f * ((s.hits + 1f) / (s.tries + 2f) - 0.5f) * 2f
    }

    private fun deadPenalty(sig: String, key: String): Float {
        val s = screenStat[sig + "|" + key] ?: return 0f
        return if (s.hits == 0) 45f * s.tries else 0f
    }

    private fun isDead(sig: String, key: String): Boolean {
        val s = screenStat[sig + "|" + key] ?: return false
        return s.hits == 0 && s.tries >= 3
    }

    // ------------------------------------------------------------------ deciding

    private fun choose(r: Reading, sig: String, stuckLevel: Int): Decision {
        // Loading screens are normal: just wait (but not forever, it could be a frozen screen).
        val loading = r.lines.any { isLoading(normalize(it.text)) }
        if (loading && loadingWaits < 15) {
            loadingWaits++
            last = null
            lastPlan = "Loading screen detected, waiting"
            return Decision(GameAction.Wait(1200L), lastPlan, "wait loading")
        }
        if (!loading) loadingWaits = 0

        // Anything that looks like buying / ads / login is a no-go zone.
        val danger = ArrayList<TextLine>()
        for (ln in r.lines) {
            if (isDanger(ln.text, normalize(ln.text))) danger.add(ln)
        }
        val hasDanger = danger.isNotEmpty()

        fun nearDanger(x: Float, y: Float): Boolean =
            danger.any { x >= it.l - 0.05f && x <= it.r + 0.05f && y >= it.t - 0.04f && y <= it.b + 0.04f } ||
                r.blocked.any { it.contains(x, y, 0.02f) }

        val targets = ArrayList<Target>()
        for (ln in r.lines) {
            // Text that touches the agent's own chip is the chip talking, never a game button.
            if (r.blocked.any { it.intersects(ln.l, ln.t, ln.r, ln.b) }) continue
            val norm = normalize(ln.text)
            if (isDanger(ln.text, norm)) continue
            val prio = textPriority(ln, norm, hasDanger)
            if (prio <= 0f) continue
            val key = if (ln.text.trim().length == 1) "glyph" else norm.take(28)
            if (isDead(sig, key)) continue
            val s = prio + learnBonus(key) - deadPenalty(sig, key)
            targets.add(Target(Kind.TEXT, key, ln.cx, ln.cy, s, "Plan: press \"${norm.take(24)}\""))
        }
        for (b in r.blobs) {
            if (nearDanger(b.cx, b.cy)) continue
            val key = "b" + (b.cx * 10).toInt() + "_" + (b.cy * 10).toInt()
            if (isDead(sig, key)) continue
            val s = 25f + 25f * b.score - deadPenalty(sig, key)
            targets.add(Target(Kind.BLOB, key, b.cx, b.cy, s, "Plan: tap the colourful button-like area"))
        }

        val best = targets.maxByOrNull { it.score }
        val pick: Target = if (best != null && best.score >= 22f) {
            best
        } else {
            // No rule fits. Escalate through ideas the longer nothing happens.
            val ladder = stuckLevel % 14
            when {
                ladder == 12 -> return waitDecision("Idea: nothing reacts, waiting 2s in case it is loading", 2000L)
                ladder == 13 -> {
                    val spot = safeSpot(::nearDanger)
                        ?: return waitDecision("Idea: no safe spot to press, waiting", 1500L)
                    Target(Kind.LONG, "long", spot.first, spot.second, 10f, "Idea: press and hold an empty area")
                }
                ladder in 10..11 -> {
                    val spot = safeSpot(::nearDanger)
                        ?: return waitDecision("Idea: no safe spot to tap, waiting", 1500L)
                    Target(Kind.CENTER, "center", spot.first, spot.second, 10f, "Idea: tap an empty area of the screen")
                }
                ladder in 6..9 -> swipeTarget(ladder - 6, "Idea: stuck, trying a swipe")
                else -> banditPick(r, ::nearDanger)
            }
        }

        val burst = if (pick.key == streakKey && streak >= 2 &&
            (pick.kind == Kind.TEXT || pick.kind == Kind.BLOB || pick.kind == Kind.GRID || pick.kind == Kind.CENTER)
        ) {
            min(streak * 2, 16)
        } else {
            1
        }

        last = pick
        lastPlan = pick.why + (if (burst > 1) " (burst x$burst)" else "")
        return when (pick.kind) {
            Kind.SWIPE -> Decision(GameAction.Swipe(pick.x, pick.y, pick.x2, pick.y2, 280L), lastPlan, "swipe")
            Kind.LONG -> Decision(GameAction.LongPress(pick.x, pick.y, 800L), lastPlan, "long press")
            else -> Decision(
                GameAction.Tap(pick.x, pick.y, burst),
                lastPlan,
                "tap " + (pick.x * 100).toInt() + "%," + (pick.y * 100).toInt() + "%",
            )
        }
    }

    /** The last action was never performed (it would have hit the agent's own chip): do not count it as a miss. */
    fun cancelLast() {
        last = null
    }

    private fun waitDecision(why: String, ms: Long): Decision {
        last = null
        lastPlan = why
        return Decision(GameAction.Wait(ms), why, "wait idea")
    }

    /** First "empty-ish" point of the screen that is not next to buy / ad / login text. */
    private fun safeSpot(nearDanger: (Float, Float) -> Boolean): Pair<Float, Float>? =
        SPOTS.firstOrNull { !nearDanger(it.first, it.second) }

    private fun swipeTarget(dir: Int, why: String): Target = when (dir) {
        0 -> Target(Kind.SWIPE, "s0", 0.80f, 0.50f, 10f, "$why (left)", 0.20f, 0.50f)
        1 -> Target(Kind.SWIPE, "s1", 0.20f, 0.50f, 10f, "$why (right)", 0.80f, 0.50f)
        2 -> Target(Kind.SWIPE, "s2", 0.50f, 0.75f, 10f, "$why (up)", 0.50f, 0.25f)
        else -> Target(Kind.SWIPE, "s3", 0.50f, 0.25f, 10f, "$why (down)", 0.50f, 0.75f)
    }

    /** UCB bandit over a screen grid + 4 swipes: "tap anywhere", favouring spots that made things happen. */
    private fun banditPick(r: Reading, nearDanger: (Float, Float) -> Boolean): Target {
        var best = -1
        var bestScore = -1e9f
        for (arm in 0 until cells + 4) {
            var prior = 0.05f
            if (arm < cells) {
                val cx = ((arm % cols) + 0.5f) / cols
                val cy = ((arm / cols) + 0.5f) / rows
                if (nearDanger(cx, cy)) continue
                if (r.blobs.any { cx >= it.cx - it.w / 2 && cx <= it.cx + it.w / 2 && cy >= it.cy - it.h / 2 && cy <= it.cy + it.h / 2 }) {
                    prior += 0.35f
                }
            }
            val bonus = 0.6f * sqrt(ln(t.toFloat()) / (uses[arm] + 1))
            val s = armValue[arm] + bonus + prior + rnd.nextFloat() * 0.02f
            if (s > bestScore) {
                bestScore = s
                best = arm
            }
        }
        if (best < 0) return swipeTarget(0, "Explore: swipe test")
        if (best >= cells) return swipeTarget(best - cells, "Explore: swipe test")

        val row = best / cols
        val col = best % cols
        var x = 0.5f
        var y = 0.5f
        for (attempt in 0 until 6) {
            x = (col + 0.15f + rnd.nextFloat() * 0.7f) / cols
            y = (row + 0.15f + rnd.nextFloat() * 0.7f) / rows
            if (!nearDanger(x, y)) break
        }
        return Target(Kind.GRID, "g$best", x, y, 5f, "Explore: tap test at row ${row + 1}, col ${col + 1}")
    }

    // ------------------------------------------------------------------ text rules

    private fun textPriority(ln: TextLine, norm: String, hasDanger: Boolean): Float {
        val raw = ln.text.trim()
        val corner = ln.cy < 0.22f && (ln.cx > 0.65f || ln.cx < 0.3f)
        if (raw in CLOSE_GLYPHS) return if (corner) 95f else 0f
        if (norm.isEmpty()) return 0f
        if (norm in CLOSE_WORDS) return 100f
        val words = norm.split(' ').size
        val first = norm.substringBefore(' ')
        if (words <= 4 && first in REWARD_STARTERS) return 97f
        if (words <= 6 && (norm.startsWith("tap to ") || norm.startsWith("touch to ") ||
                norm.startsWith("press to ") || norm.startsWith("click to "))
        ) {
            return 88f
        }
        if (norm in SAFE_PROGRESS) return 90f
        if (words <= 4 && first in PROGRESS_STARTERS) return 80f
        if (!hasDanger && norm in CONFIRM_WORDS) return 85f
        return 0f
    }

    private fun isLoading(norm: String): Boolean {
        if (norm.isEmpty() || norm.split(' ').size > 5) return false
        return LOADING_PHRASES.any { norm.contains(it) }
    }

    private fun isDanger(raw: String, norm: String): Boolean {
        if (PRICE.containsMatchIn(raw)) return true
        if (norm.isEmpty()) return false
        if (norm.startsWith("skip") || norm.startsWith("close") ||
            norm.startsWith("get started") || norm.startsWith("get ready")
        ) {
            return false
        }
        for (p in DANGER_PHRASES) if (norm.contains(p)) return true
        for (tok in norm.split(' ')) if (tok in DANGER_WORDS) return true
        return false
    }

    // ------------------------------------------------------------------ helpers

    companion object {
        private val SPOTS = listOf(
            0.5f to 0.5f, 0.5f to 0.35f, 0.5f to 0.65f, 0.3f to 0.5f, 0.7f to 0.5f, 0.5f to 0.2f, 0.5f to 0.8f,
        )

        private val CLOSE_GLYPHS = setOf("x", "X", "×", "✕", "✖", "✗", "╳")

        private val CLOSE_WORDS = setOf(
            "close", "skip", "no thanks", "no thank you", "not now", "later", "maybe later",
            "cancel", "dismiss", "skip tutorial", "skip intro", "continue without",
        )

        private val SAFE_PROGRESS = setOf(
            "continue", "continue game", "next", "next level", "next stage", "next round", "play", "play again",
            "play now", "play on", "start", "start game", "start playing", "retry", "try again", "restart",
            "replay", "resume", "go", "lets go", "let s go", "begin", "proceed", "claim", "collect",
            "claim reward", "collect reward", "take reward", "new game", "tap here", "tap anywhere",
            "press start", "get started", "get ready", "level up", "keep playing",
        )

        private val REWARD_STARTERS = setOf("claim", "collect")

        private val PROGRESS_STARTERS = setOf(
            "continue", "next", "retry", "resume", "restart", "begin", "proceed", "replay", "start",
        )

        private val CONFIRM_WORDS = setOf("ok", "okay", "yes", "confirm", "done", "got it")

        private val LOADING_PHRASES = listOf(
            "loading", "please wait", "connecting", "downloading", "updating", "initializing",
            "checking for updates", "starting up",
        )

        private val DANGER_WORDS = setOf(
            "buy", "purchase", "subscribe", "subscription", "install", "download", "login", "password",
            "payment", "pay", "premium", "upgrade", "watch", "ad", "ads", "offer", "discount", "sale",
            "vip", "trial", "get", "shop", "store",
        )

        private val DANGER_PHRASES = listOf("sign in", "log in", "remove ads", "no ads", "free trial", "in app")

        // $ EUR GBP PHP JPY followed by a number, or a number followed by a currency code.
        private val PRICE = Regex("[$€£₱¥]\\s?\\d|\\d\\s?(usd|php|eur)", RegexOption.IGNORE_CASE)

        /** Lowercase letters/digits separated by single spaces. */
        fun normalize(s: String): String {
            val sb = StringBuilder()
            var lastSpace = true
            for (ch in s.lowercase()) {
                if (ch in 'a'..'z' || ch in '0'..'9') {
                    sb.append(ch)
                    lastSpace = false
                } else if (!lastSpace) {
                    sb.append(' ')
                    lastSpace = true
                }
            }
            return sb.toString().trim()
        }

        /** A fingerprint of the screen made from its words (numbers ignored so scores do not change it). */
        fun signature(r: Reading): String {
            val words = LinkedHashSet<String>()
            for (ln in r.lines) {
                for (tok in normalize(ln.text).split(' ')) {
                    if (tok.length >= 3 && tok.any { it in 'a'..'z' }) words.add(tok)
                }
            }
            if (words.isEmpty()) return "notext"
            return words.sorted().take(10).joinToString("-")
        }

        /** Biggest plain number in the top third of the screen, a rough "score" reading. */
        fun scoreOf(r: Reading): Long? {
            var best: Long? = null
            for (ln in r.lines) {
                if (ln.cy > 0.35f) continue
                val digits = ln.text.replace(",", "").replace(" ", "").replace(".", "")
                if (digits.isEmpty() || digits.length > 10 || !digits.all { it in '0'..'9' }) continue
                val v = digits.toLongOrNull() ?: continue
                val b = best
                if (b == null || v > b) best = v
            }
            return best
        }
    }
}
