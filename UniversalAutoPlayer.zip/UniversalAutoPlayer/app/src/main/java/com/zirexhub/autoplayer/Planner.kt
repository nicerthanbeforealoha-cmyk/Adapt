package com.zirexhub.autoplayer

import java.util.Random
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** One line of on-screen text with its box, all values 0..1 of the screen. */
data class TextLine(val text: String, val l: Float, val t: Float, val r: Float, val b: Float) {
    val cx: Float get() = (l + r) / 2f
    val cy: Float get() = (t + b) / 2f
}

/** A colourful, button-like area of the screen (0..1). */
data class Blob(val cx: Float, val cy: Float, val w: Float, val h: Float, val score: Float)

/** A rectangle (0..1) the bot must never tap, e.g. its own floating chip. */
data class Zone(val l: Float, val t: Float, val r: Float, val b: Float) {
    fun contains(x: Float, y: Float, margin: Float = 0f): Boolean =
        x >= l - margin && x <= r + margin && y >= t - margin && y <= b + margin

    /** True if the box (l, t, r, b) touches this zone at all. */
    fun intersects(bl: Float, bt: Float, br: Float, bb: Float): Boolean =
        bl <= r && br >= l && bt <= b && bb >= t
}

/** Everything the offline brain "sees" in one frame. */
class Reading(
    val lines: List<TextLine>,
    val blobs: List<Blob>,
    val blocked: List<Zone> = emptyList(),
    /** Screen height / width, so joystick circles come out round. */
    val aspect: Float = 2f,
)

/**
 * The offline brain's thinking. Pure Kotlin (no Android), so it can be unit tested.
 *
 *  1. READ   : on-screen text (from OCR) and button-like colour blobs.
 *  2. RULES  : close pop-ups, press Continue/Play/Next/Claim..., wait on loading screens,
 *              never touch anything that looks like buying / ads / logins.
 *  3. LEARN  : remembers per screen which targets changed something and which did nothing,
 *              and keeps global stats per button word. Score going up counts as a win too.
 *  4. EXPLORE: when no rule fits, an escalating ladder of ideas (tap test, swipes, centre taps,
 *              long press, wait) driven by a bandit that favours areas that made the screen react.
 *  5. BURST  : if the same target keeps working (clicker / tapper games) it sends fast tap bursts.
 *  6. STYLE  : when no rule fits and the game is live, the [Strategist] spends ~30 s finding out HOW the
 *              game is played (joystick drag, tap, swipe, hold), then plays that way and keeps adapting.
 *              Games that need two kinds of input (move AND press) get both, mixed.
 *  7. SURVIVE: basic rules that are always on: stay alive as long as possible (keep moving, run from what
 *              moves, avoid walls), decline risky deals (curses, pacts, sacrifices), prefer defensive upgrades,
 *              restart after a death and learn from how long each run lasted.
 *  8. UNSTICK: a screen that stays the same while nothing real happens (an animated popup, say) is never
 *              waited out: the bot works through its buttons, remembers the ones that do nothing, and finally
 *              tries Back.
 */
class Planner(private val rnd: Random = Random(), private val adaptive: Boolean = true) {

    private class Stat {
        var tries = 0
        var hits = 0
    }

    private enum class Kind { TEXT, BLOB, GRID, SWIPE, CENTER, LONG }

    private class Target(
        val kind: Kind,
        val key: String,
        val x: Float,
        val y: Float,
        var score: Float,
        val why: String,
        val x2: Float = x,
        val y2: Float = y,
        val ms: Long = 280L,
        val keep: Boolean = false,
        /** A second finger pressed while a held joystick push is on (move + press at once). */
        val tap: Pair<Float, Float>? = null,
        val tapArm: Int = -1,
    )

    /** The words seen on one kind of screen. Matching is fuzzy so animated text does not make a "new" screen. */
    private class Scene(val id: String, val words: MutableSet<String>)

    private val cols = 8
    private val rows = 14
    private val cells = cols * rows
    private val armValue = FloatArray(cells + 4)
    private val uses = IntArray(cells + 4)

    private val wordStat = HashMap<String, Stat>()
    private val screenStat = HashMap<String, Stat>()
    private val recentChanges = ArrayList<Float>()

    private var last: Target? = null
    private var lastSig = ""
    private val scenes = ArrayList<Scene>()
    private var sceneCounter = 0
    private var idleSteps = 0 // steps in a row where nothing REAL happened (animations do not count)
    private val banUntil = HashMap<String, Int>()
    private val failRun = HashMap<String, Int>()
    private val backTried = HashMap<String, Int>()
    private var runStartMs = -1L
    private var deaths = 0
    private val notes = ArrayList<String>()
    private val blobSeen = HashMap<String, Int>() // colour area at this spot -> in how many reads in a row it was there
    private var lastBlobList: Any? = null
    private var staticBlobs: List<Blob> = emptyList() // always in the same place = a HUD button, not an enemy
    private var liveNow = false
    private var lastEngagedStep = -1000
    private var calmSteps = 0
    private var hpFrac = -1f
    private var lastLinesRef: Any? = null
    private var lastScore: Long? = null
    private var sameCount = 0
    private var streakKey: String? = null
    private var streak = 0
    private var loadingWaits = 0
    private var t = 1

    private val strategist = Strategist(rnd)
    private var nowMs = 0L
    private var motion: MotionInfo? = null
    private val liveHistory = ArrayList<Boolean>()
    private var frozenSteps = 0
    private var midEma = 1f // how many words a normal frame of this game has in the middle of the screen
    private var popupMode = false

    /** Short human-readable "what I plan to do and why" for the status line. */
    var lastPlan: String = ""
        private set

    /** True once the game has been recognised as a joystick / drag-to-move game. */
    fun movementMode(): Boolean = adaptive && strategist.moveConfirmed()

    /** What the bot has worked out about the game, for the chip and the debug log. */
    fun styleStatus(): String = strategist.status(nowMs)

    fun styleDetails(): String = strategist.describe()

    /** One line about lives and deaths, for the debug log. */
    fun survivalStatus(): String = strategist.survivalStatus()

    /** Things worth writing in the debug log (deaths, learned survival styles). Reading them empties the list. */
    fun takeNotes(): List<String> {
        if (notes.isEmpty()) return emptyList()
        val out = ArrayList(notes)
        notes.clear()
        return out
    }

    /** True when the screen text says the character died / the run is over. */
    private fun deathOnScreen(r: Reading): Boolean = r.lines.any { isDeath(normalize(it.text)) }

    /** Times a run from "game is live" to "game over", so the Strategist can learn which survival style lasts longest. */
    private fun trackRun(r: Reading, now: Long) {
        if (!adaptive) return
        if (deathOnScreen(r)) {
            runEnded(now)
            return
        }
        val live = liveHistory.count { it } >= 3 && frozenSteps == 0
        if (runStartMs < 0 && live) {
            runStartMs = now
            strategist.startRun(now)
        }
    }

    /** A colour area that sits in the same place read after read is a screen button (skill, pause, ...); things that move are not. */
    private fun trackBlobs(r: Reading) {
        if (r.blobs === lastBlobList) return // the same (cached) reading again, nothing new to count
        lastBlobList = r.blobs
        val present = HashSet<String>()
        for (b in r.blobs) present.add(blobCell(b))
        val iter = blobSeen.keys.iterator()
        while (iter.hasNext()) if (iter.next() !in present) iter.remove()
        for (k in present) blobSeen[k] = (blobSeen[k] ?: 0) + 1
        staticBlobs = r.blobs.filter { (blobSeen[blobCell(it)] ?: 0) >= 5 }
    }

    private fun blobCell(b: Blob) = (b.cx * 20).toInt().toString() + "_" + (b.cy * 20).toInt()

    /** The run is over (death text seen, or the bot is pressing Retry): learn from how long it lasted. */
    private fun runEnded(now: Long) {
        if (runStartMs < 0) return
        runStartMs = -1L
        deaths++
        val note = strategist.endRun(now)
        if (note.isNotEmpty()) notes.add(note)
    }

    // ------------------------------------------------------------------ scenes

    /**
     * Which kind of screen is this? Screens are matched by the words they share, so a popup whose speech
     * bubble text keeps changing is still ONE screen (and "I already tried this button here" keeps working).
     */
    private fun sceneFor(r: Reading): String {
        val w = wordSet(r)
        if (w.isEmpty()) return "notext"
        val need = if (w.size <= 4) 0.75f else 0.55f
        var best: Scene? = null
        var bestOv = 0f
        for (sc in scenes) {
            var shared = 0
            for (x in w) if (x in sc.words) shared++
            val ov = shared.toFloat() / w.size
            if (ov >= need && ov > bestOv) {
                best = sc
                bestOv = ov
            }
        }
        if (best != null) {
            if (best.words.size < 48) best.words.addAll(w)
            scenes.remove(best)
            scenes.add(best) // most recent last
            return best.id
        }
        sceneCounter++
        val sc = Scene(w.sorted().take(10).joinToString("-") + "#" + sceneCounter, LinkedHashSet(w))
        scenes.add(sc)
        if (scenes.size > 16) scenes.removeAt(0)
        return sc.id
    }

    fun decide(r: Reading, change: Float?, stuck: Int, motion: MotionInfo? = null, nowMs: Long = 0L): Decision {
        t++
        this.motion = motion
        this.nowMs = nowMs
        val sig = sceneFor(r)
        trackBlobs(r)
        val score = scoreOf(r)
        val prevScore = lastScore
        val scoreUp = score != null && prevScore != null && score > prevScore
        val sigChanged = lastSig.isNotEmpty() && sig != lastSig
        val thr = changeThreshold()
        val worked = (change != null && change > thr) || scoreUp || sigChanged
        // A REAL effect is stricter: a new screen, a score going up, the whole scene sliding, or a big jump.
        // An animated popup (a talking demon) always "changes a bit", which must not count as a button working.
        val engaged = motion != null && motion.coherence >= 0.4f && motion.magnitude >= 1.0f
        val real = scoreUp || sigChanged || engaged || (change != null && change > max(0.10f, thr * 1.6f))
        if (change != null) recordChange(change)
        if (engaged) lastEngagedStep = t
        calmSteps = if (change == null || change < 0.02f) calmSteps + 1 else 0
        trackHp(r)

        val pressed = last
        creditLast(change, worked, real, scoreUp)
        if (adaptive) {
            strategist.observe(change, motion, scoreUp)
            if (sigChanged && pressed != null && (pressed.kind == Kind.TEXT || pressed.kind == Kind.BLOB)) {
                strategist.newContext()
            }
        }
        idleSteps = if (real) 0 else idleSteps + 1

        // "Same words on screen" only means stuck if the picture is not moving either (a live game
        // keeps the same HUD text for minutes).
        val still = change == null || change < 0.008f
        sameCount = if (sig == lastSig && still) sameCount + 1 else 0
        trackLiveness(change)
        trackRun(r, nowMs)
        val stuckLevel = max(stuck, sameCount)
        if (stuckLevel >= 10 && stuckLevel % 10 == 0) forgetScreen(sig)

        val decision = choose(r, sig, stuckLevel)
        lastSig = sig
        if (score != null) lastScore = score
        return decision
    }

    // ------------------------------------------------------------------ learning

    /** Remembers whether the picture was moving, to spot "the action froze and a choice popped up". */
    private fun trackLiveness(change: Float?) {
        if (change == null) return
        liveHistory.add(change > 0.03f)
        if (liveHistory.size > 8) liveHistory.removeAt(0)
        frozenSteps = if (change < 0.006f) frozenSteps + 1 else 0
    }

    /** The game was busy a moment ago and has just frozen: a level-up / reward / game-over popup. */
    private fun looksLikeChoiceMenu(): Boolean =
        adaptive && frozenSteps in 1..6 && liveHistory.count { it } >= 3

    private fun creditLast(change: Float?, worked: Boolean, real: Boolean, scoreUp: Boolean) {
        val prev = last ?: return
        if (change == null) return

        // "does this button do anything on this screen" is judged by REAL effects only
        val ss = screenStat.getOrPut(lastSig + "|" + prev.key) { Stat() }
        ss.tries++
        if (real) ss.hits++

        if (prev.kind == Kind.TEXT || prev.kind == Kind.BLOB) {
            // Same target, nothing real, three times in a row = leave it alone for a while, whatever screen it is.
            if (real) {
                failRun[prev.key] = 0
            } else {
                val n = (failRun[prev.key] ?: 0) + 1
                failRun[prev.key] = n
                if (n >= 3) {
                    banUntil[prev.key] = t + 30
                    failRun[prev.key] = 0
                }
            }
        }

        if (prev.kind == Kind.TEXT) {
            val ws = wordStat.getOrPut(prev.key) { Stat() }
            ws.tries++
            if (real) ws.hits++
        }
        if (prev.tapArm in armValue.indices) {
            // the extra finger of a move + press combo: credit the button spot only when a number went up
            val arm = prev.tapArm
            uses[arm]++
            val reward = if (scoreUp) 1f else 0.2f // no number went up: unknown, so neutral, not "failed"

            armValue[arm] += (reward - armValue[arm]) * max(1f / uses[arm], 0.25f)
        }
        if (prev.kind == Kind.GRID || prev.kind == Kind.SWIPE) {
            val arm = armOf(prev)
            if (arm in armValue.indices) {
                uses[arm]++
                val reward = min(change, 0.5f) * 2f + (if (scoreUp) 0.6f else 0f)
                armValue[arm] += (reward - armValue[arm]) * max(1f / uses[arm], 0.25f)
                if (change > 0.45f) forgetHalf() // brand new scene: old knowledge is less reliable
            }
        }

        // bursts of taps only for targets that did something REAL (a clicker's coin), not for "the screen moved a bit"
        val good = if (prev.kind == Kind.GRID || prev.kind == Kind.CENTER) worked else real
        if (good) {
            if (prev.key == streakKey) {
                streak++
            } else {
                streakKey = prev.key
                streak = 1
            }
        } else {
            streakKey = null
            streak = 0
        }
    }

    private fun armOf(tg: Target): Int = when (tg.kind) {
        Kind.GRID -> tg.key.substring(1).toIntOrNull() ?: -1
        Kind.SWIPE -> cells + (tg.key.substring(1).toIntOrNull() ?: -1)
        else -> -1
    }

    private fun forgetHalf() {
        for (i in armValue.indices) {
            armValue[i] *= 0.5f
            uses[i] = uses[i] / 2
        }
    }

    private fun forgetScreen(sig: String) {
        val prefix = "$sig|"
        val iter = screenStat.keys.iterator()
        while (iter.hasNext()) {
            if (iter.next().startsWith(prefix)) iter.remove()
        }
    }

    private fun recordChange(c: Float) {
        recentChanges.add(c)
        if (recentChanges.size > 15) recentChanges.removeAt(0)
    }

    /** Games with constant idle animation always "change"; only count clear spikes as an effect. */
    private fun changeThreshold(): Float {
        if (recentChanges.size < 4) return 0.02f
        val sorted = recentChanges.sorted()
        val median = sorted[sorted.size / 2]
        return (median * 1.6f).coerceIn(0.02f, 0.2f)
    }

    private fun learnBonus(key: String): Float {
        val s = wordStat[key] ?: return 0f
        return 30f * ((s.hits + 1f) / (s.tries + 2f) - 0.5f) * 2f
    }

    private fun deadPenalty(sig: String, key: String): Float {
        val s = screenStat[sig + "|" + key] ?: return 0f
        return if (s.hits == 0) 45f * s.tries else 0f
    }

    private fun isDead(sig: String, key: String): Boolean {
        val s = screenStat[sig + "|" + key] ?: return false
        return s.hits == 0 && s.tries >= 3
    }

    // ------------------------------------------------------------------ deciding

    private fun choose(r: Reading, sig: String, stuckLevel: Int): Decision {
        // Loading screens are normal: just wait (but not forever, it could be a frozen screen).
        val loading = r.lines.any { isLoading(normalize(it.text)) }
        if (loading && loadingWaits < 15) {
            loadingWaits++
            last = null
            lastPlan = "Loading screen detected, waiting"
            return Decision(GameAction.Wait(1200L), lastPlan, "wait loading")
        }
        if (!loading) loadingWaits = 0

        val midCount = r.lines.count { it.cy in 0.22f..0.88f && normalize(it.text).length >= 3 }
        val confident = adaptive && (strategist.moveConfirmed() || (strategist.style() != null && strategist.confidence() >= 0.5f))
        // Same screen for a while and nothing REAL happened, we do not know how this game is played, and the screen
        // has real button-like words on it: a menu or popup is holding us (an animated one never looks "still", so it
        // is judged by what our presses achieved). HUD text and numbers of a running game are not buttons.
        val buttonLike = r.lines.count { isButtonLike(it) }
        val engagedRecently = t - lastEngagedStep < 40
        val stagnant = adaptive && idleSteps >= 4 && !confident && !engagedRecently && buttonLike >= 2

        // Anything that looks like buying / ads / login is a no-go zone.
        val danger = ArrayList<TextLine>()
        for (ln in r.lines) {
            if (isDanger(ln.text, normalize(ln.text))) danger.add(ln)
        }
        val hasDanger = danger.isNotEmpty()

        fun nearDanger(x: Float, y: Float): Boolean =
            danger.any { x >= it.l - 0.05f && x <= it.r + 0.05f && y >= it.t - 0.04f && y <= it.b + 0.04f } ||
                r.blocked.any { it.contains(x, y, 0.02f) }

        val targets = ArrayList<Target>()
        for (ln in r.lines) {
            // Text that touches the agent's own chip is the chip talking, never a game button.
            if (r.blocked.any { it.intersects(ln.l, ln.t, ln.r, ln.b) }) continue
            val norm = normalize(ln.text)
            if (isDanger(ln.text, norm)) continue
            val prio = textPriority(ln, norm, hasDanger)
            if (prio <= 0f) continue
            val key = if (ln.text.trim().length == 1) "glyph" else norm.take(28)
            if (isDead(sig, key) || isBanned(key)) continue
            val s = prio + learnBonus(key) - deadPenalty(sig, key)
            targets.add(Target(Kind.TEXT, key, ln.cx, ln.cy, s, "Plan: press \"${norm.take(24)}\""))
        }
        // In a live game the screen is full of coloured things (enemies, gems, bars), none of them buttons.
        val liveGame = adaptive && liveHistory.count { it } >= 4 && frozenSteps == 0
        liveNow = liveGame
        // Coloured areas are only treated as buttons on a calm screen (or a stuck popup). In a running game they are
        // enemies, bars and icons; the first few steps of a game count as running too.
        val blobsOk = stagnant || (!liveGame && (liveHistory.size >= 4 || calmSteps >= 1))
        for (b in (if (blobsOk) r.blobs else emptyList())) {
            if (nearDanger(b.cx, b.cy)) continue
            if (r.blocked.any { it.contains(b.cx, b.cy, 0.02f) }) continue
            val key = "b" + (b.cx * 10).toInt() + "_" + (b.cy * 10).toInt()
            if (isDead(sig, key) || isBanned(key)) continue
            // wide and flat = looks like a button, big and roundish = a picture (a face, an enemy)
            val shape = if (b.w / max(b.h, 0.01f) >= 2.2f && b.h <= 0.12f) 12f else if (b.w * b.h > 0.06f) -12f else 0f
            val s = 25f + 25f * b.score + shape - deadPenalty(sig, key)
            targets.add(Target(Kind.BLOB, key, b.cx, b.cy, s, "Plan: tap the colourful button-like area"))
        }

        // Words suddenly filled the middle of a live game, or the action froze: an upgrade / reward / choice popup.
        // Pick the line that looks most like a button (short, on a button-shaped colour area, not a question, not a
        // risky deal) and prefer defensive upgrades. Options that do nothing get remembered and skipped.
        if (adaptive) {
            if (!popupMode && liveHistory.count { it } >= 3 && midCount >= 3 && midCount >= midEma + 2f) popupMode = true
            else if (popupMode && midCount < 3) popupMode = false
            if (!popupMode) midEma = 0.9f * midEma + 0.1f * midCount
        }
        if ((looksLikeChoiceMenu() || popupMode || stagnant) && targets.none { it.score >= 60f }) {
            val desperate = idleSteps >= 6
            for (ln in r.lines) {
                if (ln.cy < 0.12f || ln.cy > 0.97f) continue
                if (r.blocked.any { it.intersects(ln.l, ln.t, ln.r, ln.b) }) continue
                val norm = normalize(ln.text)
                if (norm.length < 3 || isDanger(ln.text, norm)) continue
                val key = "pick:" + norm.take(24)
                if (isDead(sig, key) || isBanned(key)) continue
                var s = pickScore(ln, norm, r.blobs) - deadPenalty(sig, key)
                if (s < 22f) {
                    if (!desperate) continue
                    s = 22f - deadPenalty(sig, key) / 100f // last resort: try every line once, in a fixed order
                }
                targets.add(Target(Kind.TEXT, key, ln.cx, ln.cy, s, "Plan: choosing \"${norm.take(20)}\""))
            }
        }

        // The popup will not close whatever we press: Android's Back button closes most of them.
        if (adaptive && idleSteps >= 8 && buttonLike >= 3 && !engagedRecently && (backTried[sig] ?: 0) < 1 &&
            targets.none { it.score >= 80f }
        ) {
            backTried[sig] = (backTried[sig] ?: 0) + 1
            last = null
            lastPlan = "Idea: this popup will not close, pressing Back"
            return Decision(GameAction.Back, lastPlan, "back")
        }

        val best = targets.maxByOrNull { it.score }
        val pick: Target = if (best != null && best.score >= 22f) {
            best
        } else if (adaptive && stuckLevel < 12) {
            // Gameplay with no button to press: work out HOW this game is played, then play that way.
            when (val mv = strategist.next(nowMs, r.aspect, { x, y -> !nearDanger(x, y) }, motion)) {
                is Move.Idle -> return waitDecision(mv.why, mv.ms)
                is Move.Tap -> banditPick(r, ::nearDanger).let {
                    Target(it.kind, it.key, it.x, it.y, it.score, strategist.status(nowMs) + ": " + it.why)
                }
                is Move.Drag -> {
                    var extra: Target? = null
                    if (mv.withTap) {
                        val bt = banditPick(r, ::nearDanger)
                        if (bt.kind == Kind.GRID) extra = bt
                    }
                    Target(
                        Kind.SWIPE, "drag", mv.ax, mv.ay, 10f,
                        mv.why + (if (extra != null) " + press" else ""),
                        mv.tx, mv.ty, mv.ms, true,
                        extra?.let { it.x to it.y }, extra?.let { armOf(it) } ?: -1,
                    )
                }
                is Move.Swipe -> Target(Kind.SWIPE, "swipe", mv.x1, mv.y1, 10f, mv.why, mv.x2, mv.y2, mv.ms, false)
                is Move.Hold -> Target(Kind.LONG, "hold", mv.x, mv.y, 10f, mv.why, ms = mv.ms)
            }
        } else {
            // No rule fits. Escalate through ideas the longer nothing happens.
            val ladder = stuckLevel % 14
            when {
                ladder == 12 -> return waitDecision("Idea: nothing reacts, waiting 2s in case it is loading", 2000L)
                ladder == 13 -> {
                    val spot = safeSpot(::nearDanger)
                        ?: return waitDecision("Idea: no safe spot to press, waiting", 1500L)
                    Target(Kind.LONG, "long", spot.first, spot.second, 10f, "Idea: press and hold an empty area", ms = 800L)
                }
                ladder in 10..11 -> {
                    val spot = safeSpot(::nearDanger)
                        ?: return waitDecision("Idea: no safe spot to tap, waiting", 1500L)
                    Target(Kind.CENTER, "center", spot.first, spot.second, 10f, "Idea: tap an empty area of the screen")
                }
                ladder in 6..9 -> swipeTarget(ladder - 6, "Idea: stuck, trying a swipe")
                else -> banditPick(r, ::nearDanger)
            }
        }

        val burst = if (pick.key == streakKey && streak >= 2 &&
            (pick.kind == Kind.TEXT || pick.kind == Kind.BLOB || pick.kind == Kind.GRID || pick.kind == Kind.CENTER)
        ) {
            min(streak * 2, if (adaptive && strategist.isMixed()) 4 else 16)
        } else {
            1
        }

        if (pick.kind == Kind.TEXT && pick.key in RETRY_KEYS) runEnded(nowMs)
        last = pick
        lastPlan = pick.why + (if (burst > 1) " (burst x$burst)" else "")
        return when (pick.kind) {
            Kind.SWIPE -> Decision(
                GameAction.Swipe(pick.x, pick.y, pick.x2, pick.y2, pick.ms, pick.keep, pick.tap?.let { listOf(it) } ?: emptyList()),
                lastPlan,
                if (pick.keep) "drag" else "swipe",
            )
            Kind.LONG -> Decision(GameAction.LongPress(pick.x, pick.y, pick.ms), lastPlan, "long press")
            else -> Decision(
                GameAction.Tap(pick.x, pick.y, burst),
                lastPlan,
                "tap " + (pick.x * 100).toInt() + "%," + (pick.y * 100).toInt() + "%",
            )
        }
    }

    /** The last action was never performed (it would have hit the agent's own chip): do not count it as a miss. */
    fun cancelLast() {
        last = null
    }

    private fun isBanned(key: String): Boolean = (banUntil[key] ?: 0) > t

    /** How button-like and how safe a line of text is as a popup choice. About 40 is average. */
    private fun pickScore(ln: TextLine, norm: String, blobs: List<Blob>): Float {
        var s = 40f
        val words = norm.split(' ')
        if (words.size <= 3) s += 12f else if (words.size >= 6) s -= 18f else if (words.size >= 5) s -= 8f
        if (norm.length > 28) s -= 10f
        val raw = ln.text.trim()
        if (raw.endsWith("?") || raw.endsWith(".") || raw.endsWith("...") || raw.endsWith("!")) s -= 15f // titles, speech
        if (ln.b - ln.t > 0.05f) s -= 6f // giant title lettering
        // sits on a colour area that is wide and flat like a button
        if (blobs.any {
                ln.cx >= it.cx - it.w / 2 && ln.cx <= it.cx + it.w / 2 && ln.cy >= it.cy - it.h / 2 && ln.cy <= it.cy + it.h / 2 &&
                    it.w / max(it.h, 0.01f) >= 1.6f && it.h <= 0.14f
            }
        ) {
            s += 10f
        }
        // survival rules: pick what keeps the character alive, stay away from curses and deals
        for (tok in words) {
            if (tok in SURVIVE_GOOD) s += 12f
            if (tok in SURVIVE_RISKY) s -= 20f
        }
        return s
    }

    private fun waitDecision(why: String, ms: Long): Decision {
        last = null
        lastPlan = why
        return Decision(GameAction.Wait(ms), why, "wait idea")
    }

    /** First "empty-ish" point of the screen that is not next to buy / ad / login text. */
    private fun safeSpot(nearDanger: (Float, Float) -> Boolean): Pair<Float, Float>? =
        SPOTS.firstOrNull { !nearDanger(it.first, it.second) }

    private fun swipeTarget(dir: Int, why: String): Target = when (dir) {
        0 -> Target(Kind.SWIPE, "s0", 0.80f, 0.50f, 10f, "$why (left)", 0.20f, 0.50f)
        1 -> Target(Kind.SWIPE, "s1", 0.20f, 0.50f, 10f, "$why (right)", 0.80f, 0.50f)
        2 -> Target(Kind.SWIPE, "s2", 0.50f, 0.75f, 10f, "$why (up)", 0.50f, 0.25f)
        else -> Target(Kind.SWIPE, "s3", 0.50f, 0.25f, 10f, "$why (down)", 0.50f, 0.75f)
    }

    /** Fixed colour areas that may really be buttons: not the top bar, not thin bars (health, XP, slots), not the middle (our own character). */
    private fun pressableFixed(r: Reading, nearDanger: (Float, Float) -> Boolean): List<Blob> =
        staticBlobs.filter {
            it.cy > 0.18f && it.h >= 0.03f && !nearDanger(it.cx, it.cy) &&
                r.blocked.none { z -> z.contains(it.cx, it.cy, 0.02f) } &&
                !(strategist.moveConfirmed() && kotlin.math.abs(it.cx - 0.5f) < 0.2f && kotlin.math.abs(it.cy - 0.5f) < 0.2f)
        }

    /** A short word-only line (1 to 3 words, no digits): what a button or a menu choice looks like, not HUD numbers. */
    private fun isButtonLike(ln: TextLine): Boolean {
        if (ln.cy < 0.2f || ln.cy > 0.97f) return false
        val norm = normalize(ln.text)
        if (norm.length < 3 || norm.length > 22 || norm.any { it in '0'..'9' }) return false
        val words = norm.split(' ').size
        return words <= 3 && !isDanger(ln.text, norm)
    }

    /** Reads "80 / 100" style health text. Losing health makes the bot run away harder and change direction. */
    private fun trackHp(r: Reading) {
        if (!adaptive || r.lines === lastLinesRef) return // the same (cached) reading again
        lastLinesRef = r.lines
        var frac = -1f
        for (ln in r.lines) {
            val m = HP_TEXT.matchEntire(ln.text.trim()) ?: continue
            val a = m.groupValues[1].toIntOrNull() ?: continue
            val b = m.groupValues[2].toIntOrNull() ?: continue
            if (b >= 3 && a <= b) {
                frac = a.toFloat() / b
                break
            }
        }
        if (frac < 0f) return
        if (hpFrac >= 0f && frac < hpFrac - 0.04f) {
            strategist.hurt()
            notes.add("HURT: health ${(hpFrac * 100).toInt()}% -> ${(frac * 100).toInt()}%, running away / changing direction")
        }
        hpFrac = frac
    }

    private fun cellOf(b: Blob): Int =
        (b.cy * rows).toInt().coerceIn(0, rows - 1) * cols + (b.cx * cols).toInt().coerceIn(0, cols - 1)

    /** Is the middle of this colour area inside grid cell [arm]? */
    private fun inCell(b: Blob, arm: Int): Boolean {
        val col = arm % cols
        val row = arm / cols
        return (b.cx * cols).toInt().coerceIn(0, cols - 1) == col && (b.cy * rows).toInt().coerceIn(0, rows - 1) == row
    }

    /** UCB bandit over a screen grid + 4 swipes: "tap anywhere", favouring spots that made things happen. */
    private fun banditPick(r: Reading, nearDanger: (Float, Float) -> Boolean): Target {
        // Screen buttons that never move (a skill button, a coin) are pressed over and over, favouring the ones
        // that paid off, instead of being re-discovered among 112 grid cells every time.
        val fixed = pressableFixed(r, nearDanger)
        if (fixed.isNotEmpty() && rnd.nextFloat() < 0.6f) {
            var total = 0f
            val w = FloatArray(fixed.size)
            for ((i, b) in fixed.withIndex()) {
                val arm = cellOf(b)
                w[i] = if (uses[arm] < 2) 0.6f else 0.05f + 1.5f * max(0f, armValue[arm])
                // skill and attack buttons live in the lower corners; anything else that never moves is mostly HUD
                if (!(b.cy > 0.6f && (b.cx < 0.3f || b.cx > 0.7f))) w[i] *= 0.25f
                total += w[i]
            }
            var roll = rnd.nextFloat() * total
            var pick = fixed.last()
            for ((i, b) in fixed.withIndex()) {
                roll -= w[i]
                if (roll <= 0f) {
                    pick = b
                    break
                }
            }
            val arm = cellOf(pick)
            val bx = (pick.cx + (rnd.nextFloat() - 0.5f) * pick.w * 0.4f).coerceIn(0.01f, 0.99f)
            val by = (pick.cy + (rnd.nextFloat() - 0.5f) * pick.h * 0.4f).coerceIn(0.01f, 0.99f)
            return Target(Kind.GRID, "g$arm", bx, by, 5f, "Explore: press the fixed button at row ${arm / cols + 1}, col ${arm % cols + 1}")
        }
        val hudGuard = strategist.moveConfirmed()
        var best = -1
        var bestScore = -1e9f
        for (arm in 0 until cells + 4) {
            var prior = 0.05f
            if (arm < cells) {
                val cx = ((arm % cols) + 0.5f) / cols
                val cy = ((arm / cols) + 0.5f) / rows
                if (nearDanger(cx, cy)) continue
                // in a movement game random presses stay away from the top bar (pause, settings) and from our own character
                if (hudGuard && (cy < 0.18f || (kotlin.math.abs(cx - 0.5f) < 0.2f && kotlin.math.abs(cy - 0.5f) < 0.2f))) continue
                if (fixed.any { inCell(it, arm) }) {
                    prior += 0.8f // a button that never moves: the best place to try pressing
                } else if (r.blobs.any { cx >= it.cx - it.w / 2 && cx <= it.cx + it.w / 2 && cy >= it.cy - it.h / 2 && cy <= it.cy + it.h / 2 }) {
                    prior += if (liveNow) 0.1f else 0.35f // in a live game coloured things are mostly enemies
                }
            }
            val bonus = 0.6f * sqrt(ln(t.toFloat()) / (uses[arm] + 1))
            val s = armValue[arm] + bonus + prior + rnd.nextFloat() * 0.02f
            if (s > bestScore) {
                bestScore = s
                best = arm
            }
        }
        if (best < 0) return swipeTarget(0, "Explore: swipe test")
        if (best >= cells) return swipeTarget(best - cells, "Explore: swipe test")

        val row = best / cols
        val col = best % cols
        var x = 0.5f
        var y = 0.5f
        val btn = fixed.firstOrNull { inCell(it, best) }
        if (btn != null) {
            // press the middle of the button, not a random point of the grid cell
            val bx = (btn.cx + (rnd.nextFloat() - 0.5f) * btn.w * 0.4f).coerceIn(0.01f, 0.99f)
            val by = (btn.cy + (rnd.nextFloat() - 0.5f) * btn.h * 0.4f).coerceIn(0.01f, 0.99f)
            return Target(Kind.GRID, "g$best", bx, by, 5f, "Explore: press the fixed button at row ${row + 1}, col ${col + 1}")
        }
        for (attempt in 0 until 6) {
            x = (col + 0.15f + rnd.nextFloat() * 0.7f) / cols
            y = (row + 0.15f + rnd.nextFloat() * 0.7f) / rows
            if (!nearDanger(x, y)) break
        }
        return Target(Kind.GRID, "g$best", x, y, 5f, "Explore: tap test at row ${row + 1}, col ${col + 1}")
    }

    // ------------------------------------------------------------------ text rules

    private fun textPriority(ln: TextLine, norm: String, hasDanger: Boolean): Float {
        val raw = ln.text.trim()
        val corner = ln.cy < 0.22f && (ln.cx > 0.65f || ln.cx < 0.3f)
        if (raw in CLOSE_GLYPHS) return if (corner) 95f else 0f
        if (norm.isEmpty()) return 0f
        if (norm in CLOSE_WORDS) return 100f
        val words = norm.split(' ').size
        val first = norm.substringBefore(' ')
        if (words <= 4 && first in REWARD_STARTERS) return 97f
        if (words <= 6 && (norm.startsWith("tap to ") || norm.startsWith("touch to ") ||
                norm.startsWith("press to ") || norm.startsWith("click to "))
        ) {
            return 88f
        }
        if (norm in SAFE_PROGRESS) return 90f
        if (words <= 4 && first in PROGRESS_STARTERS) return 80f
        if (!hasDanger && norm in CONFIRM_WORDS) return 85f
        return 0f
    }

    private fun isLoading(norm: String): Boolean {
        if (norm.isEmpty() || norm.split(' ').size > 5) return false
        return LOADING_PHRASES.any { norm.contains(it) }
    }

    private fun isDanger(raw: String, norm: String): Boolean {
        if (PRICE.containsMatchIn(raw)) return true
        if (norm.isEmpty()) return false
        if (norm.startsWith("skip") || norm.startsWith("close") ||
            norm.startsWith("get started") || norm.startsWith("get ready")
        ) {
            return false
        }
        if (isLoginDanger(norm)) return true
        for (p in DANGER_PHRASES) if (norm.contains(p)) return true
        for (tok in norm.split(' ')) if (tok in DANGER_WORDS) return true
        return false
    }

    /**
     * "Sign in" / "log in" / "sign up" as an ACCOUNT action. A game can use the same words for something else
     * ("SIGN IN BLOOD" on a devil's contract), so it only counts when it stands alone or is followed by a
     * login word ("sign in with Google", "log in to continue").
     */
    private fun isLoginDanger(norm: String): Boolean {
        for (p in LOGIN_PHRASES) {
            var from = 0
            while (true) {
                val i = norm.indexOf(p, from)
                if (i < 0) break
                from = i + p.length
                if (i > 0 && norm[i - 1] != ' ') continue // "design in" is not "sign in"
                val after = norm.substring(i + p.length).trim()
                if (after.isEmpty()) return true
                if (after.substringBefore(' ') in LOGIN_FOLLOW) return true
            }
        }
        return false
    }

    private fun isDeath(norm: String): Boolean {
        if (norm.isEmpty() || norm.split(' ').size > 7) return false
        return DEATH_PHRASES.any { norm.contains(it) }
    }

    // ------------------------------------------------------------------ helpers

    companion object {
        private val SPOTS = listOf(
            0.5f to 0.5f, 0.5f to 0.35f, 0.5f to 0.65f, 0.3f to 0.5f, 0.7f to 0.5f, 0.5f to 0.2f, 0.5f to 0.8f,
        )

        private val CLOSE_GLYPHS = setOf("x", "X", "×", "✕", "✖", "✗", "╳")

        private val CLOSE_WORDS = setOf(
            "close", "skip", "no thanks", "no thank you", "not now", "later", "maybe later",
            "cancel", "dismiss", "skip tutorial", "skip intro", "continue without",
            // saying no to a deal / offer is always safe (a devil's contract, "quit?", "rate us?")
            "walk away", "decline", "refuse", "reject", "no", "nope", "not today", "no deal", "ignore",
            "never mind", "nevermind", "i refuse", "leave it",
        )

        private val SAFE_PROGRESS = setOf(
            "continue", "continue game", "next", "next level", "next stage", "next round", "play", "play again",
            "play now", "play on", "start", "start game", "start playing", "retry", "try again", "restart",
            "replay", "resume", "go", "lets go", "let s go", "begin", "proceed", "claim", "collect",
            "claim reward", "collect reward", "take reward", "new game", "tap here", "tap anywhere",
            "press start", "get started", "get ready", "level up", "keep playing", "respawn",
        )

        private val REWARD_STARTERS = setOf("claim", "collect")

        private val PROGRESS_STARTERS = setOf(
            "continue", "next", "retry", "resume", "restart", "begin", "proceed", "replay", "start",
        )

        private val CONFIRM_WORDS = setOf("ok", "okay", "yes", "confirm", "done", "got it")

        private val LOADING_PHRASES = listOf(
            "loading", "please wait", "connecting", "downloading", "updating", "initializing",
            "checking for updates", "starting up",
        )

        private val DANGER_WORDS = setOf(
            "buy", "purchase", "subscribe", "subscription", "install", "download", "login", "password",
            "payment", "pay", "premium", "upgrade", "watch", "ad", "ads", "offer", "discount", "sale",
            "vip", "trial", "get", "shop", "store",
        )

        private val DANGER_PHRASES = listOf("remove ads", "no ads", "free trial", "in app", "create account")

        private val LOGIN_PHRASES = listOf("sign in", "log in", "sign up")
        private val LOGIN_FOLLOW = setOf(
            "with", "using", "to", "via", "as", "now", "here", "or", "first", "again", "google", "facebook", "apple",
            "email", "account", "required", "play", "games", "gamecenter", "id", "instead", "later",
        )

        /** The character died / the run is over. */
        private val DEATH_PHRASES = listOf(
            "game over", "you died", "you are dead", "you re dead", "defeated", "you lose", "you lost", "wasted",
            "run over", "run ended", "mission failed", "level failed", "you failed", "out of lives", "you were killed",
        )

        private val HP_TEXT = Regex("^(\\d{1,5})\\s*[/|]\\s*(\\d{1,5})$")

        /** Pressing one of these while a run is on means the character just died. */
        private val RETRY_KEYS = setOf("retry", "try again", "restart", "play again", "respawn", "new game", "replay")

        /** Survival rules for choosing between options: stay alive, avoid curses and deals. */
        private val SURVIVE_GOOD = setOf(
            "health", "hp", "heal", "healing", "life", "lives", "armor", "armour", "shield", "defense", "defence",
            "regen", "regeneration", "protect", "protection", "guard", "barrier", "dodge", "speed", "vitality",
        )
        private val SURVIVE_RISKY = setOf(
            "curse", "cursed", "pact", "sacrifice", "sell", "soul", "blood", "chains", "contract", "deal", "lose",
            "weaken", "doom", "wager", "gamble", "bargain", "forsake",
        )

        // $ EUR GBP PHP JPY followed by a number, or a number followed by a currency code.
        private val PRICE = Regex("[$€£₱¥]\\s?\\d|\\d\\s?(usd|php|eur)", RegexOption.IGNORE_CASE)

        /** Lowercase letters/digits separated by single spaces. */
        fun normalize(s: String): String {
            val sb = StringBuilder()
            var lastSpace = true
            for (ch in s.lowercase()) {
                if (ch in 'a'..'z' || ch in '0'..'9') {
                    sb.append(ch)
                    lastSpace = false
                } else if (!lastSpace) {
                    sb.append(' ')
                    lastSpace = true
                }
            }
            return sb.toString().trim()
        }

        /** The words of a screen (3+ letters, numbers ignored so scores do not change it). */
        fun wordSet(r: Reading): Set<String> {
            val words = LinkedHashSet<String>()
            for (ln in r.lines) {
                if (r.blocked.any { it.intersects(ln.l, ln.t, ln.r, ln.b) }) continue
                for (tok in normalize(ln.text).split(' ')) {
                    if (tok.length >= 3 && tok.any { it in 'a'..'z' }) words.add(tok)
                }
            }
            return words
        }

        /** A fingerprint of the screen made from its words (numbers ignored so scores do not change it). */
        fun signature(r: Reading): String {
            val words = LinkedHashSet<String>()
            for (ln in r.lines) {
                for (tok in normalize(ln.text).split(' ')) {
                    if (tok.length >= 3 && tok.any { it in 'a'..'z' }) words.add(tok)
                }
            }
            if (words.isEmpty()) return "notext"
            return words.sorted().take(10).joinToString("-")
        }

        /** Biggest plain number in the top third of the screen, a rough "score" reading. */
        fun scoreOf(r: Reading): Long? {
            var best: Long? = null
            for (ln in r.lines) {
                if (ln.cy > 0.35f) continue
                val digits = ln.text.replace(",", "").replace(" ", "").replace(".", "")
                if (digits.isEmpty() || digits.length > 10 || !digits.all { it in '0'..'9' }) continue
                val v = digits.toLongOrNull() ?: continue
                val b = best
                if (b == null || v > b) best = v
            }
            return best
        }
    }
}
