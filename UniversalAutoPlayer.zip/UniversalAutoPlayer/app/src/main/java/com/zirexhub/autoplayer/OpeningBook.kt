package com.zirexhub.autoplayer

import java.util.Random

/**
 * An opening book: well known opening lines (see [OpeningData]) looked up by position, so a game does not start the same way
 * every time and the first moves are theory. Every move is chosen at random, weighted by how many opening lines use it, among
 * the moves the book knows for the position on the board. The lookup is by position (not by move list), so transpositions
 * work and a game that was joined after a few moves still finds its place. A book move is only used when it is legal.
 */
object OpeningBook {
    private var table: HashMap<Long, IntArray>? = null // position hash -> move, weight, move, weight ...
    private var edgeCount = 0

    private fun load(): HashMap<Long, IntArray> {
        table?.let { return it }
        val map = HashMap<Long, IntArray>()
        val parent = ArrayList<Int>()
        val move = ArrayList<Int>()
        val count = ArrayList<Int>()
        parent.add(0); move.add(0); count.add(0) // node 0 = the start position
        val start = ChessPos.start()
        for (chunk in OpeningData.CHUNKS) {
            for (edge in chunk.split(';')) {
                if (edge.isEmpty()) continue
                val f = edge.split(',')
                val par = if (f.size == 3) f[0].toIntOrNull() else null
                val mv = if (f.size == 3) parseUci(f[1]) else null
                if (par == null || mv == null || par !in parent.indices) {
                    parent.add(0); move.add(-1); count.add(0) // keeps the numbering of the later edges
                    continue
                }
                parent.add(par); move.add(mv); count.add(f[2].toIntOrNull() ?: 1)
            }
        }
        edgeCount = parent.size - 1
        // the position of every node: replay its path from the start
        val path = IntArray(64)
        for (id in 1 until parent.size) {
            var n = 0
            var c = parent[id]
            while (c > 0 && n < path.size) { path[n++] = move[c]; c = parent[c] }
            val p = start.copy()
            var ok = true
            for (i in n - 1 downTo 0) {
                if (!isLegal(p, path[i])) { ok = false; break }
                p.make(path[i])
            }
            if (!ok || move[id] < 0 || !isLegal(p, move[id])) continue
            val h = p.hash
            val old = map[h] ?: IntArray(0)
            var found = -1
            var i = 0
            while (i < old.size) { if (old[i] == move[id]) { found = i; break }; i += 2 }
            if (found >= 0) {
                old[found + 1] += count[id]
            } else {
                val a = old.copyOf(old.size + 2)
                a[old.size] = move[id]
                a[old.size + 1] = count[id]
                map[h] = a
            }
        }
        table = map
        return map
    }

    private fun isLegal(p: ChessPos, m: Int): Boolean {
        val buf = IntArray(256)
        val n = p.legal(buf)
        for (i in 0 until n) if (buf[i] == m) return true
        return false
    }

    private fun parseUci(s: String): Int? {
        if (s.length < 4) return null
        val f1 = s[0] - 'a'; val r1 = s[1] - '1'; val f2 = s[2] - 'a'; val r2 = s[3] - '1'
        if (f1 !in 0..7 || f2 !in 0..7 || r1 !in 0..7 || r2 !in 0..7) return null
        val promo = if (s.length > 4) "nbrq".indexOf(s[4]) + 2 else 0
        if (s.length > 4 && promo < 2) return null
        return ChessPos.move(r1 * 8 + f1, r2 * 8 + f2, promo)
    }

    /** How many opening moves the book holds (0 when the data is missing). */
    fun size(): Int {
        load()
        return edgeCount
    }

    /** The moves the book knows for [pos] (move, weight pairs), or an empty list. */
    fun moves(pos: ChessPos): List<Pair<Int, Int>> {
        val a = load()[pos.zobrist()] ?: return emptyList()
        val out = ArrayList<Pair<Int, Int>>()
        var i = 0
        while (i < a.size) { out.add(Pair(a[i], a[i + 1])); i += 2 }
        return out
    }

    /** A book move for [pos] (weighted random), or null when the position is not in the book. Moves in [exclude] (UCI) are not offered. */
    fun pick(pos: ChessPos, rng: Random, exclude: Set<String> = emptySet()): Int? {
        val legal = moves(pos).filter { ChessPos.uci(it.first) !in exclude && isLegal(pos, it.first) }
        if (legal.isEmpty()) return null
        // a move that only ONE odd line plays is left out when other moves are well supported (e.g. 1.d4 g6 2.h4), unless it is all there is
        val top = legal.maxOf { it.second }
        val all = legal.filter { it.second >= 2 || top < 4 }.ifEmpty { legal }
        // popular lines are more likely, but not overwhelmingly so: weight = sqrt(number of lines)
        val w = all.map { Math.sqrt(it.second.toDouble()) }
        var r = rng.nextDouble() * w.sum()
        for ((i, x) in w.withIndex()) {
            r -= x
            if (r <= 0) return all[i].first
        }
        return all.last().first
    }
}
