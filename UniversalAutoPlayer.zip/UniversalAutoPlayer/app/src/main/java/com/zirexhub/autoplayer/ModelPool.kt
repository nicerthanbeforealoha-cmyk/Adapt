package com.zirexhub.autoplayer

/**
 * Which model the next AI call goes to (pure Kotlin, no Android).
 *
 * Found in a real chess log: "HTTP 503: This model is currently experiencing high demand". A preview or "lite" model of a big
 * provider is often overloaded for minutes. Nine calls in one run failed that way, each one took 3 to 5 seconds to fail and
 * was followed by a waiting time that grew (2 s, 4 s, 6 s), so the game slowed down until it seemed to stop. The answer is
 * not to wait for the same model but to ask another one at once: the model the user chose stays the first choice, an
 * overloaded model rests for a while (longer each time it fails in a row) and the next best model of the account answers
 * meanwhile.
 */
class ModelPool(private val preferred: String, private val clock: () -> Long) {
    private val restUntil = HashMap<String, Long>()
    private val streak = HashMap<String, Int>()
    private var others: List<String>? = null

    /** The other models of the account were looked up (even if there are none). */
    val alternativesKnown: Boolean @Synchronized get() = others != null

    val alternatives: List<String> @Synchronized get() = others ?: emptyList()

    @Synchronized fun setAlternatives(list: List<String>) {
        others = list.filter { !it.equals(preferred, ignoreCase = true) }.distinct().take(MAX_ALTERNATIVES)
    }

    private fun resting(model: String): Boolean = (restUntil[model] ?: 0L) > clock()

    /** The model for the next call: the chosen one unless it rests, then the first alternative that does not rest. */
    @Synchronized fun pick(): String {
        if (!resting(preferred)) return preferred
        return alternatives.firstOrNull { !resting(it) } ?: preferred
    }

    /** [model] answered "overloaded": it rests for 90 s, then 3 min, then 6 min, at most 10 min while it keeps failing. */
    @Synchronized fun overloaded(model: String) {
        val n = (streak[model] ?: 0) + 1
        streak[model] = n
        val rest = (BASE_REST_MS shl (n - 1).coerceAtMost(3)).coerceAtMost(MAX_REST_MS)
        restUntil[model] = clock() + rest
    }

    /** [model] answered: forget its failures. */
    @Synchronized fun ok(model: String) {
        streak.remove(model)
        restUntil.remove(model)
    }

    @Synchronized fun restMsLeft(model: String): Long = ((restUntil[model] ?: 0L) - clock()).coerceAtLeast(0L)

    companion object {
        const val BASE_REST_MS = 90_000L
        const val MAX_REST_MS = 600_000L
        const val MAX_ALTERNATIVES = 4

        /** "Server busy" answers: 500, 502, 503, 504, or the words the providers use for it (not the 429 "too many calls"). */
        fun isOverload(e: Exception): Boolean {
            if (e !is ApiException || e is RateLimitException) return false
            val low = e.message?.lowercase() ?: ""
            return e.code in 500..504 || "overloaded" in low || "high demand" in low || "unavailable" in low
        }
    }
}
