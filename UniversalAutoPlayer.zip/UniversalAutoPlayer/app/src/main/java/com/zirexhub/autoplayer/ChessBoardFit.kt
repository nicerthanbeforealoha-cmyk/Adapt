package com.zirexhub.autoplayer

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Picks the real 8x8 chess board out of what [GridFinder] found (pure Kotlin, no Android).
 *
 * The finder only knows "a regular lattice of cells". On a real chess.com screen it returned an 8x9 board: the white speech bubble
 * of the coach sits right above the board, the bot's own chip (painted dark grey and ignored by the finder) hides the top of the
 * bubble, and the cells of the bubble row that were hidden or full of text counted as "probably board". An 8x9 board was
 * rejected, so the bot saw "no chess board" on a screen that had one.
 *
 * A chess board is more than a lattice: its squares ALTERNATE light and dark. [score] measures that for one 8x8 window (from
 * the four corners of every square, where a piece never stands, so pieces and the file/rank letters do not matter). [fit] tries
 * every 8x8 window inside the found rectangle (and the neighbours of an exact 8x8 one) and keeps the one that is clearly the
 * best checkerboard.
 */
object ChessBoardFit {
    /** A window must reach this score to be called a chessboard. */
    const val MIN_SCORE = 0.55f

    /** The best window must beat the next one by this much, else the rectangle is left as the finder gave it. */
    private const val MARGIN = 0.08f

    /** Tests set this to see how the windows scored. */
    internal var trace: ((String) -> Unit)? = null

    /** Sums of rectangles in O(1). */
    internal class Integral(g: Gray) {
        val w = g.w
        val h = g.h
        private val s = LongArray((g.w + 1) * (g.h + 1))

        init {
            for (y in 0 until g.h) {
                var row = 0L
                for (x in 0 until g.w) {
                    row += g.px[y * g.w + x]
                    s[(y + 1) * (g.w + 1) + x + 1] = s[y * (g.w + 1) + x + 1] + row
                }
            }
        }

        /** Mean brightness of the pixels x0 until x1, y0 until y1 (clamped to the picture, at least one pixel). */
        fun mean(x0: Float, y0: Float, x1: Float, y1: Float): Double {
            val xa = x0.toInt().coerceIn(0, w - 1)
            val ya = y0.toInt().coerceIn(0, h - 1)
            val xb = max(xa + 1, x1.toInt() + 1).coerceAtMost(w)
            val yb = max(ya + 1, y1.toInt() + 1).coerceAtMost(h)
            val sum = s[yb * (w + 1) + xb] - s[ya * (w + 1) + xb] - s[yb * (w + 1) + xa] + s[ya * (w + 1) + xa]
            return sum.toDouble() / ((xb - xa) * (yb - ya))
        }
    }

    /**
     * 0..1: how well the 8x8 window with its top-left corner at ([x0],[y0]) (pixels of [g]) and squares of [cw] x [ch] pixels
     * alternates between two colours. Squares under a painted-over box ([masks]) are skipped. -1 when too few squares can be
     * measured or the two colours are almost the same.
     */
    internal fun score(g: Gray, x0: Float, y0: Float, cw: Float, ch: Float, masks: List<Zone>): Float =
        measure(Integral(g), x0, y0, cw, ch, masks).first

    /** [score] and the number of squares that could be measured (the others are under a painted-over box). */
    internal fun measure(ii: Integral, x0: Float, y0: Float, cw: Float, ch: Float, masks: List<Zone>): Pair<Float, Int> {
        if (x0 < -1f || y0 < -1f || x0 + 8 * cw > ii.w + 1f || y0 + 8 * ch > ii.h + 1f) return Pair(-1f, 0)
        val sumA = DoubleArray(2)
        val sqA = DoubleArray(2)
        val nA = IntArray(2)
        var measured = 0
        for (j in 0 until 8) for (i in 0 until 8) {
            val xa = x0 + i * cw
            val ya = y0 + j * ch
            if (masks.isNotEmpty() && masks.any { m -> m.intersects(xa / ii.w, ya / ii.h, (xa + cw) / ii.w, (ya + ch) / ii.h) }) continue
            val v = corners(ii, xa, ya, cw, ch)
            val p = (i + j) and 1
            sumA[p] += v
            sqA[p] += v * v
            nA[p]++
            measured++
        }
        if (nA[0] < 6 || nA[1] < 6 || measured < 24) return Pair(-1f, measured)
        val m0 = sumA[0] / nA[0]
        val m1 = sumA[1] / nA[1]
        val v0 = max(0.0, sqA[0] / nA[0] - m0 * m0)
        val v1 = max(0.0, sqA[1] / nA[1] - m1 * m1)
        val d = abs(m0 - m1)
        if (d < 10.0) return Pair(-1f, measured)
        val sigma = sqrt((v0 + v1) / 2.0)
        // contrast between the two colours against the spread inside each colour
        return Pair((d / (d + 2.5 * sigma + 4.0)).toFloat(), measured)
    }

    /** The middle two of the four corner patches of a square (a letter in one corner or a piece leaning over one does not count). */
    private fun corners(ii: Integral, x: Float, y: Float, cw: Float, ch: Float): Double {
        val pw = max(1f, cw * 0.18f)
        val ph = max(1f, ch * 0.18f)
        val gx = cw * 0.07f
        val gy = ch * 0.07f
        val a = ii.mean(x + gx, y + gy, x + gx + pw, y + gy + ph)
        val b = ii.mean(x + cw - gx - pw, y + gy, x + cw - gx, y + gy + ph)
        val c = ii.mean(x + gx, y + ch - gy - ph, x + gx + pw, y + ch - gy)
        val d = ii.mean(x + cw - gx - pw, y + ch - gy - ph, x + cw - gx, y + ch - gy)
        // the middle two of four values = the sum minus the smallest and the largest
        val lo = min(min(a, b), min(c, d))
        val hi = max(max(a, b), max(c, d))
        return (a + b + c + d - lo - hi) / 2.0
    }

    /**
     * The 8x8 board inside [found] (what [GridFinder.find] returned), or [found] itself when nothing better is clear.
     * Only rectangles of 8 or more columns and 8 or more rows with nearly square squares are looked at.
     */
    fun fit(g: Gray, found: Grid?, masks: List<Zone> = emptyList()): Grid? {
        if (found == null || found.cols < 8 || found.rows < 8 || found.cols > 11 || found.rows > 11) return found
        val cw = (found.r - found.l) * g.w / found.cols
        val ch = (found.b - found.t) * g.h / found.rows
        if (cw < 4f || ch < 4f || cw / ch < 0.8f || cw / ch > 1.25f) return found
        val x0 = found.l * g.w
        val y0 = found.t * g.h
        val exact = found.cols == 8 && found.rows == 8
        val ii = Integral(g)
        // the windows: every position inside the rectangle; for an exact 8x8 also the ones one square aside
        val dxs = if (exact) -1..1 else 0..(found.cols - 8)
        val dys = if (exact) -1..1 else 0..(found.rows - 8)
        class Cand(val dx: Int, val dy: Int, val s: Float, val seen: Int)
        val cands = ArrayList<Cand>()
        for (dy in dys) for (dx in dxs) {
            if (exact && dx != 0 && dy != 0) continue // a window moves along one axis at a time
            val m = measure(ii, x0 + dx * cw, y0 + dy * ch, cw, ch, masks)
            cands.add(Cand(dx, dy, m.first, m.second))
        }
        trace?.invoke("fit of $found: " + cands.joinToString(" ") { "(${it.dx},${it.dy})=${"%.2f".format(java.util.Locale.US, it.s)}/${it.seen}" })
        val own = cands.firstOrNull { it.dx == 0 && it.dy == 0 && exact }
        val ranked = cands.sortedByDescending { it.s }
        var best = ranked.first()
        if (best.s < MIN_SCORE) return found
        if (exact) {
            // a board that is already 8x8 moves only when a neighbour is clearly better
            if (best.dx == 0 && best.dy == 0) return found
            if (own != null && own.s >= MIN_SCORE && best.s - own.s < 0.2f) return found
        } else {
            // windows that look about as good as the best: the one with the most measured squares wins (a window that reaches into a
            // painted-over box, e.g. the bubble row above the board, has little evidence behind it); equal evidence = no decision
            val close = ranked.filter { best.s - it.s < MARGIN }
            if (close.size > 1) {
                val most = close.maxOf { it.seen }
                val top = close.filter { it.seen == most }
                if (top.size > 1) return found
                best = top[0]
            }
        }
        val left = x0 + best.dx * cw
        val top = y0 + best.dy * ch
        return Grid(
            (left / g.w).coerceIn(0f, 1f), (top / g.h).coerceIn(0f, 1f),
            ((left + 8 * cw) / g.w).coerceIn(0f, 1f), ((top + 8 * ch) / g.h).coerceIn(0f, 1f), 8, 8,
        )
    }

    /** The search only looks for boards that fill at least this much of the screen width (phone chess apps: all of it). */
    private const val SEARCH_MIN_WIDTH = 0.55f

    /** A board found by [search] alone (no lattice behind it) must score higher than one that [fit] picks out of a lattice. */
    const val SEARCH_MIN_SCORE = 0.70f

    /**
     * Looks for an 8x8 checkerboard directly, without the lattice finder: every size (a board that fills at least 55 % of the width),
     * position, scored by [score]. Used when the finder returned nothing useful (a chip or a bubble spoiled its lines). Null when
     * no window looks like a chessboard. A coarse pass (2 px steps), then a fine one around the best window.
     */
    fun search(g: Gray, masks: List<Zone> = emptyList()): Grid? {
        if (g.w < 60 || g.h < 60) return null
        val ii = Integral(g)
        var best = -1f // score of the chosen window
        var bestKey = -1f
        var bestSeen = 0
        var bx = 0f
        var by = 0f
        var bs = 0f
        // A window is better with a higher score; a little extra for every measured square, because a window that slides one row
        // into a painted-over box (a hidden player bar) scores the same on the squares that are left but has less evidence.
        fun consider(x: Float, y: Float, s: Float) {
            val (v, seen) = measure(ii, x, y, s, s, masks)
            if (v < 0f) return
            val key = v + 0.1f * seen / 64f
            if (key > bestKey) {
                bestKey = key
                best = v
                bestSeen = seen
                bx = x
                by = y
                bs = s
            }
        }
        var s = min(g.w / 8f, g.h / 8f)
        while (s >= g.w * SEARCH_MIN_WIDTH / 8f) {
            var x = 0f
            while (x <= g.w - 8 * s + 0.01f) {
                var y = 0f
                while (y <= g.h - 8 * s + 0.01f) {
                    consider(x, y, s)
                    y += 3f
                }
                x += 3f
            }
            s -= 0.75f
        }
        if (best < SEARCH_MIN_SCORE) return null
        // fine pass around the best coarse window
        var fs = bs - 0.75f
        while (fs <= bs + 0.76f) {
            var x = bx - 3f
            while (x <= bx + 3.01f) {
                var y = by - 3f
                while (y <= by + 3.01f) {
                    consider(x, y, fs)
                    y += 0.5f
                }
                x += 0.5f
            }
            fs += 0.25f
        }
        trace?.invoke("search: best window x $bx y $by cell $bs score $best (measured squares $bestSeen)")
        if (best < SEARCH_MIN_SCORE) return null
        return Grid(
            (bx / g.w).coerceIn(0f, 1f), (by / g.h).coerceIn(0f, 1f),
            ((bx + 8 * bs) / g.w).coerceIn(0f, 1f), ((by + 8 * bs) / g.h).coerceIn(0f, 1f), 8, 8,
        )
    }
}
