package com.zirexhub.autoplayer

/** What kind of "too many requests" the provider answered with. */
enum class LimitKind {
    /** Too many calls in one minute. Waiting and spacing the calls out fixes it. */
    PER_MINUTE,

    /** The calls for today are used up. Retrying does not help until the provider's day starts again. */
    PER_DAY,

    /** This key / project has no quota at all for this model (free tier not offered, "limit: 0"). */
    NO_QUOTA,

    UNKNOWN,
}

/**
 * [retryAfterMs] = how long the provider asked us to wait (0 = it did not say). [limitValue] = the number of calls the
 * provider allows per period when it said so (for example 5 per minute), else 0.
 */
class LimitInfo(val kind: LimitKind, val retryAfterMs: Long, val limitValue: Int, val detail: String)

/**
 * Reads the error replies of the AI services and explains them in plain words (pure Kotlin, no Android, no JSON library:
 * the reply is searched as text, so even a half-broken body still gives an answer).
 *
 * Found with a real Google AI Studio key: the free tier of gemini-3.8-flash allows 5 calls per MINUTE and only 20 per DAY.
 * The bot made one call per second or two, so the day was used up in under a minute and every later call failed.
 */
object ApiErrors {
    private val RETRY_DELAY = Regex("\"retryDelay\"\\s*:\\s*\"([0-9]+(?:\\.[0-9]+)?)(ms|s)\"")
    private val RETRY_IN = Regex("retry in ([0-9]+(?:\\.[0-9]+)?)\\s*s", RegexOption.IGNORE_CASE)
    private val QUOTA_VALUE = Regex("\"quotaValue\"\\s*:\\s*\"?([0-9]+)\"?")
    private val LIMIT_N = Regex("limit:\\s*([0-9]+)", RegexOption.IGNORE_CASE)

    /** Works on the raw error body (or just the message). */
    fun limit(body: String): LimitInfo {
        val low = body.lowercase()
        val squeezed = low.replace("_", "").replace(" ", "").replace("-", "")
        var retryMs = 0L
        RETRY_DELAY.find(body)?.let {
            val v = it.groupValues[1].toDouble()
            retryMs = if (it.groupValues[2] == "ms") v.toLong() else (v * 1000).toLong()
        }
        if (retryMs == 0L) RETRY_IN.find(body)?.let { retryMs = (it.groupValues[1].toDouble() * 1000).toLong() }
        val value = QUOTA_VALUE.find(body)?.groupValues?.get(1)?.toIntOrNull() ?: LIMIT_N.find(body)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val kind = when {
            "limit:0" in squeezed || (QUOTA_VALUE.find(body)?.groupValues?.get(1) == "0") -> LimitKind.NO_QUOTA
            "perday" in squeezed || "requestsperday" in squeezed || "daily" in squeezed -> LimitKind.PER_DAY
            "perminute" in squeezed || "requestsperminute" in squeezed -> LimitKind.PER_MINUTE
            retryMs in 1..120_000 -> LimitKind.PER_MINUTE // "please retry in 23s" without a name: it is the short kind
            else -> LimitKind.UNKNOWN
        }
        return LimitInfo(kind, retryMs, value, body.take(200))
    }

    /** A pasted key often carries a space, a line break or quotes. Providers answer "key not valid" to those. */
    fun cleanKey(raw: String): String = raw.filter { !it.isWhitespace() }.trim('"', '\'', '`', '“', '”', '‘', '’').removePrefix("key=")

    /** One or two plain sentences on what to do, for the test dialog and the status line. Empty when there is nothing to add. */
    fun hint(code: Int, message: String): String {
        val low = message.lowercase()
        return when {
            code == 429 -> {
                val info = limit(message)
                when (info.kind) {
                    LimitKind.PER_DAY -> "The free calls for today are used up (resets at midnight Pacific time, about 4 PM in Manila). " +
                        "Use a Flash-Lite model (more calls per day), another key, or the Offline brain."
                    LimitKind.NO_QUOTA -> "This model has no free quota for your key. Pick another model (try a Flash-Lite one) or turn on billing in AI Studio."
                    else -> "Too many calls per minute. The app now spaces its calls out by itself."
                }
            }
            code == 400 && ("api key not valid" in low || "api_key_invalid" in low || "api key" in low) ->
                "The key was not accepted. Copy it again from aistudio.google.com/apikey (starts with AIza), without spaces or quotes."
            code == 400 && "location is not supported" in low ->
                "Google does not offer this API for your current location or network. Try another network or a VPN-free connection, or another provider."
            code == 403 && ("denied access" in low || "has been suspended" in low) ->
                "Google blocked this project. Create a new key in a new project at aistudio.google.com/apikey."
            code == 403 && ("blocked" in low || "referer" in low || "restrict" in low || "not been used" in low || "disabled" in low) ->
                "The key is restricted or the Gemini API is off for its project. Make a new unrestricted key at aistudio.google.com/apikey."
            code == 401 || code == 403 ->
                "The key was refused. Check that it is the right provider, that it was copied completely, and that the project can use the Gemini API."
            code == 500 || code == 502 || code == 503 || code == 504 || "overloaded" in low || "unavailable" in low ->
                "The provider's server is busy. The app tries again by itself."
            else -> ""
        }
    }
}

/**
 * Keeps the calls to the AI inside what the provider allows, and says when to let the offline bot play instead.
 *
 * Starts without any limit (a paid key is not slowed down). Every "too many calls" answer teaches it: a per-minute limit
 * sets the gap between calls to what the provider said (5 per minute = one call every 13 s), a per-day limit or a missing
 * quota ends AI calls for this run. Between AI calls the offline bot plays, so the game never stands still.
 */
class RateGuard(private val clock: () -> Long = { System.currentTimeMillis() }) {
    var gapMs = 0L
        private set
    var outForToday = false
        private set
    var why = ""
        private set
    private var blockedUntil = 0L
    private var lastCall = Long.MIN_VALUE / 2
    private var learnedGap = 0L
    private var exact = false
    private var okRun = 0

    /** 0 = a call may go out now. */
    fun waitMs(): Long {
        if (outForToday) return Long.MAX_VALUE
        val now = clock()
        return maxOf(0L, blockedUntil - now, lastCall + gapMs - now)
    }

    fun started() {
        lastCall = clock()
    }

    /** No AI call for this long (after a server error or an unreadable answer). */
    fun blockFor(ms: Long) {
        blockedUntil = maxOf(blockedUntil, clock() + ms)
    }

    fun success() {
        okRun++
        if (okRun >= 25 && gapMs > 0L && !exact) {
            okRun = 0
            // a gap that was only a guess creeps back toward 70 % of itself, so a short-lived limit does not slow us for ever.
            // A gap taken from the provider's own number (5 per minute) is a hard quota and stays.
            gapMs = maxOf((learnedGap * 0.7).toLong(), (gapMs * 0.9).toLong())
        }
    }

    fun limited(info: LimitInfo) {
        okRun = 0
        when (info.kind) {
            LimitKind.PER_DAY -> {
                outForToday = true
                why = "today's free calls are used up"
            }
            LimitKind.NO_QUOTA -> {
                outForToday = true
                why = "this model has no free quota for the key"
            }
            else -> {
                val now = clock()
                blockedUntil = now + maxOf(info.retryAfterMs + 500L, 4000L).coerceAtMost(90_000L)
                val taught = if (info.limitValue in 1..600) (60_000L * 11L / 10L) / info.limitValue else maxOf(gapMs * 3 / 2, 6500L)
                learnedGap = taught.coerceIn(3000L, 20_000L)
                if (info.limitValue in 1..600) exact = true
                gapMs = maxOf(gapMs, learnedGap)
                why = "waiting ${gapMs / 1000}s between AI calls (provider limit)"
            }
        }
    }
}
