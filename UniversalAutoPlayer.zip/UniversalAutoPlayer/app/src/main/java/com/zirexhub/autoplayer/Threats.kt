package com.zirexhub.autoplayer

import kotlin.math.max
import kotlin.math.min

/** One thing seen on the screen: where (0..1 of the screen) and how much it counts. */
class Blip(val x: Float, val y: Float, val weight: Float)

/**
 * Enemies, gems and the character's health bar, found from the colours of one screenshot (pure Kotlin, no Android).
 *
 * Calibrated on the real Inferno map of a Vampire-Survivors-like game:
 *  - ENEMIES (imps) are tiny crimson sprites, about RGB 140,40,48: red, green well under half of red, blue at least as
 *    big as green. Embers, lava and fire are orange (blue SMALLER than green) and are not counted. Crimson specks on the
 *    edge of a lava river are lava texture, so anything touching lava is dropped too.
 *  - GEMS are bright green diamonds (XP): green clearly above red and blue.
 *  - HEALTH: the bar under the character is bright red on dark red. The width of the bright part is the health.
 *
 * This is a heuristic for THAT look. Enemies of another colour are not seen; the bot then falls back to the old
 * "where did things move" guess and to the health-drop reaction.
 */
class ThreatMap(
    val enemies: List<Blip>,
    val gems: List<Blip>,
    /** Width in grid pixels of the bright red health fill (0 = no health bar found). */
    val hpSpan: Int,
    val gridWidth: Int,
    val aspect: Float,
) {
    fun describe(): String = "enemies=${enemies.size} gems=${gems.size} hpbar=${if (hpSpan > 0) "$hpSpan/${gridWidth}px" else "-"}"
}

object Threats {
    /** Where the character stands on the screen when the camera follows it (same as [Hazards]). */
    const val HERO_X = 0.5f
    const val HERO_Y = 0.49f

    /** Core of the character itself is not an enemy. */
    private const val HERO_CORE = 0.06f

    fun isEnemyColour(c: Int): Boolean {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        if (r < 85) return false
        if (g * 2 > r) return false // orange / yellow have green above half of red
        if (b * 10 < g * 9) return false // lava / embers: blue below green
        if (b * 5 < r || b * 5 > r * 4) return false // not purple-grey, not pink-white
        return r - g >= 45
    }

    fun isGemColour(c: Int): Boolean {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        return g >= 140 && g >= r + 45 && g >= b + 25
    }

    private fun isHpRed(c: Int): Boolean {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        return r >= 170 && g <= 75 && b <= 85 && r - g >= 110
    }

    /** Width of the bright red health fill under the character, in grid pixels (0 when there is no such bar). */
    fun hpSpan(px: IntArray, gw: Int, gh: Int): Int {
        val y0 = (gh * 0.505f).toInt()
        val y1 = (gh * 0.58f).toInt().coerceAtMost(gh - 1)
        val x0 = (gw * 0.38f).toInt()
        val x1 = (gw * 0.62f).toInt().coerceAtMost(gw - 1)
        if (y1 <= y0 || x1 <= x0) return 0
        var bestRow = -1
        var bestCount = 0
        for (y in y0..y1) {
            var cnt = 0
            for (x in x0..x1) if (isHpRed(px[y * gw + x])) cnt++
            if (cnt > bestCount) {
                bestCount = cnt
                bestRow = y
            }
        }
        if (bestCount < 4) return 0
        var minX = Int.MAX_VALUE
        var maxX = -1
        for (y in max(y0, bestRow - 1)..min(y1, bestRow + 1)) {
            for (x in x0..x1) {
                if (isHpRed(px[y * gw + x])) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                }
            }
        }
        return if (maxX < minX) 0 else maxX - minX + 1
    }

    /**
     * [px] is the shrunk screenshot (ARGB ints, 192 px wide is the size the colours were measured at).
     * [lava] is the lava picture from [Hazards] (its own, smaller grid) so crimson specks on lava are not enemies.
     * [blocked] are the screen zones that belong to the bot's own overlay (the chip).
     */
    fun analyze(px: IntArray, gw: Int, gh: Int, aspect: Float, lava: HazardInfo?, blocked: List<Zone>): ThreatMap? {
        if (gw < 32 || gh < 32 || px.size < gw * gh) return null
        val n = gw * gh
        val hudRows = (gh * 0.16f).toInt()
        val hx = HERO_X * gw
        val hy = HERO_Y * gh
        val core = HERO_CORE * gw
        val enemy = BooleanArray(n)
        val gem = BooleanArray(n)
        for (y in hudRows until gh) {
            for (x in 0 until gw) {
                val dx = x + 0.5f - hx
                val dy = y + 0.5f - hy
                if (dx * dx + dy * dy < core * core) continue
                // the health bar under the character is red too
                if (y > gh * 0.50f && y < gh * 0.585f && x > gw * 0.37f && x < gw * 0.63f) continue
                val c = px[y * gw + x]
                if (isEnemyColour(c)) enemy[y * gw + x] = true
                else if (isGemColour(c)) gem[y * gw + x] = true
            }
        }
        return ThreatMap(blobs(enemy, gw, gh, aspect, lava, blocked, 3, 260, true), blobs(gem, gw, gh, aspect, null, blocked, 2, 120, false), hpSpan(px, gw, gh), gw, aspect)
    }

    private fun blobs(mask: BooleanArray, gw: Int, gh: Int, aspect: Float, lava: HazardInfo?, blocked: List<Zone>, minPx: Int, maxPx: Int, enemies: Boolean): List<Blip> {
        // join the specks of one sprite: grow by one pixel, then flood fill
        val grown = BooleanArray(mask.size)
        for (y in 0 until gh) for (x in 0 until gw) {
            if (!mask[y * gw + x]) continue
            for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx
                val yy = y + dy
                if (xx in 0 until gw && yy in 0 until gh) grown[yy * gw + xx] = true
            }
        }
        val seen = BooleanArray(mask.size)
        val stack = IntArray(mask.size)
        val out = ArrayList<Blip>()
        for (start in mask.indices) {
            if (!grown[start] || seen[start]) continue
            var sp = 0
            stack[sp++] = start
            seen[start] = true
            var raw = 0
            var sx = 0L
            var sy = 0L
            var minX = gw
            var maxX = 0
            var minY = gh
            var maxY = 0
            while (sp > 0) {
                val cur = stack[--sp]
                val x = cur % gw
                val y = cur / gw
                if (mask[cur]) {
                    raw++
                    sx += x
                    sy += y
                }
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                if (x > 0 && grown[cur - 1] && !seen[cur - 1]) { seen[cur - 1] = true; stack[sp++] = cur - 1 }
                if (x < gw - 1 && grown[cur + 1] && !seen[cur + 1]) { seen[cur + 1] = true; stack[sp++] = cur + 1 }
                if (cur >= gw && grown[cur - gw] && !seen[cur - gw]) { seen[cur - gw] = true; stack[sp++] = cur - gw }
                if (cur + gw < mask.size && grown[cur + gw] && !seen[cur + gw]) { seen[cur + gw] = true; stack[sp++] = cur + gw }
            }
            if (raw < minPx || raw > maxPx) continue
            val cx = (sx.toFloat() / raw + 0.5f) / gw
            val cy = (sy.toFloat() / raw + 0.5f) / gh
            if (blocked.any { it.contains(cx, cy, 0.01f) }) continue
            if (enemies && lava != null) {
                // crimson specks on or at the edge of lava are lava texture
                var onLava = false
                loop@ for (oy in -2..2) for (ox in -2..2) {
                    if (lava.lavaAt(cx + ox * 0.012f, cy + oy * 0.012f / aspect)) {
                        onLava = true
                        break@loop
                    }
                }
                if (onLava) continue
            }
            val w = if (enemies) 1f + min(raw / 60f, 2f) else 1f
            out.add(Blip(cx, cy, w))
        }
        return out
    }
}
