package com.zirexhub.autoplayer

import kotlin.math.abs

/**
 * Finds the choice box a chess app shows when a pawn reaches the last row ("promote to: queen, rook, bishop, knight"), from two
 * small pictures of the whole screen: one taken when the move was pressed and one taken now (pure Kotlin, tested on a PC).
 *
 * Nearly every app lists the queen FIRST (the top / left icon, or on the target square itself), so the point to press is the
 * first icon of whatever appeared. This is a guess about the layout: it presses inside the popup only, never elsewhere.
 */
object PromoPopup {

    /** A point to press (0..1 of the screen) and the box of the popup (0..1). */
    class Spot(val x: Float, val y: Float, val l: Float, val t: Float, val r: Float, val b: Float)

    private const val CHANGE = 28
    private const val GROW = 4
    private const val ACTIVE = 30

    fun find(before: Gray, now: Gray): Spot? {
        if (before.w != now.w || before.h != now.h || now.w < 20 || now.h < 20) return null
        val w = now.w
        val h = now.h
        val n = w * h
        var mask = BooleanArray(n)
        var changed = 0
        for (i in 0 until n) if (abs(now.px[i] - before.px[i]) > CHANGE) { mask[i] = true; changed++ }
        if (changed > n * 0.6) {
            // the whole screen was dimmed behind a dialog: the dialog itself is what got brighter
            changed = 0
            mask = BooleanArray(n)
            for (i in 0 until n) if (now.px[i] - before.px[i] > CHANGE) { mask[i] = true; changed++ }
        }
        if (changed < n * 0.004 || changed > n * 0.6) return null

        // join the icons of one popup into one piece, then take the biggest piece
        val grown = grow(mask, w, h, GROW)
        val seen = BooleanArray(n)
        val stack = IntArray(n)
        var bestArea = 0
        var bl = 0; var bt = 0; var br = 0; var bb = 0
        for (s in 0 until n) {
            if (!grown[s] || seen[s]) continue
            var sp = 0
            stack[sp++] = s
            seen[s] = true
            var area = 0
            var l = w; var t = h; var r = 0; var b = 0
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w
                val y = p / w
                area++
                if (x < l) l = x
                if (x > r) r = x
                if (y < t) t = y
                if (y > b) b = y
                if (x > 0 && grown[p - 1] && !seen[p - 1]) { seen[p - 1] = true; stack[sp++] = p - 1 }
                if (x < w - 1 && grown[p + 1] && !seen[p + 1]) { seen[p + 1] = true; stack[sp++] = p + 1 }
                if (y > 0 && grown[p - w] && !seen[p - w]) { seen[p - w] = true; stack[sp++] = p - w }
                if (y < h - 1 && grown[p + w] && !seen[p + w]) { seen[p + w] = true; stack[sp++] = p + w }
            }
            if (area > bestArea) { bestArea = area; bl = l; bt = t; br = r; bb = b }
        }
        // shrink the box back by the growing
        bl = minOf(bl + GROW, br); bt = minOf(bt + GROW, bb)
        br = maxOf(br - GROW, bl); bb = maxOf(bb - GROW, bt)
        val bw = br - bl + 1
        val bh = bb - bt + 1
        if (bw < 8 || bh < 8 || bw * bh < n * 0.004) return null

        // the popup's own background: the middle value inside the box
        val vals = IntArray(bw * bh)
        var k = 0
        for (y in bt..bb) for (x in bl..br) vals[k++] = now.px[y * w + x]
        vals.sort()
        val bg = vals[vals.size / 2]
        val col = IntArray(bw)
        val row = IntArray(bh)
        for (y in bt..bb) for (x in bl..br) {
            if (abs(now.px[y * w + x] - bg) > ACTIVE) { col[x - bl]++; row[y - bt]++ }
        }
        val cx = firstGroup(col) ?: return null
        val cy = firstGroup(row) ?: return null
        return Spot(
            (bl + cx) / w.toFloat(), (bt + cy) / h.toFloat(),
            bl / w.toFloat(), bt / h.toFloat(), (br + 1) / w.toFloat(), (bb + 1) / h.toFloat(),
        )
    }

    /** The middle of the first run of columns (or rows) that hold something, bridging gaps of one. Null if nothing. */
    private fun firstGroup(a: IntArray): Float? {
        var i = 0
        while (i < a.size && a[i] < 2) i++
        if (i >= a.size) return null
        var j = i
        var gap = 0
        while (j + 1 < a.size) {
            if (a[j + 1] >= 2) { gap = 0; j++ } else if (gap < 1 && j + 2 < a.size && a[j + 2] >= 2) { gap++; j++ } else break
        }
        // trailing inactive column of a bridged gap
        while (j > i && a[j] < 2) j--
        return (i + j) / 2f + 0.5f
    }

    private fun grow(m: BooleanArray, w: Int, h: Int, r: Int): BooleanArray {
        val tmp = BooleanArray(w * h)
        for (y in 0 until h) {
            var last = -1000
            for (x in 0 until w) {
                if (m[y * w + x]) last = x
                if (x - last <= r) tmp[y * w + x] = true
            }
            last = 100000
            for (x in w - 1 downTo 0) {
                if (m[y * w + x]) last = x
                if (last - x <= r) tmp[y * w + x] = true
            }
        }
        val out = BooleanArray(w * h)
        for (x in 0 until w) {
            var last = -1000
            for (y in 0 until h) {
                if (tmp[y * w + x]) last = y
                if (y - last <= r) out[y * w + x] = true
            }
            last = 100000
            for (y in h - 1 downTo 0) {
                if (tmp[y * w + x]) last = y
                if (last - y <= r) out[y * w + x] = true
            }
        }
        return out
    }
}
