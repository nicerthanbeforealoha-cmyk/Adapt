package com.zirexhub.autoplayer

import kotlin.math.abs

/**
 * Finds the choice box a chess app shows when a pawn reaches the last row ("promote to: queen, rook, bishop, knight"), from two
 * small pictures of the whole screen: one taken when the move was pressed and one taken now (pure Kotlin, tested on a PC).
 *
 * Nearly every app lists the queen FIRST (the top / left icon, or on the target square itself), so the point to press is the
 * first icon of whatever appeared. This is a guess about the layout: it presses inside the popup only, never elsewhere.
 */
object PromoPopup {

    /** A point to press (0..1 of the screen) and the box of the popup (0..1). */
    class Spot(val x: Float, val y: Float, val l: Float, val t: Float, val r: Float, val b: Float)

    private const val CHANGE = 28
    private const val GROW = 4
    private const val ACTIVE = 30

    /**
     * The choice box (its bounding box in pixels l,t,r,b, inclusive) that appeared between [before] and [now], or null.
     */
    private fun box(before: Gray, now: Gray): IntArray? {
        if (before.w != now.w || before.h != now.h || now.w < 20 || now.h < 20) return null
        val w = now.w
        val h = now.h
        val n = w * h
        var mask = BooleanArray(n)
        var changed = 0
        for (i in 0 until n) if (abs(now.px[i] - before.px[i]) > CHANGE) { mask[i] = true; changed++ }
        if (changed > n * 0.6) {
            // the whole screen was dimmed behind a dialog: the dialog itself is what got brighter
            changed = 0
            mask = BooleanArray(n)
            for (i in 0 until n) if (now.px[i] - before.px[i] > CHANGE) { mask[i] = true; changed++ }
        }
        if (changed < n * 0.004 || changed > n * 0.6) return null

        // join the icons of one popup into one piece, then take the biggest piece
        val grown = grow(mask, w, h, GROW)
        val comp = components(grown, w, h)
        var best: IntArray? = null
        for (c in comp) if (best == null || c[4] > best[4]) best = c
        val c = best ?: return null
        // shrink the box back by the growing
        val bl = minOf(c[0] + GROW, c[2])
        val bt = minOf(c[1] + GROW, c[3])
        val br = maxOf(c[2] - GROW, bl)
        val bb = maxOf(c[3] - GROW, bt)
        if (br - bl + 1 < 8 || bb - bt + 1 < 8 || (br - bl + 1) * (bb - bt + 1) < n * 0.004) return null
        return intArrayOf(bl, bt, br, bb)
    }

    /** The box (0..1 of the screen) that appeared, for the log. Null if none. */
    fun region(before: Gray, now: Gray): Spot? {
        val b = box(before, now) ?: return null
        val w = now.w.toFloat()
        val h = now.h.toFloat()
        return Spot((b[0] + b[2] + 1) / 2f / w, (b[1] + b[3] + 1) / 2f / h, b[0] / w, b[1] / h, (b[2] + 1) / w, (b[3] + 1) / h)
    }

    /** Connected pieces of [m] (8 neighbours): each as [left, top, right, bottom, area]. */
    private fun components(m: BooleanArray, w: Int, h: Int): List<IntArray> {
        val n = w * h
        val seen = BooleanArray(n)
        val stack = IntArray(n)
        val out = ArrayList<IntArray>()
        for (s in 0 until n) {
            if (!m[s] || seen[s]) continue
            var sp = 0
            stack[sp++] = s
            seen[s] = true
            var area = 0
            var l = w; var t = h; var r = 0; var b = 0
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w
                val y = p / w
                area++
                if (x < l) l = x
                if (x > r) r = x
                if (y < t) t = y
                if (y > b) b = y
                for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = x + dx
                    val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val q = ny * w + nx
                    if (m[q] && !seen[q]) { seen[q] = true; stack[sp++] = q }
                }
            }
            out.add(intArrayOf(l, t, r, b, area))
        }
        return out
    }

    /**
     * The icons of the choice box in reading order (top row first, left to right): pieces of about the size of a board square
     * ([cellW] x [cellH] in pixels of these pictures) that are NEW on the screen. Titles, borders and buttons are not that size
     * and are skipped; a row or column of icons that touch is cut into equal parts. Empty if no box is found.
     */
    fun icons(before: Gray, now: Gray, cellW: Float, cellH: Float): List<Spot> {
        val bx = box(before, now) ?: return emptyList()
        val w = now.w
        val h = now.h
        val bl = bx[0]; val bt = bx[1]; val br = bx[2]; val bb = bx[3]
        val vals = IntArray((br - bl + 1) * (bb - bt + 1))
        var k = 0
        for (y in bt..bb) for (x in bl..br) vals[k++] = now.px[y * w + x]
        vals.sort()
        val bg = vals[vals.size / 2]
        val active = BooleanArray(w * h)
        for (y in bt..bb) for (x in bl..br) if (abs(now.px[y * w + x] - bg) > ACTIVE) active[y * w + x] = true
        val parts = components(grow(active, w, h, 2), w, h)
        val minW = cellW * 0.5f
        val maxW = cellW * 2.6f
        val minH = cellH * 0.5f
        val maxH = cellH * 2.6f
        val found = ArrayList<IntArray>() // l, t, r, b
        for (c in parts) {
            val cl = c[0] + 2; val ct = c[1] + 2; val cr = maxOf(c[2] - 2, cl); val cb = maxOf(c[3] - 2, ct)
            val cw = (cr - cl + 1).toFloat()
            val ch = (cb - ct + 1).toFloat()
            val fits = cw in minW..maxW && ch in minH..maxH
            if (fits) {
                found.add(intArrayOf(cl, ct, cr, cb))
            } else if (ch in (cellH * 0.8f)..maxH && cw > maxW && cw <= cellW * 7f) {
                // icons that touch: a row, cut into equal parts the size of the height
                val parts2 = maxOf(2, Math.round(cw / ch))
                for (i in 0 until parts2) found.add(intArrayOf(cl + (cw * i / parts2).toInt(), ct, cl + (cw * (i + 1) / parts2).toInt() - 1, cb))
            } else if (cw in (cellW * 0.8f)..maxW && ch > maxH && ch <= cellH * 7f) {
                val parts2 = maxOf(2, Math.round(ch / cw))
                for (i in 0 until parts2) found.add(intArrayOf(cl, ct + (ch * i / parts2).toInt(), cr, ct + (ch * (i + 1) / parts2).toInt() - 1))
            }
        }
        // only things that are new on the screen (a piece of the board that was there before is not a choice)
        val fresh = found.filter { f ->
            var diff = 0
            var total = 0
            for (y in f[1]..f[3]) for (x in f[0]..f[2]) { total++; if (abs(now.px[y * w + x] - before.px[y * w + x]) > CHANGE) diff++ }
            total > 0 && diff >= total * 0.35
        }
        // reading order: rows (centres within half a square of each other), then left to right
        val sorted = fresh.sortedBy { (it[1] + it[3]) / 2 }
        val rows = ArrayList<MutableList<IntArray>>()
        for (f in sorted) {
            val cy = (f[1] + f[3]) / 2f
            val row = rows.lastOrNull()
            if (row != null && abs((row[0][1] + row[0][3]) / 2f - cy) <= cellH * 0.5f) row.add(f) else rows.add(mutableListOf(f))
        }
        val out = ArrayList<Spot>()
        for (row in rows) for (f in row.sortedBy { it[0] }) {
            out.add(Spot((f[0] + f[2] + 1) / 2f / w, (f[1] + f[3] + 1) / 2f / h, f[0] / w.toFloat(), f[1] / h.toFloat(), (f[2] + 1) / w.toFloat(), (f[3] + 1) / h.toFloat()))
        }
        return out
    }

    /** The first icon of the box (see [icons]), for squares of 21 x 21 pixels. Null if there is no box. */
    fun find(before: Gray, now: Gray): Spot? = icons(before, now, 21f, 21f).firstOrNull()

    private fun grow(m: BooleanArray, w: Int, h: Int, r: Int): BooleanArray {
        val tmp = BooleanArray(w * h)
        for (y in 0 until h) {
            var last = -1000
            for (x in 0 until w) {
                if (m[y * w + x]) last = x
                if (x - last <= r) tmp[y * w + x] = true
            }
            last = 100000
            for (x in w - 1 downTo 0) {
                if (m[y * w + x]) last = x
                if (last - x <= r) tmp[y * w + x] = true
            }
        }
        val out = BooleanArray(w * h)
        for (x in 0 until w) {
            var last = -1000
            for (y in 0 until h) {
                if (tmp[y * w + x]) last = y
                if (y - last <= r) out[y * w + x] = true
            }
            last = 100000
            for (y in h - 1 downTo 0) {
                if (tmp[y * w + x]) last = y
                if (last - y <= r) out[y * w + x] = true
            }
        }
        return out
    }
}
