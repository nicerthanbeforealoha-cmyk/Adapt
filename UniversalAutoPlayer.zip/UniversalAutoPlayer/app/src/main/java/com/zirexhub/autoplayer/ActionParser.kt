package com.zirexhub.autoplayer

import org.json.JSONObject
import java.io.IOException
import java.util.Locale
import kotlin.math.min
import kotlin.math.roundToInt

/** Turns the AI's text reply into a [Decision]. Accepts one flat action or an "actions" list. */
object ActionParser {

    fun parse(reply: String, w: Int, h: Int, maxActions: Int): Decision {
        val start = reply.indexOf('{')
        val end = reply.lastIndexOf('}')
        if (start < 0 || end <= start) throw IOException("No JSON in reply: ${reply.take(80)}")

        val j = JSONObject(reply.substring(start, end + 1))
        val note = j.optString("plan").ifBlank { j.optString("observation") }.take(160)

        val actions = ArrayList<GameAction>()
        val labels = ArrayList<String>()

        val arr = j.optJSONArray("actions")
        if (arr != null && arr.length() > 0) {
            val limit = min(arr.length(), maxActions.coerceAtLeast(1))
            for (i in 0 until limit) {
                val o = arr.optJSONObject(i) ?: continue
                val (a, label) = convert(o, w, h, note)
                actions.add(a)
                labels.add(label)
                if (a is GameAction.Finish) break
            }
        } else {
            val (a, label) = convert(j, w, h, note)
            actions.add(a)
            labels.add(label)
        }
        if (actions.isEmpty()) {
            actions.add(GameAction.Wait(1000L))
            labels.add("wait(1000ms)")
        }
        return Decision(actions, note, labels.joinToString(" ; "))
    }

    /** Coordinates from the model are pixels of the image we sent; convert to 0..1. */
    private fun norm(v: Double, dim: Int): Float =
        (if (v <= 1.0) v else v / dim).toFloat().coerceIn(0f, 1f)

    private fun convert(o: JSONObject, w: Int, h: Int, note: String): Pair<GameAction, String> {
        val x = norm(o.optDouble("x", 0.5), w)
        val y = norm(o.optDouble("y", 0.5), h)
        val x2 = norm(o.optDouble("x2", 0.5), w)
        val y2 = norm(o.optDouble("y2", 0.5), h)
        val px = (x * w).roundToInt()
        val py = (y * h).roundToInt()
        val ms = o.optLong("duration_ms", 0L)

        return when (o.optString("action").lowercase(Locale.US).trim()) {
            "tap", "click" -> {
                val count = o.optInt("count", 1).coerceIn(1, 20)
                val suffix = if (count > 1) " x$count" else ""
                Pair(GameAction.Tap(x, y, count), "tap($px,$py)$suffix")
            }
            "double_tap" -> Pair(GameAction.Tap(x, y, 2), "double_tap($px,$py)")
            "long_press", "hold" -> {
                val d = if (ms > 0) ms.coerceIn(300L, 3000L) else 800L
                Pair(GameAction.LongPress(x, y, d), "long_press($px,$py,${d}ms)")
            }
            "swipe", "drag", "scroll" -> {
                val d = if (ms > 0) ms.coerceIn(80L, 2500L) else 300L
                val ex = (x2 * w).roundToInt()
                val ey = (y2 * h).roundToInt()
                Pair(GameAction.Swipe(x, y, x2, y2, d), "swipe($px,$py->$ex,$ey,${d}ms)")
            }
            "wait" -> {
                val d = if (ms > 0) ms.coerceIn(300L, 5000L) else 1000L
                Pair(GameAction.Wait(d), "wait(${d}ms)")
            }
            "back" -> Pair(GameAction.Back, "back")
            "finish", "done", "stop" -> {
                val reason = o.optString("reason").ifBlank { note }
                Pair(GameAction.Finish(reason), "finish")
            }
            else -> Pair(GameAction.Wait(1000L), "wait(1000ms)")
        }
    }
}
