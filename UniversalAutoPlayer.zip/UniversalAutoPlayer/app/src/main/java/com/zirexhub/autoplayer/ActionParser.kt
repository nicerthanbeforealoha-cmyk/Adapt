package com.zirexhub.autoplayer

import org.json.JSONObject
import java.io.IOException
import java.util.Locale
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Turns the AI's text reply into a [Decision]. Accepts one flat action or an "actions" list.
 *
 * Coordinates: Gemini is asked for a 0..1000 scale ([scale] = 1000, its own native scale and independent of the picture
 * size), the other providers for pixels of the picture they were given ([scale] = 0). A model does not always obey, so the
 * reply is checked as a whole: values that do not fit the asked-for scale but fit the other one switch the whole reply to
 * the other one. A point that fits neither is an ERROR, never silently moved to the screen edge: the chess log had
 * "x=567" on a picture only 461 pixels wide, which became a tap on the right edge.
 *
 * Board games: with a [grid] the AI can name cells ("col":5,"row":7) and the app computes the exact centre.
 */
object ActionParser {

    /**
     * [dragAsTaps]: "drag_cell" is played as two taps (the piece, then its target). Found in a real chess app: dragging only
     * SELECTED the piece (the screen changed by the same 0.0025 as a plain selection, and the pawn never moved), while two taps
     * moved it. The caller turns this off when taps are shown not to move pieces.
     */
    fun parse(reply: String, w: Int, h: Int, maxActions: Int, scale: Int = 0, grid: Grid? = null, dragAsTaps: Boolean = true): Decision {
        val start = reply.indexOf('{')
        val end = reply.lastIndexOf('}')
        if (start < 0 || end <= start) throw IOException("No JSON in reply: ${reply.take(80)}")

        val j = JSONObject(reply.substring(start, end + 1))
        val note = j.optString("plan").ifBlank { j.optString("observation") }.take(160)

        val objs = ArrayList<JSONObject>()
        val arr = j.optJSONArray("actions")
        if (arr != null && arr.length() > 0) {
            val limit = min(arr.length(), maxActions.coerceAtLeast(1))
            for (i in 0 until limit) arr.optJSONObject(i)?.let { objs.add(it) }
        } else {
            objs.add(j)
        }

        val space = Space.pick(objs, w, h, scale)
        val actions = ArrayList<GameAction>()
        val labels = ArrayList<String>()
        for (o in objs) {
            val two = if (dragAsTaps) dragAsTwoTaps(o, grid) else null
            if (two != null) {
                for ((a, label) in two) {
                    actions.add(a)
                    labels.add(label)
                }
                continue
            }
            val (a, label) = convert(o, w, h, note, space, grid)
            actions.add(a)
            labels.add(label)
            if (a is GameAction.Finish) break
        }
        if (actions.isEmpty()) {
            actions.add(GameAction.Wait(1000L))
            labels.add("wait(1000ms)")
        }
        // a chess reading ("fen": the pieces as drawn on the screen), see BoardPlan
        val fen = listOf("fen", "board_fen", "position").map { j.optString(it).trim() }.firstOrNull { it.contains('/') }
        val read = fen?.let { BoardRead(it.take(120), j.optString("white_at")) }
        return Decision(actions, note, labels.joinToString(" ; "), false, read)
    }

    /** Which number scale a whole reply uses. [unit] = the value that means "the whole picture": 1000, or 0 = pixels. */
    class Space(val unit: Int) {
        /** 0..1 position of [v] along a side of [dim] pixels. A value of 1.0 or less is already a fraction. */
        fun frac(v: Double, dim: Int): Float {
            if (v <= 1.0) return v.toFloat().coerceAtLeast(0f)
            val d = if (unit > 0) unit.toDouble() else dim.toDouble()
            return (v / d).toFloat()
        }

        companion object {
            private const val SLACK = 1.05

            fun pick(objs: List<JSONObject>, w: Int, h: Int, asked: Int): Space {
                var fitsUnits = true
                var fitsPixels = true
                var biggest = 0.0
                for (o in objs) {
                    for ((key, dim) in listOf("x" to w, "x2" to w, "y" to h, "y2" to h)) {
                        if (!o.has(key)) continue
                        val v = o.optDouble(key, 0.0)
                        if (v <= 1.0) continue
                        biggest = maxOf(biggest, v)
                        if (v > 1000.0 * SLACK) fitsUnits = false
                        if (v > dim * SLACK) fitsPixels = false
                    }
                }
                val unitsFirst = asked > 0
                return when {
                    unitsFirst && fitsUnits -> Space(1000)
                    !unitsFirst && fitsPixels -> Space(0)
                    fitsPixels -> Space(0)
                    fitsUnits -> Space(1000)
                    else -> throw IOException("The AI gave a point outside the picture (${biggest.roundToInt()} on a ${w}x$h picture)")
                }
            }
        }
    }

    private fun checkCell(grid: Grid, c: Int, r: Int) {
        if (c < 1 || c > grid.cols || r < 1 || r > grid.rows) {
            throw IOException("The AI named a cell outside the board: col $c row $r on a ${grid.cols}x${grid.rows} board")
        }
    }

    /** "drag_cell" / a swipe between two cells, as two taps: the piece, then the cell it goes to. Null = not such an action. */
    private fun dragAsTwoTaps(o: JSONObject, grid: Grid?): List<Pair<GameAction, String>>? {
        if (grid == null || !o.has("col") || !o.has("row") || !o.has("col2") || !o.has("row2")) return null
        val base = o.optString("action").lowercase(Locale.US).trim().removeSuffix("_cell").removeSuffix("_square")
        if (base != "swipe" && base != "drag" && base != "move") return null
        val c = o.optInt("col")
        val r = o.optInt("row")
        val c2 = o.optInt("col2")
        val r2 = o.optInt("row2")
        checkCell(grid, c, r)
        checkCell(grid, c2, r2)
        val a = "cell($c,$r)"
        val b = "cell($c2,$r2)"
        return listOf(
            Pair(GameAction.Tap(grid.cx(c), grid.cy(r), 1, a, true), a),
            Pair(GameAction.Tap(grid.cx(c2), grid.cy(r2), 1, b, true), b),
        )
    }

    private fun convert(o: JSONObject, w: Int, h: Int, note: String, space: Space, grid: Grid?): Pair<GameAction, String> {
        val name = o.optString("action").lowercase(Locale.US).trim()
        val cellAction = name.endsWith("_cell") || name.endsWith("_square")
        val hasCell = o.has("col") && o.has("row")
        val hasCell2 = o.has("col2") && o.has("row2")

        var x = space.frac(o.optDouble("x", 0.5), w).coerceIn(0f, 1f)
        var y = space.frac(o.optDouble("y", 0.5), h).coerceIn(0f, 1f)
        var x2 = space.frac(o.optDouble("x2", 0.5), w).coerceIn(0f, 1f)
        var y2 = space.frac(o.optDouble("y2", 0.5), h).coerceIn(0f, 1f)
        var cellText = ""
        var exact = false
        if ((cellAction || hasCell) && grid != null && hasCell) {
            val c = o.optInt("col")
            val r = o.optInt("row")
            checkCell(grid, c, r)
            x = grid.cx(c)
            y = grid.cy(r)
            exact = true
            cellText = "cell($c,$r)"
            if (hasCell2) {
                val c2 = o.optInt("col2")
                val r2 = o.optInt("row2")
                checkCell(grid, c2, r2)
                x2 = grid.cx(c2)
                y2 = grid.cy(r2)
                cellText += "->cell($c2,$r2)"
            }
        } else if ((cellAction || hasCell) && grid == null && (cellAction || !o.has("x"))) {
            // a cell action without a board: nothing safe to press
            return Pair(GameAction.Wait(1000L), "wait(1000ms)")
        }

        val px = (x * w).roundToInt()
        val py = (y * h).roundToInt()
        val ms = o.optLong("duration_ms", 0L)
        val base = name.removeSuffix("_cell").removeSuffix("_square")

        return when (base) {
            "tap", "click", "select", "press" -> {
                val count = o.optInt("count", 1).coerceIn(1, 20)
                val suffix = if (count > 1) " x$count" else ""
                // "text" = the words on the button or card the model means; the app moves the press onto those OCR words
                val text = o.optString("text").trim().take(60)
                val shown = if (exact) cellText else "tap($px,$py)"
                val a = GameAction.Tap(x, y, count, if (exact) cellText else text, exact)
                Pair(a, shown + suffix + if (!exact && text.isNotEmpty()) " \"$text\"" else "")
            }
            "double_tap" -> Pair(GameAction.Tap(x, y, 2, if (exact) cellText else "", exact), if (exact) "double_$cellText" else "double_tap($px,$py)")
            "long_press", "hold" -> {
                val d = if (ms > 0) ms.coerceIn(300L, 3000L) else 800L
                Pair(GameAction.LongPress(x, y, d), "long_press($px,$py,${d}ms)")
            }
            "swipe", "drag", "scroll", "move" -> {
                val d = if (ms > 0) ms.coerceIn(80L, 2500L) else if (exact) 450L else 300L
                val ex = (x2 * w).roundToInt()
                val ey = (y2 * h).roundToInt()
                Pair(GameAction.Swipe(x, y, x2, y2, d), if (exact && hasCell2) "drag_$cellText" else "swipe($px,$py->$ex,$ey,${d}ms)")
            }
            "wait" -> {
                val d = if (ms > 0) ms.coerceIn(300L, 5000L) else 1000L
                Pair(GameAction.Wait(d), "wait(${d}ms)")
            }
            "back" -> Pair(GameAction.Back, "back")
            "finish", "done", "stop" -> {
                val reason = o.optString("reason").ifBlank { note }
                Pair(GameAction.Finish(reason), "finish")
            }
            else -> Pair(GameAction.Wait(1000L), "wait(1000ms)")
        }
    }
}
