package com.zirexhub.autoplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Settings screen: enable the service, choose AI provider / offline mode, pick a game, show the overlay. */
class MainActivity : Activity() {

    private val cBg = 0xFF0B1220.toInt()
    private val cCard = 0xFF131C2E.toInt()
    private val cField = 0xFF1B2740.toInt()
    private val cText = 0xFFE6EDF6.toInt()
    private val cMuted = 0xFF8FA3B8.toInt()
    private val cAccent = 0xFF35E0A1.toInt()

    private var currentProvider: Provider = Providers.GEMINI

    private lateinit var statusLine: TextView
    private lateinit var hintView: TextView
    private lateinit var swAi: Switch
    private lateinit var providerBtn: Button
    private lateinit var providerNote: TextView
    private lateinit var etKey: EditText
    private lateinit var etModel: EditText
    private lateinit var etBase: EditText
    private lateinit var etGoal: EditText
    private lateinit var etDelay: EditText
    private lateinit var etActions: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DebugLog.init(this)
        setContentView(buildUi())
        loadPrefs()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ---------------------------------------------------------------- UI helpers

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = t
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun input(hintText: String) = EditText(this).apply {
        this.hint = hintText
        setTextColor(cText)
        setHintTextColor(cMuted)
        textSize = 14f
        background = rounded(cField, 12)
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    private fun button(t: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        this.text = t
        isAllCaps = false
        textSize = 15f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (filled) 0xFF06210F.toInt() else cText)
        background = rounded(if (filled) cAccent else cField, 14)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        setOnClickListener { onClick() }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(cCard, 16)
        setPadding(dp(14), dp(14), dp(14), dp(14))
    }

    private fun LinearLayout.add(v: View, topDp: Int = 10) {
        addView(
            v,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(topDp) },
        )
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(28))
        }

        root.add(label("Universal AutoPlayer", 26f, cText, true), 0)
        root.add(label("Version ${BuildInfo.VERSION} (build ${BuildInfo.CODE})", 11f, cMuted), 2)
        root.add(
            label(
                "Looks at the screen, decides what to do, taps and swipes for you. " +
                    "Works on top of any game.",
                13f,
                cMuted,
            ),
            4,
        )

        // Step 1: accessibility service
        val s1 = card()
        s1.add(label("1. Turn on the service", 15f, cText, true), 0)
        statusLine = label("", 13f, cMuted)
        s1.add(statusLine, 6)
        hintView = label(
            "Settings > Accessibility > Installed apps > Universal AutoPlayer > On.\n" +
                "If Android says \"Restricted setting\": Settings > Apps > Universal AutoPlayer > " +
                "menu (3 dots) > Allow restricted settings, then try again.",
            12f,
            cMuted,
        )
        s1.add(hintView, 6)
        s1.add(
            button("Open accessibility settings", false) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            10,
        )
        root.add(s1, 16)

        // Step 2: brain
        val s2 = card()
        s2.add(label("2. Choose the brain", 15f, cText, true), 0)
        swAi = Switch(this).apply {
            this.text = "AI player (needs a vision AI key). Off = free offline bot"
            setTextColor(cText)
            textSize = 13f
        }
        s2.add(swAi, 8)
        s2.add(
            label(
                "Offline bot: reads the screen text on your phone, presses Continue / Play / Next / " +
                    "Claim, closes pop-ups, waits on loading screens, avoids buy / ad buttons. In a game " +
                    "it spends ~30 seconds working out how it is played (joystick, tapping, swiping, " +
                    "holding), then plays that way. No key, no internet.",
                11f,
                cMuted,
            ),
            6,
        )

        providerBtn = button("Provider", false) { chooseProvider() }
        s2.add(providerBtn, 12)
        providerNote = label("", 11f, cMuted)
        s2.add(providerNote, 4)
        etKey = input("API key (paste here)").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        s2.add(etKey, 8)
        etModel = input("Model ID (must accept images), e.g. gemini-3.8-flash")
        s2.add(etModel, 8)
        s2.add(button("Pick model from list (needs key)", false) { pickModel() }, 6)
        etBase = input("Base URL")
        s2.add(etBase, 8)
        etGoal = input("Rules for the AI, e.g. \"Match-3 game. Make combos. Never use boosters.\" (empty = play to win and survive as long as possible)").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
        }
        s2.add(etGoal, 12)
        etDelay = input("Pause between steps in seconds (0 = max speed, default 0.2)").apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        s2.add(etDelay, 8)
        etActions = input("Actions per AI call, 1 to 6 (default 3, more = faster)").apply {
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        s2.add(etActions, 8)
        s2.add(button("Save settings", true) { savePrefs(); toast("Saved") }, 12)
        s2.add(button("Test AI connection", false) { savePrefs(); testConnection() }, 8)
        root.add(s2, 12)

        // Step 3: go
        val s3 = card()
        s3.add(label("3. Play", 15f, cText, true), 0)
        s3.add(button("Pick a game and launch it", true) { savePrefs(); pickGame() }, 10)
        s3.add(button("Just show the floating button", false) { savePrefs(); showOverlayOnly() }, 8)
        s3.add(
            label(
                "A small PLAY/STOP chip floats over the game. Press PLAY to start, STOP to pause. " +
                    "Drag it by the three-line grip.",
                12f,
                cMuted,
            ),
            10,
        )
        root.add(s3, 12)

        root.add(button("Show debug log (why did it stop?)", false) { showLog() }, 12)

        root.add(
            label(
                "No app can promise to win every game. The AI takes a second or more per call, so it " +
                    "shines in puzzle, card, idle, tap and turn-based games and is weak in fast reflex " +
                    "games. Use it on offline or single-player games: bots in online competitive games " +
                    "usually break the rules and can get your account banned. AI mode sends screenshots " +
                    "of your screen to the provider you pick. The offline bot reads Latin-script text.",
                11f,
                cMuted,
            ),
            16,
        )

        return ScrollView(this).apply {
            setBackgroundColor(cBg)
            isFillViewport = true
            addView(root)
        }
    }

    // ---------------------------------------------------------------- state

    private fun loadPrefs() {
        swAi.isChecked = Prefs.mode(this) == Prefs.MODE_AI
        currentProvider = Prefs.provider(this)
        loadProviderFields()
        etGoal.setText(Prefs.rawGoal(this))
        etDelay.setText((Prefs.delayMs(this) / 1000.0).toString())
        etActions.setText(Prefs.actionsPerCall(this).toString())
    }

    private fun loadProviderFields() {
        val p = currentProvider
        providerBtn.text = "Provider: ${p.label} (tap to change)"
        providerNote.text = p.note
        etKey.hint = if (p.needsKey) "API key (paste here)" else "API key (leave empty if none)"
        etKey.setText(Prefs.apiKey(this, p))
        etModel.setText(Prefs.model(this, p))
        etBase.setText(Prefs.baseUrl(this, p))
    }

    private fun savePrefs() {
        val seconds = etDelay.text.toString().trim().toDoubleOrNull() ?: 0.2
        val actions = etActions.text.toString().trim().toIntOrNull() ?: 3
        Prefs.save(
            this,
            if (swAi.isChecked) Prefs.MODE_AI else Prefs.MODE_OFFLINE,
            currentProvider,
            etKey.text.toString(),
            etModel.text.toString(),
            etBase.text.toString(),
            etGoal.text.toString(),
            (seconds * 1000).toLong(),
            actions,
        )
    }

    private fun refreshStatus() {
        val on = AutoPlayService.instance != null
        statusLine.text = if (on) "Service is ON. You are ready." else "Service is OFF."
        statusLine.setTextColor(if (on) cAccent else 0xFFFF8A80.toInt())
        hintView.visibility = if (on) View.GONE else View.VISIBLE
    }

    private fun chooseProvider() {
        savePrefs() // keep what was typed for the current provider
        val all = Providers.all
        AlertDialog.Builder(this)
            .setTitle("AI provider")
            .setItems(all.map { it.label }.toTypedArray()) { _, i ->
                currentProvider = all[i]
                loadProviderFields()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun testConnection() {
        val p = currentProvider
        val key = Prefs.apiKey(this, p)
        val model = Prefs.model(this, p)
        val base = Prefs.baseUrl(this, p)
        if (p.needsKey && key.isBlank()) {
            toast("Paste an API key first.")
            return
        }
        if (model.isBlank() || base.isBlank()) {
            toast("Fill in the model name and base URL first.")
            return
        }
        toast("Testing...")
        Thread {
            var usedModel = model
            val msg = try {
                val answer = try {
                    AiBrain(AiBrain.Config(p, key, model, base)).ping()
                } catch (e: ModelProblemException) {
                    // Retired or mistyped model: find the newest one of the same family that works, and keep it.
                    val fixed = AiBrain.heal(AiBrain.Config(p, key, model, base), e.message ?: "") ?: throw e
                    Prefs.setModel(this, p, fixed)
                    usedModel = fixed
                    runOnUiThread { etModel.setText(fixed) }
                    AiBrain(AiBrain.Config(p, key, fixed, base)).ping()
                }
                val fixedNote = if (usedModel != model) {
                    "Fixed automatically: \"$model\" is not usable any more, so I switched to \"$usedModel\" and saved it.\n\n"
                } else {
                    ""
                }
                fixedNote + "It works. The AI answered: " + answer.trim().take(60) +
                    "\n\n(This only tests the key and model name. The model must also accept images.)"
            } catch (e: Exception) {
                "Failed: ${e.message}"
            }
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setTitle("Connection test")
                    .setMessage(msg)
                    .setPositiveButton("OK", null)
                    .show()
            }
        }.start()
    }

    private fun pickModel() {
        val p = currentProvider
        val key = etKey.text.toString().trim()
        val base = etBase.text.toString().trim().ifBlank { p.defaultBase }
        if (p.needsKey && key.isBlank()) {
            toast("Paste your API key first.")
            return
        }
        if (base.isBlank()) {
            toast("Fill in the base URL first.")
            return
        }
        toast("Loading models...")
        Thread {
            try {
                val list = AiBrain.listModels(AiBrain.Config(p, key, "", base))
                runOnUiThread {
                    if (list.isEmpty()) {
                        toast("The provider returned no models.")
                    } else {
                        AlertDialog.Builder(this)
                            .setTitle("Pick a model (${list.size})")
                            .setItems(list.toTypedArray()) { _, i -> etModel.setText(list[i]) }
                            .setNegativeButton("Cancel", null)
                            .show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Could not load models: ${e.message}") }
            }
        }.start()
    }

    private fun showLog() {
        val tv = TextView(this).apply {
            this.text = DebugLog.dump()
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val sv = ScrollView(this).apply { addView(tv) }
        AlertDialog.Builder(this)
            .setTitle("Debug log")
            .setView(sv)
            .setPositiveButton("Copy") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("debug log", DebugLog.dump(400)))
                toast("Log copied")
            }
            .setNeutralButton("Clear") { _, _ -> DebugLog.clear() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun serviceOrToast(): AutoPlayService? {
        val s = AutoPlayService.instance
        if (s == null) toast("Turn on the accessibility service first (step 1).")
        return s
    }

    private fun showOverlayOnly() {
        val s = serviceOrToast() ?: return
        s.showOverlay()
        toast("Open your game, then press PLAY on the floating button.")
        moveTaskToBack(true)
    }

    private fun pickGame() {
        val s = serviceOrToast() ?: return
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps: List<ResolveInfo> = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        if (apps.isEmpty()) {
            toast("No launchable apps found.")
            return
        }
        val names = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pick a game")
            .setItems(names) { _, i ->
                val launch = pm.getLaunchIntentForPackage(apps[i].activityInfo.packageName)
                if (launch == null) {
                    toast("Cannot launch that app.")
                } else {
                    s.showOverlay()
                    startActivity(launch)
                    toast("Press PLAY on the floating button when the game is ready.")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
