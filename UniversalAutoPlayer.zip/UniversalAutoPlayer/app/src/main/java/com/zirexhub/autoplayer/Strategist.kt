package com.zirexhub.autoplayer

import java.util.Random
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** The four ways a finger can play a game. */
enum class Family { TAP, DRAG, SWIPE, HOLD }

/** What the strategist wants to do next. Coordinates are 0..1 of the screen. */
sealed class Move {
    /** Tap somewhere: the planner's tap-explorer picks where. */
    object Tap : Move()

    /** Joystick push: finger down at (ax, ay), slides to (tx, ty) over [ms], held while the bot thinks. */
    class Drag(val ax: Float, val ay: Float, val tx: Float, val ty: Float, val ms: Long, val why: String) : Move()

    class Swipe(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val ms: Long, val why: String) : Move()

    class Hold(val x: Float, val y: Float, val ms: Long, val why: String) : Move()

    /** Do nothing for a moment and just watch. */
    class Idle(val ms: Long, val why: String) : Move()
}

/**
 * Works out HOW a game is played, from scratch, in about 30 seconds, and then plays that way.
 * Pure Kotlin (no Android), so it is unit tested on a PC with simulated games.
 *
 *  1. WATCH  : two idle looks measure how much the screen moves by itself (animations).
 *  2. PROBE  : tries each kind of input (joystick drag, tap, swipe, hold) a few times and scores how much
 *              each one changed the screen ABOVE that idle level. A drag that makes the whole scene slide
 *              (the camera follows the player) scores very high, a tap that raises a counter scores high.
 *  3. PLAY   : keeps using the family that works (about 80% of the time) and keeps testing the others,
 *              so it adapts when the game changes (menu -> battle -> puzzle bonus round).
 *
 * Joystick play: sticky anchor where the drag worked, heading that wanders, turns away from walls (a drag
 * that moved nothing), and runs away from clusters of things that move on their own (enemies).
 */
class Strategist(private val rnd: Random = Random()) {

    companion object {
        const val PROBE_MS = 30_000L
        private val ORDER = arrayOf(Family.DRAG, Family.TAP, Family.SWIPE, Family.HOLD)
        private val MIN_TRIES = mapOf(Family.DRAG to 6, Family.TAP to 7, Family.SWIPE to 4, Family.HOLD to 2)
        private const val MIN_VALUE = 0.06f
        private const val DRAG_RADIUS = 0.16f // of the screen width

        // Where a joystick usually lives, or where a floating one is likely to be allowed.
        private val ANCHORS = arrayOf(
            0.20f to 0.82f, 0.80f to 0.82f, 0.50f to 0.74f, 0.14f to 0.70f, 0.86f to 0.70f, 0.32f to 0.88f,
        )

        private val COMPASS = arrayOf("right", "down-right", "down", "down-left", "left", "up-left", "up", "up-right")

        fun label(f: Family?): String = when (f) {
            Family.DRAG -> "movement (joystick / drag)"
            Family.TAP -> "tapping"
            Family.SWIPE -> "swiping"
            Family.HOLD -> "press and hold"
            null -> "unknown yet"
        }
    }

    private val famN = IntArray(4)
    private val famV = FloatArray(4)
    private val famPeak = FloatArray(4) // best recent result: a tapper only reacts at ONE spot
    private val famHits = IntArray(4) // how many clear successes
    private val famStrong = BooleanArray(4) // a number on screen went up because of it
    private val anchorN = IntArray(ANCHORS.size)
    private val anchorV = FloatArray(ANCHORS.size)
    private val swipeN = IntArray(4)
    private val swipeV = FloatArray(4)

    private var baseline = 0.02f
    private var idleSeen = 0
    private var idleObs = 0
    private var startMs = -1L
    private var heading = 0.0
    private var moves = 0

    private var lastMove: Move? = null
    private var lastFam: Family? = null
    private var lastAnchor = -1
    private var lastSwipeDir = -1
    private var lastWasDrag = false
    private var lastDragLift = 1f
    private var totalDrags = 0

    // ------------------------------------------------------------------ what we learned

    /**
     * How well a family works. The running average, but a family that has clearly worked a couple of times
     * (or made a score number go up) is also credited for its best result, because some inputs only
     * work in one place (the coin of a clicker) and most tries of them look like failures.
     */
    private fun value(i: Int): Float =
        if (famHits[i] >= 2 || famStrong[i]) max(famV[i], 0.6f * famPeak[i]) else famV[i]

    /** The family that works best so far, or null if nothing has shown a clear effect yet. */
    fun style(): Family? {
        var best: Family? = null
        var bv = MIN_VALUE
        for (f in Family.values()) {
            val i = f.ordinal
            if (famN[i] >= 2 && value(i) > bv) {
                bv = value(i)
                best = f
            }
        }
        return best
    }

    /** 0..1: how far ahead the best family is of the runner-up. */
    fun confidence(): Float {
        val s = style() ?: return 0f
        var second = 0f
        for (f in Family.values()) if (f != s) second = max(second, value(f.ordinal))
        val b = value(s.ordinal)
        return (b / (b + second + 0.05f)).coerceIn(0f, 1f)
    }

    fun isProbing(nowMs: Long): Boolean = startMs < 0 || nowMs - startMs < PROBE_MS

    /** Short status text, for the chip. */
    fun status(nowMs: Long): String {
        if (startMs < 0) return "Learning the game"
        val sec = ((nowMs - startMs) / 1000).toInt()
        return if (isProbing(nowMs)) "Learning the game ${min(sec, 30)}s/30s" else "Style: ${label(style())}"
    }

    /** One line for the debug log. */
    fun describe(): String =
        "style=${label(style())} conf=${"%.2f".format(confidence())} base=${"%.3f".format(baseline)} " +
            Family.values().joinToString(" ") { "${it.name.lowercase()}=${"%.2f".format(value(it.ordinal))}(${famN[it.ordinal]})" }

    // ------------------------------------------------------------------ learning from results

    /**
     * Call once per step, BEFORE next(): scores the move made last time by what the screen did afterwards.
     * [change] is how much the screen changed since the previous step, [motion] how it moved,
     * [scoreUp] whether an on-screen number went up.
     */
    fun observe(change: Float?, motion: MotionInfo?, scoreUp: Boolean) {
        val m = lastMove ?: return
        lastMove = null
        if (change == null) return
        if (m is Move.Idle) {
            // two frames with no input between them: a clean measure of how much the game moves by itself
            idleObs++
            baseline = if (idleObs == 1) change.coerceIn(0f, 0.6f) else 0.6f * baseline + 0.4f * change.coerceIn(0f, 0.6f)
            return
        }
        if (change < baseline) baseline = 0.8f * baseline + 0.2f * change // quieter than thought: learn it
        val fam = lastFam ?: return
        val over = max(0f, change - baseline)
        var lift = min(over, 0.5f) + (if (scoreUp) 0.5f else 0f)
        if (fam == Family.DRAG) {
            val coh = motion?.coherence ?: 0f
            val mag = min(1f, (motion?.magnitude ?: 0f) / 3f)
            lift += coh * mag
        }
        val i = fam.ordinal
        famV[i] = if (famN[i] == 0) lift else 0.7f * famV[i] + 0.3f * lift
        famPeak[i] = max(lift, famPeak[i] * 0.97f)
        if (lift > 0.1f) famHits[i]++
        if (scoreUp) famStrong[i] = true
        famN[i]++
        if (fam == Family.DRAG && lastAnchor >= 0) {
            anchorV[lastAnchor] = if (anchorN[lastAnchor] == 0) lift else 0.6f * anchorV[lastAnchor] + 0.4f * lift
            anchorN[lastAnchor]++
            lastDragLift = lift
        }
        if (fam == Family.SWIPE && lastSwipeDir >= 0) {
            swipeV[lastSwipeDir] = if (swipeN[lastSwipeDir] == 0) lift else 0.6f * swipeV[lastSwipeDir] + 0.4f * lift
            swipeN[lastSwipeDir]++
        }
        // a drag that moved nothing at a spot that used to work is a wall
        if (fam != Family.DRAG) lastDragLift = 1f
    }

    // ------------------------------------------------------------------ choosing the next move

    /**
     * @param aspect screen height / width (for round joystick circles)
     * @param free   true if a point is OK to touch (not near a buy button, not our own chip)
     */
    fun next(nowMs: Long, aspect: Float, free: (Float, Float) -> Boolean, motion: MotionInfo?): Move {
        if (startMs < 0) startMs = nowMs
        moves++

        if (idleSeen < 2) {
            idleSeen++
            return remember(Move.Idle(350L, "Learning the game: watching the screen first"), null)
        }

        val fam = chooseFamily(nowMs)
        val tag = status(nowMs)
        val move: Move = when (fam) {
            Family.TAP -> Move.Tap
            Family.DRAG -> planDrag(tag, aspect, free, motion)
            Family.SWIPE -> planSwipe(tag, free)
            Family.HOLD -> planHold(tag, free)
        }
        return remember(move, if (move is Move.Idle) null else fam)
    }

    private fun remember(m: Move, fam: Family?): Move {
        lastMove = m
        lastFam = fam
        lastWasDrag = m is Move.Drag
        return m
    }

    private fun bestFamily(): Family? = style()

    private fun chooseFamily(nowMs: Long): Family {
        if (isProbing(nowMs)) {
            var pick: Family? = null
            var worst = 1f
            for (f in ORDER) {
                val need = MIN_TRIES[f] ?: 2
                val ratio = famN[f.ordinal].toFloat() / need
                if (ratio < worst) {
                    worst = ratio
                    pick = f
                }
            }
            if (pick != null) return pick
            return bestFamily() ?: ORDER[moves % ORDER.size]
        }
        val best = bestFamily() ?: return ORDER[moves % ORDER.size] // nothing worked yet: keep cycling
        if (rnd.nextFloat() < 0.18f) {
            val others = ORDER.filter { it != best }
            return others[rnd.nextInt(others.size)]
        }
        return best
    }

    // ------------------------------------------------------------------ joystick

    private fun planDrag(tag: String, aspect: Float, free: (Float, Float) -> Boolean, motion: MotionInfo?): Move {
        totalDrags++
        // 1) where to put the finger down
        var anchor = -1
        val untried = (0 until ANCHORS.size).filter { anchorN[it] == 0 }
        val firstUntried = untried.firstOrNull { free(ANCHORS[it].first, ANCHORS[it].second) }
        if (firstUntried != null && totalDrags <= ANCHORS.size + 1) {
            anchor = firstUntried
        } else if (lastAnchor >= 0 && lastDragLift >= 0.35f && free(ANCHORS[lastAnchor].first, ANCHORS[lastAnchor].second)) {
            anchor = lastAnchor // it works, stay with it
        } else {
            var bs = -1e9f
            val total = max(2, anchorN.sum())
            for (i in ANCHORS.indices) {
                if (!free(ANCHORS[i].first, ANCHORS[i].second)) continue
                val s = anchorV[i] + 0.25f * sqrt(ln(total.toFloat()) / (anchorN[i] + 1)) + rnd.nextFloat() * 0.02f
                if (s > bs) {
                    bs = s
                    anchor = i
                }
            }
        }
        if (anchor < 0) return Move.Idle(600L, "$tag: no safe place to put a finger, waiting")

        // 2) which way to push
        val probingPass = totalDrags <= ANCHORS.size
        if (probingPass) {
            heading = 0.0 // first pass: every spot is tested with the same push to the right
        } else {
            val wall = lastWasDrag && lastDragLift < 0.2f && anchorV[anchor] > 0.3f
            val flee = fleeAngle(motion)
            heading = when {
                wall -> heading + PI * (0.55 + rnd.nextDouble() * 0.45) * (if (rnd.nextBoolean()) 1 else -1)
                flee != null -> blendAngle(heading, flee, 0.7)
                else -> heading + (rnd.nextDouble() - 0.5) * (PI / 2.2)
            }
        }
        heading = normalize(heading)

        // 3) find a direction whose end point is also safe
        val ax = ANCHORS[anchor].first
        val ay = ANCHORS[anchor].second
        var h = heading
        var tx = 0f
        var ty = 0f
        var ok = false
        for (attempt in 0 until 7) {
            tx = (ax + DRAG_RADIUS * cos(h)).toFloat().coerceIn(0.03f, 0.97f)
            ty = (ay + DRAG_RADIUS * sin(h) / aspect).toFloat().coerceIn(0.03f, 0.97f)
            if (free(tx, ty) && free((ax + tx) / 2f, (ay + ty) / 2f)) {
                ok = true
                break
            }
            h = normalize(h + PI / 3)
        }
        if (!ok) return Move.Idle(500L, "$tag: the joystick path is blocked, waiting")
        heading = h
        lastAnchor = anchor
        val dir = COMPASS[((h / (PI / 4)).roundToInt() % 8 + 8) % 8]
        val why = "$tag: push joystick $dir (${(ax * 100).toInt()}%,${(ay * 100).toInt()}%)"
        return Move.Drag(ax, ay, tx, ty, 900L, why)
    }

    /** Direction pointing AWAY from where things move on their own, or null if nothing stands out. */
    private fun fleeAngle(motion: MotionInfo?): Double? {
        val r = motion?.residual ?: return null
        var vx = 0.0
        var vy = 0.0
        var sum = 0.0
        for (k in 0 until 9) {
            if (k == 4) continue // the middle holds our own character
            val ox = (k % 3) - 1
            val oy = (k / 3) - 1
            vx += r[k] * ox
            vy += r[k] * oy
            sum += r[k]
        }
        if (sum < 0.04) return null
        val strength = sqrt(vx * vx + vy * vy) / sum
        if (strength < 0.35) return null
        return atan2(-vy, -vx)
    }

    private fun normalize(a: Double): Double {
        var x = a
        while (x > PI) x -= 2 * PI
        while (x < -PI) x += 2 * PI
        return x
    }

    private fun blendAngle(from: Double, to: Double, k: Double): Double = normalize(from + normalize(to - from) * k)

    // ------------------------------------------------------------------ swipe and hold

    private fun planSwipe(tag: String, free: (Float, Float) -> Boolean): Move {
        // 0 left, 1 up, 2 right, 3 down
        var dir: Int = swipeN.indices.firstOrNull { swipeN[it] == 0 } ?: -1
        if (dir < 0) {
            var total = 0f
            val w = FloatArray(4) { max(0.03f, swipeV[it]) + 0.04f }
            for (x in w) total += x
            var roll = rnd.nextFloat() * total
            dir = 3
            for (i in 0 until 4) {
                roll -= w[i]
                if (roll <= 0f) {
                    dir = i
                    break
                }
            }
        }
        lastSwipeDir = dir
        val names = arrayOf("left", "up", "right", "down")
        val cx = 0.5f
        val cy = 0.55f
        val (x1, y1, x2, y2) = when (dir) {
            0 -> listOf(0.78f, cy, 0.22f, cy)
            1 -> listOf(cx, 0.80f, cx, 0.32f)
            2 -> listOf(0.22f, cy, 0.78f, cy)
            else -> listOf(cx, 0.32f, cx, 0.80f)
        }
        if (!free(x1, y1) || !free(x2, y2)) return Move.Idle(400L, "$tag: swipe path is blocked, waiting")
        return Move.Swipe(x1, y1, x2, y2, 220L, "$tag: swipe ${names[dir]}")
    }

    private fun planHold(tag: String, free: (Float, Float) -> Boolean): Move {
        for (attempt in 0 until 6) {
            val x = 0.5f + (rnd.nextFloat() - 0.5f) * 0.5f
            val y = 0.6f + (rnd.nextFloat() - 0.5f) * 0.4f
            if (free(x, y)) return Move.Hold(x, y, 900L, "$tag: press and hold")
        }
        return Move.Idle(400L, "$tag: nowhere safe to hold, waiting")
    }
}
