package com.zirexhub.autoplayer

import java.util.Random
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** The four ways a finger can play a game. */
enum class Family { TAP, DRAG, SWIPE, HOLD }

/** What the strategist wants to do next. Coordinates are 0..1 of the screen. */
sealed class Move {
    /** Tap somewhere: the planner's tap-explorer picks where. */
    object Tap : Move()

    /** Joystick push: finger down at (ax, ay), slides to (tx, ty) over [ms], held while the bot thinks. */
    class Drag(
        val ax: Float,
        val ay: Float,
        val tx: Float,
        val ty: Float,
        val ms: Long,
        val why: String,
        /** Also press a button with a second finger while the joystick is held (move + attack at once). */
        val withTap: Boolean = false,
    ) : Move()

    class Swipe(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val ms: Long, val why: String) : Move()

    class Hold(val x: Float, val y: Float, val ms: Long, val why: String) : Move()

    /** Do nothing for a moment and just watch. */
    class Idle(val ms: Long, val why: String) : Move()
}

/**
 * Works out HOW a game is played, from scratch, in about 30 seconds, and then plays that way.
 * Pure Kotlin (no Android), so it is unit tested on a PC with simulated games.
 *
 *  1. WATCH  : two idle looks measure how much the screen moves by itself (animations).
 *  2. PROBE  : tries each kind of input (joystick drag, tap, swipe, hold) a few times and scores how much
 *              each one changed the screen ABOVE that idle level. A drag that makes the whole scene slide
 *              (the camera follows the player) scores very high, a tap that raises a counter scores high.
 *  3. PLAY   : keeps using the family that works (about 80% of the time) and keeps testing the others,
 *              so it adapts when the game changes (menu -> battle -> puzzle bonus round).
 *
 * Joystick play: sticky anchor where the drag worked, heading that wanders, turns away from walls (a drag
 * that moved nothing), and runs away from clusters of things that move on their own (enemies).
 *
 * MOVEMENT FIRST: most action / survival games are played by moving. So after the two idle looks the bot tries the
 * joystick at the usual spots. As soon as pushing makes the whole scene slide (the camera follows the player) the game
 * is "confirmed as a movement game": from then on it keeps moving about 95% of the time, flees from enemies, and stops
 * wasting time tapping things (HUD bars, text). Other inputs are only re-checked now and then.
 *
 * MIXED games (move AND press): every family that clearly works stays in the mix, in proportion to how well it
 * works, and a button press is sent as a second finger while the joystick is held, so it does both at once.
 *
 * SURVIVAL: every run (start -> death) is timed. Each run uses one of a few "survival styles" (how hard it
 * runs from enemies, how steadily it keeps its heading, how big the joystick pushes are). After a death the
 * styles that lasted longest are used more, so it learns to survive as long as possible.
 */
class Strategist(private val rnd: Random = Random()) {

    companion object {
        const val PROBE_MS = 30_000L
        private val ORDER = arrayOf(Family.DRAG, Family.TAP, Family.SWIPE, Family.HOLD)
        private val MIN_TRIES = mapOf(Family.DRAG to 6, Family.TAP to 7, Family.SWIPE to 4, Family.HOLD to 2)
        private const val MIN_VALUE = 0.06f
        private const val DRAG_RADIUS = 0.16f // of the screen width

        // Where a joystick usually lives, or where a floating one is likely to be allowed.
        private val ANCHORS = arrayOf(
            0.20f to 0.82f, 0.80f to 0.82f, 0.50f to 0.74f, 0.14f to 0.70f, 0.86f to 0.70f, 0.32f to 0.88f,
        )

        /** How the joystick is played: how hard to flee, how much the heading wanders, how big the push is. */
        private class Profile(val flee: Double, val wander: Double, val radius: Float, val name: String)

        private val PROFILES = arrayOf(
            Profile(0.70, PI / 2.2, 0.16f, "balanced"),
            Profile(0.95, PI / 4.0, 0.16f, "run-away"),
            Profile(0.45, PI / 1.3, 0.16f, "wanderer"),
            Profile(0.85, PI / 3.0, 0.22f, "big-pushes"),
        )
        private const val EXPLORE = 0.10f // chance to try a family that is not working, so it can adapt
        private const val ACTIVE_SHARE = 0.30f // a family counts as "working" at 30% of the best one

        private val COMPASS = arrayOf("right", "down-right", "down", "down-left", "left", "up-left", "up", "up-right")

        fun label(f: Family?): String = when (f) {
            Family.DRAG -> "movement (joystick / drag)"
            Family.TAP -> "tapping"
            Family.SWIPE -> "swiping"
            Family.HOLD -> "press and hold"
            null -> "unknown yet"
        }
    }

    private val famN = IntArray(4)
    private val famV = FloatArray(4)
    private val famPeak = FloatArray(4) // best recent result: a tapper only reacts at ONE spot
    private val famHits = IntArray(4) // how many clear successes
    private val famStrong = BooleanArray(4) // a number on screen went up because of it
    private val famUp = IntArray(4) // times a number on screen went up right after this family's move
    private val dragEngaged = ArrayList<Boolean>() // last drags: did the whole scene slide because of the push?
    private var dragsObserved = 0
    private var movementLatched = false
    private var missStreak = 0 // pushes in a row without a visible slide
    private var hurtMoves = 0 // after losing health: flee harder for this many moves
    private var turnPending = false
    private val anchorN = IntArray(ANCHORS.size)
    private val anchorV = FloatArray(ANCHORS.size)
    private val swipeN = IntArray(4)
    private val swipeV = FloatArray(4)

    private var baseline = 0.02f
    private var idleSeen = 0
    private var idleObs = 0
    private var idleUps = 0 // times a number on screen went up while the bot did NOTHING: the score counts by itself
    private var startMs = -1L
    private var activeMs = 0L // time spent really playing (menus and popups do not use up the learning time)
    private var lastNextMs = -1L
    private var probeLen = PROBE_MS
    private var tapPicks = 0

    /** Set by the planner every step: the picture is moving by itself (a running game, not a frozen menu or popup). */
    var live = false

    /** Set by the planner every step: lava and thorn walls seen around the character (null when not looked at). */
    var hazards: HazardInfo? = null

    /** Set by the planner every step: enemies and gems found on the screen by colour (null = not looked at). */
    var threats: ThreatMap? = null

    /** Health 0..1 read from the bar under the character (null = no bar seen). */
    var hpFrac: Float? = null
    private var kiteActs = 0

    private var stallStreak = 0 // pushes in a row where the character stood still although the game was running
    private var avoidHeading = 0.0 // where the character got stuck: do not go that way again for a while
    private var avoidMoves = 0
    private var hazardTurns = 0
    private var hazardNote: String? = null

    /** What the hazard steering did lately, for the debug log (reading it empties it). */
    fun takeHazardNote(): String? {
        val n = hazardNote
        hazardNote = null
        return n
    }

    private var profile = 0
    private val profN = IntArray(PROFILES.size)
    private val profSum = DoubleArray(PROFILES.size)
    private var runStartMs = -1L

    /** How many runs (start -> death) were played, and how long the last and the best one lasted. */
    var runs = 0
        private set
    var lastRunMs = 0L
        private set
    var bestRunMs = 0L
        private set
    private var heading = 0.0
    private var moves = 0

    private var lastMove: Move? = null
    private var lastFam: Family? = null
    private var lastAnchor = -1
    private var lastSwipeDir = -1
    private var lastWasDrag = false
    private var lastDragLift = 1f
    private var totalDrags = 0

    // ------------------------------------------------------------------ what we learned

    /**
     * How well a family works. The running average, but a family that has clearly worked a couple of times
     * (or made a score number go up) is also credited for its best result, because some inputs only
     * work in one place (the coin of a clicker) and most tries of them look like failures.
     */
    private fun value(i: Int): Float =
        if (famHits[i] >= 2 || famStrong[i]) max(famV[i], 0.6f * famPeak[i]) else famV[i]

    /** The family that works best so far, or null if nothing has shown a clear effect yet. */
    fun style(): Family? {
        var best: Family? = null
        var bv = MIN_VALUE
        for (f in Family.values()) {
            val i = f.ordinal
            if (famN[i] >= 2 && value(i) > bv) {
                bv = value(i)
                best = f
            }
        }
        return best
    }

    /** 0..1: how far ahead the best family is of the runner-up. */
    fun confidence(): Float {
        val s = style() ?: return 0f
        var second = 0f
        for (f in Family.values()) if (f != s) second = max(second, value(f.ordinal))
        val b = value(s.ordinal)
        return (b / (b + second + 0.05f)).coerceIn(0f, 1f)
    }

    /**
     * True when pushing the joystick clearly makes the scene slide: this is a movement (camera-follows-player) game.
     * Once seen it stays true: a few pushes without a visible slide (a wall, a flash, a popup) must not send a game
     * that is clearly played by moving back to "learning" (the bot then stood still testing hold and swipe mid-fight).
     * It is only dropped after 24 pushes in a row without any slide.
     */
    fun moveConfirmed(): Boolean = movementLatched

    /** The character just lost health: for the next few moves run away harder and change direction. */
    fun hurt() {
        hurtMoves = 8
        turnPending = true
    }

    fun isProbing(nowMs: Long): Boolean = !moveConfirmed() && (startMs < 0 || activeMs < probeLen)

    /** Families that clearly work. One entry = a pure game (joystick only, tapper only), two or more = a mixed game. */
    private fun activeSet(): List<Family> {
        var best = 0f
        for (f in ORDER) if (famN[f.ordinal] >= 2) best = max(best, value(f.ordinal))
        if (best < MIN_VALUE) return emptyList()
        val floor = max(MIN_VALUE, ACTIVE_SHARE * best)
        return ORDER.filter {
            val i = it.ordinal
            // a joystick's big "the whole scene slid" score must not hide a button that scores far less but works:
            // a number going up, or steady clear successes, also makes a family count as working
            famN[i] >= 2 && value(i) >= MIN_VALUE &&
                (value(i) >= floor || famStrong[i] || (famHits[i] >= 3 && famHits[i] >= 0.15f * famN[i]))
        }
    }

    /** True if the game needs more than one kind of input (for example move AND press a skill button). */
    fun isMixed(): Boolean = activeSet().size >= 2

    /** Short status text, for the chip. */
    fun status(nowMs: Long): String {
        if (startMs < 0) return "Learning the game"
        val sec = (activeMs / 1000).toInt()
        if (isProbing(nowMs)) return "Learning the game ${min(sec, (probeLen / 1000).toInt())}s/${(probeLen / 1000).toInt()}s"
        if (moveConfirmed()) {
            // a movement game; other inputs are only named when they work nearly as well as moving
            val dv = value(Family.DRAG.ordinal)
            val extra = activeSet().filter { it != Family.DRAG && value(it.ordinal) >= 0.5f * dv }
            return "Style: " + (listOf(Family.DRAG) + extra).joinToString(" + ") { label(it) }
        }
        val act = activeSet()
        if (act.size >= 2) return "Style: " + act.joinToString(" + ") { label(it) }
        return "Style: ${label(style())}"
    }

    /** What the bot knows about surviving, for the chip and the debug log. */
    fun survivalStatus(): String {
        if (runs == 0) return "no deaths yet"
        return "runs=$runs last=${lastRunMs / 1000}s best=${bestRunMs / 1000}s style=${PROFILES[profile].name}"
    }

    // ------------------------------------------------------------------ survival: learn from every death

    /** Call when a new run begins (the game is live again). Picks the survival style for this run. */
    fun startRun(nowMs: Long) {
        if (runStartMs >= 0) return
        runStartMs = nowMs
        profile = pickProfile()
    }

    /** Call when the character dies. Returns a one-line note for the debug log. */
    fun endRun(nowMs: Long): String {
        if (runStartMs < 0) return ""
        val dur = max(0L, nowMs - runStartMs)
        runStartMs = -1L
        runs++
        lastRunMs = dur
        val wasBest = dur > bestRunMs
        if (wasBest) bestRunMs = dur
        profN[profile]++
        profSum[profile] += dur.toDouble()
        val used = PROFILES[profile].name
        val next = pickProfile()
        return "DEATH #$runs after ${dur / 1000}s with '$used' (best ${bestRunMs / 1000}s${if (wasBest) ", new record" else ""}); next run style '${PROFILES[next].name}'"
    }

    /** Untried styles first, then the one with the longest average life (plus a little curiosity). */
    private fun pickProfile(): Int {
        for (i in PROFILES.indices) if (profN[i] == 0) return i
        var mx = 1.0
        for (i in PROFILES.indices) mx = max(mx, profSum[i] / profN[i])
        val total = profN.sum().toDouble()
        var best = 0
        var bs = -1e9
        for (i in PROFILES.indices) {
            val s = (profSum[i] / profN[i]) / mx + 0.3 * sqrt(ln(max(2.0, total)) / profN[i])
            if (s > bs) {
                bs = s
                best = i
            }
        }
        return best
    }

    /**
     * The screen changed to a new situation after a button was pressed (a popup closed, a new level started).
     * If the game style is still unclear, what was learned so far came from menus and is only half trusted,
     * so learn again for a few seconds. If the style is clear the bot just keeps playing it.
     */
    fun newContext() {
        if (startMs < 0) return
        if (style() != null && confidence() >= 0.5f) return
        if (dragsObserved >= 3) return // movement is the working theory: popups do not restart the learning
        for (i in 0 until 4) {
            famN[i] = famN[i] / 2
            famHits[i] = famHits[i] / 2
            famPeak[i] *= 0.5f
        }
        activeMs = 0L
        probeLen = 12_000L
    }

    /** One line for the debug log. */
    fun describe(): String =
        "style=${label(style())} conf=${"%.2f".format(confidence())} base=${"%.3f".format(baseline)} " +
            Family.values().joinToString(" ") { "${it.name.lowercase()}=${"%.2f".format(value(it.ordinal))}(${famN[it.ordinal]})" } +
            " mixed=${isMixed()} | ${survivalStatus()}"

    // ------------------------------------------------------------------ learning from results

    /**
     * Call once per step, BEFORE next(): scores the move made last time by what the screen did afterwards.
     * [change] is how much the screen changed since the previous step, [motion] how it moved,
     * [scoreUp] whether an on-screen number went up.
     */
    fun observe(change: Float?, motion: MotionInfo?, scoreUp: Boolean) {
        val m = lastMove ?: return
        lastMove = null
        if (change == null) return
        if (m is Move.Idle) {
            // two frames with no input between them: a clean measure of how much the game moves by itself
            idleObs++
            if (scoreUp) idleUps++
            baseline = if (idleObs == 1) change.coerceIn(0f, 0.6f) else 0.6f * baseline + 0.4f * change.coerceIn(0f, 0.6f)
            return
        }
        if (change < baseline) baseline = 0.8f * baseline + 0.2f * change // quieter than thought: learn it
        val fam = lastFam ?: return
        // A score that also goes up after OTHER kinds of move is counting by itself (auto-attack kills, points per
        // second): that says nothing about which input works. It only counts for a family when that family makes it
        // go up clearly more often than the rest of the moves do.
        if (scoreUp) famUp[fam.ordinal]++
        val up = scoreUp && upAttributable(fam.ordinal)
        val over = max(0f, change - baseline)
        var lift = min(over, 0.5f) + (if (up) 0.5f else 0f)
        if (fam == Family.DRAG) {
            val coh = motion?.coherence ?: 0f
            val mag = min(1f, (motion?.magnitude ?: 0f) / 3f)
            lift += coh * mag
            // The scene slid as one piece, OR the picture changed clearly more than it does by itself (a camera that
            // follows the player over a busy floor does not always look like a clean slide).
            val slide = motion?.magnitude ?: 0f
            val engagedNow = (coh >= 0.3f && slide >= 1f) || (coh >= 0.2f && slide >= 2f) || (over >= 0.06f && over >= 2.5f * baseline)
            dragEngaged.add(engagedNow)
            if (dragEngaged.size > 8) dragEngaged.removeAt(0)
            if (engagedNow) missStreak = 0 else missStreak++
            // A running game (camera follows the player) where a whole push moved nothing at all: the character is stuck
            // against a wall, a rock or the edge of the map. Two in a row = turn away from that way.
            val stalledNow = live && movementLatched && !engagedNow && change < 0.011f && coh < 0.15f && slide < 1f
            stallStreak = if (stalledNow) stallStreak + 1 else 0
            if (dragEngaged.count { it } >= 2) movementLatched = true else if (movementLatched && missStreak >= 24) movementLatched = false
            dragsObserved++
        }
        val i = fam.ordinal
        famV[i] = if (famN[i] == 0) lift else 0.7f * famV[i] + 0.3f * lift
        famPeak[i] = max(lift, famPeak[i] * 0.97f)
        if (lift > 0.1f) famHits[i]++
        if (up) famStrong[i] = true
        famN[i]++
        if (fam == Family.DRAG && lastAnchor >= 0) {
            anchorV[lastAnchor] = if (anchorN[lastAnchor] == 0) lift else 0.6f * anchorV[lastAnchor] + 0.4f * lift
            anchorN[lastAnchor]++
            lastDragLift = lift
        }
        if (fam == Family.SWIPE && lastSwipeDir >= 0) {
            swipeV[lastSwipeDir] = if (swipeN[lastSwipeDir] == 0) lift else 0.6f * swipeV[lastSwipeDir] + 0.4f * lift
            swipeN[lastSwipeDir]++
        }
        // a drag that moved nothing at a spot that used to work is a wall
        if (fam != Family.DRAG) lastDragLift = 1f
    }

    /**
     * Did this family make the score go up, or does the score just go up by itself (auto-attack kills, points per
     * second)? The score's "background rate" is the LOWEST up-rate among the other kinds of move: if even a move
     * that does nothing useful sees the score rise that often, the rise says nothing about this family.
     */
    private fun upAttributable(i: Int): Boolean {
        if (famUp[i] < 2) return false
        var background = -1f
        for (k in 0 until 4) {
            if (k == i || famN[k] < 3) continue
            val r = famUp[k].toFloat() / famN[k]
            if (background < 0f || r < background) background = r
        }
        if (background < 0f) return idleObs >= 3 && idleUps == 0 // nothing to compare with yet: use the idle looks
        if (idleUps > 0) background = max(background, idleUps.toFloat() / max(1, idleObs))
        return famUp[i].toFloat() / (famN[i] + 1) - background >= 0.3f
    }

    // ------------------------------------------------------------------ choosing the next move

    /**
     * @param aspect screen height / width (for round joystick circles)
     * @param free   true if a point is OK to touch (not near a buy button, not our own chip)
     */
    fun next(nowMs: Long, aspect: Float, free: (Float, Float) -> Boolean, motion: MotionInfo?): Move {
        if (startMs < 0) startMs = nowMs
        // only count time the bot is really playing (calls close together), not time spent on menus and popups
        if (lastNextMs >= 0 && nowMs - lastNextMs < 4000L) activeMs += nowMs - lastNextMs
        lastNextMs = nowMs
        moves++

        if (idleSeen < 2) {
            idleSeen++
            return remember(Move.Idle(350L, "Learning the game: watching the screen first"), null)
        }

        var fam = chooseFamily(nowMs)
        val tag = status(nowMs)

        // Mixed game (move AND press): most presses go out as a second finger while the joystick is held,
        // so the bot moves and attacks at the same time. Every 3rd press is a plain tap, which keeps
        // measuring whether pressing still works.
        var combo = false
        if (fam == Family.TAP && !isProbing(nowMs)) {
            val act = activeSet()
            if (Family.TAP in act && Family.DRAG in act && famN[Family.DRAG.ordinal] >= (MIN_TRIES[Family.DRAG] ?: 6)) {
                tapPicks++
                if (tapPicks % 3 != 0) {
                    fam = Family.DRAG
                    combo = true
                }
            }
        }
        val move: Move = when (fam) {
            Family.TAP -> Move.Tap
            Family.DRAG -> planDrag(tag, aspect, free, motion, combo)
            Family.SWIPE -> planSwipe(tag, free)
            Family.HOLD -> planHold(tag, free)
        }
        return remember(move, if (move is Move.Idle) null else fam)
    }

    private fun remember(m: Move, fam: Family?): Move {
        lastMove = m
        lastFam = fam
        lastWasDrag = m is Move.Drag
        return m
    }

    private fun bestFamily(): Family? = style()

    private fun chooseFamily(nowMs: Long): Family {
        // 1) Movement first: try the joystick at the usual spots before anything else.
        if (!moveConfirmed() && dragsObserved < 12 && moves > 2) return Family.DRAG

        // 2) A confirmed movement game keeps moving. Now and then (4%) another input is re-checked, unless one of
        //    them is clearly working far better than moving.
        if (moveConfirmed()) {
            val dv = value(Family.DRAG.ordinal)
            val rival = ORDER.filter { it != Family.DRAG && famN[it.ordinal] >= 3 && value(it.ordinal) > 2.5f * max(dv, 0.2f) }
            if (rival.isNotEmpty()) return rival.maxByOrNull { value(it.ordinal) }!!
            val roll = rnd.nextFloat()
            // Is there a button that matters? Checked with plain taps, but less and less often the more of them showed
            // nothing: a movement game does not need its screen poked all the time.
            val explore = max(0.012f, 0.045f / (1f + famN[Family.TAP.ordinal] / 4f))
            if (roll < explore) return Family.TAP
            if (roll < explore + 0.005f) return Family.SWIPE
            val act = activeSet()
            if (Family.TAP in act && rnd.nextFloat() < 0.25f) return Family.TAP // a proven button: pressed as a 2nd finger
            return Family.DRAG
        }
        if (isProbing(nowMs)) {
            var pick: Family? = null
            var worst = 1f
            for (f in ORDER) {
                val need = MIN_TRIES[f] ?: 2
                val ratio = famN[f.ordinal].toFloat() / need
                if (ratio < worst) {
                    worst = ratio
                    pick = f
                }
            }
            if (pick != null) return pick
            return bestFamily() ?: ORDER[moves % ORDER.size]
        }
        val act = activeSet()
        if (act.isEmpty()) {
            // Nothing has clearly worked. A game that keeps moving by itself is an action game, where random taps
            // rarely matter and moving does: lean on the joystick instead of cycling through everything.
            if ((baseline >= 0.012f || live) && rnd.nextFloat() < 0.7f) return Family.DRAG
            return ORDER[moves % ORDER.size]
        }

        // now and then try something that is NOT working (the game may change), the least tried first
        if (rnd.nextFloat() < EXPLORE) {
            val others = ORDER.filter { it !in act }
            if (others.isNotEmpty()) return others.minByOrNull { famN[it.ordinal] }!!
        }
        if (act.size == 1) return act[0]

        // mixed game: every working family stays in the game, in proportion to how well it works
        var total = 0f
        for (f in act) total += max(0.05f, value(f.ordinal))
        var roll = rnd.nextFloat() * total
        for (f in act) {
            roll -= max(0.05f, value(f.ordinal))
            if (roll <= 0f) return f
        }
        return act.last()
    }

    // ------------------------------------------------------------------ joystick

    private fun planDrag(tag: String, aspect: Float, free: (Float, Float) -> Boolean, motion: MotionInfo?, combo: Boolean = false): Move {
        totalDrags++
        val prof = PROFILES[profile]
        // 1) where to put the finger down
        var anchor = -1
        val untried = (0 until ANCHORS.size).filter { anchorN[it] == 0 }
        val firstUntried = untried.firstOrNull { free(ANCHORS[it].first, ANCHORS[it].second) }
        if (firstUntried != null && totalDrags <= ANCHORS.size + 1 && !moveConfirmed()) {
            anchor = firstUntried
        } else if (lastAnchor >= 0 && lastDragLift >= 0.35f && free(ANCHORS[lastAnchor].first, ANCHORS[lastAnchor].second)) {
            anchor = lastAnchor // it works, stay with it
        } else {
            var bs = -1e9f
            val total = max(2, anchorN.sum())
            for (i in ANCHORS.indices) {
                if (!free(ANCHORS[i].first, ANCHORS[i].second)) continue
                val s = anchorV[i] + 0.25f * sqrt(ln(total.toFloat()) / (anchorN[i] + 1)) + rnd.nextFloat() * 0.02f
                if (s > bs) {
                    bs = s
                    anchor = i
                }
            }
        }
        if (anchor < 0) return Move.Idle(600L, "$tag: no safe place to put a finger, waiting")

        // 2) which way to push
        var kiteTag = ""
        val probingPass = totalDrags <= ANCHORS.size && !moveConfirmed()
        if (probingPass) {
            heading = 0.0 // first pass: every spot is tested with the same push to the right
        } else {
            val stuckAgainstSomething = stallStreak >= 2
            val wall = (lastWasDrag && lastDragLift < 0.2f && anchorV[anchor] > 0.3f) || stuckAgainstSomething
            val flee = fleeAngle(motion)
            val hurting = hurtMoves > 0
            if (hurting) hurtMoves--
            if (stuckAgainstSomething) {
                avoidHeading = heading
                avoidMoves = 8
                stallStreak = 0
                hazardNote = "STUCK: pushing ${COMPASS[((heading / (PI / 4)).roundToInt() % 8 + 8) % 8]} moved nothing, turning away and not going that way for a few moves"
            }
            // enemies found on the screen: go where it is survivable (see Kiter)
            val th = threats
            val kite = if (th != null && moveConfirmed()) Kiter.plan(th, hazards, heading, hpFrac, hurting) else null
            val kiteAct = kite != null && !kite.calm
            if (kiteAct) {
                kiteActs++
                kiteTag = " [enemies: running away]"
                if (kiteActs <= 3 || kiteActs % 6 == 0) hazardNote = "KITE #$kiteActs: ${kite!!.note}"
            }
            heading = when {
                wall -> heading + PI * (0.55 + rnd.nextDouble() * 0.45) * (if (rnd.nextBoolean()) 1 else -1)
                kiteAct -> kite!!.heading
                // losing health but no enemy seen by colour: run from what moves, or at least change direction
                hurting && kite == null && flee != null -> blendAngle(heading, flee, 1.0)
                hurting && kite == null && turnPending -> heading + PI * (0.6 + rnd.nextDouble() * 0.4) * (if (rnd.nextBoolean()) 1 else -1)
                // quiet: lean toward the nearest gem
                kite != null -> blendAngle(heading, kite.heading, 0.7)
                // the old guess from where things moved is only used when the screen could not be scanned
                th == null && flee != null -> blendAngle(heading, flee, prof.flee)
                else -> heading + (rnd.nextDouble() - 0.5) * prof.wander
            }
            if (hurting) turnPending = false
            // do not walk back into the thing that blocked us a moment ago
            if (avoidMoves > 0) {
                avoidMoves--
                if (Hazards.angDiff(heading, avoidHeading) < PI / 3) {
                    heading = avoidHeading + (if (normalize(heading - avoidHeading) >= 0) 1 else -1) * (PI / 3 + 0.2)
                }
            }
        }
        heading = normalize(heading)

        // lava and thorn walls: the last word on the heading. Only in a game where the camera follows the character
        // (then the character is in the middle of the picture, which is where the hazards are measured from).
        var hazardTag = ""
        val hz = hazards
        if (hz != null && moveConfirmed() && !probingPass) {
            val steered = Hazards.steer(heading, hz)
            if (Hazards.angDiff(steered, heading) > 1e-6) {
                hazardTag = " [" + Hazards.whatIsAhead(hz, heading) + ": turning]"
                heading = normalize(steered)
                hazardTurns++
                if (hazardTurns <= 3 || hazardTurns % 6 == 0) hazardNote = "HAZARD #$hazardTurns: ${Hazards.whatIsAhead(hz, heading)} -> ${hz.describe()}"
            }
        }

        // 3) find a direction whose end point is also safe
        val ax = ANCHORS[anchor].first
        val ay = ANCHORS[anchor].second
        var h = heading
        var tx = 0f
        var ty = 0f
        var ok = false
        val baseDanger = if (hz != null && moveConfirmed()) Hazards.dangerAt(hz, h) else 0f
        for (attempt in 0 until 7) {
            tx = (ax + prof.radius * cos(h)).toFloat().coerceIn(0.03f, 0.97f)
            ty = (ay + prof.radius * sin(h) / aspect).toFloat().coerceIn(0.03f, 0.97f)
            // a turn made only because the end point touches a button must not rotate the push INTO a hazard
            // (but when every way is dangerous, or the character stands in lava, the steering already picked the best one)
            val dangerous = hz != null && moveConfirmed() && attempt < 5 && !hz.onLava && baseDanger < 0.6f &&
                Hazards.dangerAt(hz, h) >= 0.6f
            if (!dangerous && free(tx, ty) && free((ax + tx) / 2f, (ay + ty) / 2f)) {
                ok = true
                break
            }
            h = normalize(h + PI / 3)
        }
        if (!ok) return Move.Idle(500L, "$tag: the joystick path is blocked, waiting")
        heading = h
        lastAnchor = anchor
        val dir = COMPASS[((h / (PI / 4)).roundToInt() % 8 + 8) % 8]
        val why = "$tag: push joystick $dir (${(ax * 100).toInt()}%,${(ay * 100).toInt()}%)$kiteTag$hazardTag"
        return Move.Drag(ax, ay, tx, ty, 1200L, why, combo)
    }

    /**
     * Where to run. Things that move on their own (enemies) show up as leftover motion per screen sector. Two ideas:
     *  - they are mostly on ONE side: run to the opposite side;
     *  - they are all around us (a swarm): run through the quietest GAP, the side with the least leftover motion.
     * Returns null when nothing stands out (then the heading just keeps going with small turns).
     */
    private fun fleeAngle(motion: MotionInfo?): Double? {
        val r = motion?.residual ?: return null
        var vx = 0.0
        var vy = 0.0
        var sum = 0.0
        for (k in 0 until 9) {
            if (k == 4) continue // the middle holds our own character
            val ox = (k % 3) - 1
            val oy = (k / 3) - 1
            vx += r[k] * ox
            vy += r[k] * oy
            sum += r[k]
        }
        if (sum < 0.03) return null
        val strength = sqrt(vx * vx + vy * vy) / sum
        if (strength >= 0.35) return atan2(-vy, -vx)

        // all around us: the ring of 8 sectors in order, each judged with its two neighbours
        val ring = intArrayOf(0, 1, 2, 5, 8, 7, 6, 3)
        var bestAngle = 0.0
        var bestDanger = Double.MAX_VALUE
        var total = 0.0
        for (i in 0 until 8) {
            val prev = ring[(i + 7) % 8]
            val next = ring[(i + 1) % 8]
            val d = r[ring[i]] + 0.5 * (r[prev] + r[next])
            total += d
            if (d < bestDanger) {
                bestDanger = d
                val ox = (ring[i] % 3) - 1
                val oy = (ring[i] / 3) - 1
                bestAngle = atan2(oy.toDouble(), ox.toDouble())
            }
        }
        val mean = total / 8
        // a gap that is clearly quieter than the rest
        return if (bestDanger <= 0.7 * mean) bestAngle else null
    }

    private fun normalize(a: Double): Double {
        var x = a
        while (x > PI) x -= 2 * PI
        while (x < -PI) x += 2 * PI
        return x
    }

    private fun blendAngle(from: Double, to: Double, k: Double): Double = normalize(from + normalize(to - from) * k)

    // ------------------------------------------------------------------ swipe and hold

    private fun planSwipe(tag: String, free: (Float, Float) -> Boolean): Move {
        // 0 left, 1 up, 2 right, 3 down
        var dir: Int = swipeN.indices.firstOrNull { swipeN[it] == 0 } ?: -1
        if (dir < 0) {
            var total = 0f
            val w = FloatArray(4) { max(0.03f, swipeV[it]) + 0.04f }
            for (x in w) total += x
            var roll = rnd.nextFloat() * total
            dir = 3
            for (i in 0 until 4) {
                roll -= w[i]
                if (roll <= 0f) {
                    dir = i
                    break
                }
            }
        }
        lastSwipeDir = dir
        val names = arrayOf("left", "up", "right", "down")
        val cx = 0.5f
        val cy = 0.55f
        val (x1, y1, x2, y2) = when (dir) {
            0 -> listOf(0.78f, cy, 0.22f, cy)
            1 -> listOf(cx, 0.80f, cx, 0.32f)
            2 -> listOf(0.22f, cy, 0.78f, cy)
            else -> listOf(cx, 0.32f, cx, 0.80f)
        }
        if (!free(x1, y1) || !free(x2, y2)) return Move.Idle(400L, "$tag: swipe path is blocked, waiting")
        return Move.Swipe(x1, y1, x2, y2, 220L, "$tag: swipe ${names[dir]}")
    }

    private fun planHold(tag: String, free: (Float, Float) -> Boolean): Move {
        for (attempt in 0 until 6) {
            val x = 0.5f + (rnd.nextFloat() - 0.5f) * 0.5f
            val y = 0.6f + (rnd.nextFloat() - 0.5f) * 0.4f
            if (free(x, y)) return Move.Hold(x, y, 900L, "$tag: press and hold")
        }
        return Move.Idle(400L, "$tag: nowhere safe to hold, waiting")
    }
}
