package com.zirexhub.autoplayer

import kotlin.math.abs

/**
 * Everything the AI mode remembers about a board game (pure Kotlin, no Android, so it is tested on a PC).
 *
 * Found in real chess logs: (1) the app counted a drag that only SELECTED a piece as a move that worked, so the AI "played" the
 * same move again and again; (2) the board finder lost a row (the bot's own chip covered it) and the next time found the board
 * again, so the cell numbers changed between questions; (3) nothing told the AI which moves were already played.
 *
 *  - [moveFrom] recognises a move (two exact cell taps, or one drag from a cell to a cell) and [judge] checks it later against the
 *    screen with [BoardCheck]; the moves that happened go into [moveLog], the ones that did not into [notes];
 *  - the same move failing twice is [blocked]; two failed moves in a row with a way of moving that never worked switch between
 *    "tap, tap" and "drag" ([dragAsTaps]);
 *  - [gridFor] keeps the board of a still screen, so a miss of the finder does not change the numbers.
 */
class BoardTracker(private val clock: () -> Long, private val log: (String) -> Unit = {}) {

    class Move(
        val key: String,
        val c1: Int, val r1: Int, val c2: Int, val r2: Int,
        val grid: Grid,
        val before: Gray,
        val byTaps: Boolean,
        val at: Long,
    ) {
        val text: String get() = "move $c1,$r1 to $c2,$r2"
    }

    /** True: a move is two taps (the default, worked in a real chess app). False: a drag. */
    var dragAsTaps: Boolean = true
        private set

    private var pending: Move? = null
    private val log8 = ArrayList<String>()
    private val noteList = ArrayList<String>()
    private val failCount = HashMap<String, Int>()
    private var tapsWork = false
    private var dragsWork = false
    private var tapFails = 0
    private var dragFails = 0

    private var memory: Grid? = null
    private var memoryThumb: IntArray? = null
    private var memoryAt = Long.MIN_VALUE / 2
    private var otherShape = 0

    /** The moves played so far, oldest first, as sentences for the AI. */
    val moveLog: List<String> get() = log8.toList()

    /** Why moves did not happen, as sentences for the AI ("do not repeat"). */
    val notes: List<String> get() = noteList.toList()

    val hasPending: Boolean get() = pending != null

    /** A new game or a screen without a board: forget the moves. */
    fun newGame() {
        log8.clear()
        noteList.clear()
        failCount.clear()
        pending = null
    }

    /** A cell for people and the AI: "col 5,row 7 (e2 if white is at the bottom)". */
    fun cellText(g: Grid, c: Int, r: Int): String =
        if (g.cols == 8 && g.rows == 8) "col $c,row $r (${g.chessName(c, r)} if white is at the bottom)" else "col $c,row $r"

    // ---- the board of this screenshot

    /**
     * [found] = what the finder saw (null = nothing), [thumb] = a small picture of this screen. The finder can miss a board once
     * (a piece animation, an edge of a popup): while the screen is still the one of the last sighting the board found before is
     * used. A board of another shape (8x8 then 8x7) must be seen twice in a row to replace the old one: a wrong grid sends
     * every tap to the wrong square.
     */
    fun gridFor(found: Grid?, thumb: IntArray): Grid? {
        val mem = memory
        val memThumb = memoryThumb
        val fresh = mem != null && memThumb != null && clock() - memoryAt < MEMORY_MS && thumbDiff(memThumb, thumb) < SAME_SCREEN
        if (found != null) {
            if (fresh && mem != null && (found.cols != mem.cols || found.rows != mem.rows) && ++otherShape < 2) {
                log("a board of another shape ($found) was seen once: keeping the earlier $mem")
                return mem
            }
            otherShape = 0
            memory = found
            memoryThumb = thumb
            memoryAt = clock()
            return found
        }
        if (fresh) {
            log("no board found this time: using the earlier $mem")
            return mem
        }
        memory = null
        return null
    }

    // ---- moves

    /** The board move in these actions, if they are one: two exact cell taps, or one drag from a cell to a cell. */
    fun moveFrom(acts: List<GameAction>, grid: Grid?, before: Gray?): Move? {
        if (grid == null || before == null) return null
        val t1 = acts.getOrNull(0)
        val t2 = acts.getOrNull(1)
        val x1: Float
        val y1: Float
        val x2: Float
        val y2: Float
        val byTaps: Boolean
        if (t1 is GameAction.Tap && t2 is GameAction.Tap && t1.exact && t2.exact) {
            x1 = t1.x; y1 = t1.y; x2 = t2.x; y2 = t2.y
            byTaps = true
        } else if (t1 is GameAction.Swipe) {
            x1 = t1.x1; y1 = t1.y1; x2 = t1.x2; y2 = t1.y2
            byTaps = false
        } else {
            return null
        }
        val c1 = grid.colAt(x1)
        val r1 = grid.rowAt(y1)
        val c2 = grid.colAt(x2)
        val r2 = grid.rowAt(y2)
        if (c1 == 0 || r1 == 0 || c2 == 0 || r2 == 0 || (c1 == c2 && r1 == r2)) return null
        return Move("move $c1,$r1>$c2,$r2", c1, r1, c2, r2, grid, before, byTaps, clock())
    }

    /** The same move already failed twice since the last move that worked: do not play it a third time. */
    fun blocked(m: Move): Boolean = (failCount[m.key] ?: 0) >= 2

    /** The move went out: judge it with [judge] once the opponent has had time to answer. */
    fun begin(m: Move) {
        pending = m
    }

    /** The press was refused (it would have hit the bot's own chip): it never happened. */
    fun cancel() {
        pending = null
    }

    /** Time to judge the move: the screen has settled ([settled]), or it has been too long. */
    fun due(settled: Boolean): Boolean {
        val p = pending ?: return false
        return settled || clock() - p.at >= PENDING_MAX_MS
    }

    /**
     * Judges the pending move against [now] (the board picture after it). [screenChange] = how much the whole screen changed
     * since the question (0..1): a new screen (game over, a menu) is not judged. Null when nothing was judged.
     */
    fun judge(now: Gray, screenChange: Float): BoardCheck.Result? {
        val p = pending ?: return null
        pending = null
        if (screenChange > SCREEN_REPLACED) {
            log("board move check skipped: the whole screen changed (a new screen)")
            return null
        }
        val from = cellText(p.grid, p.c1, p.r1)
        val to = cellText(p.grid, p.c2, p.r2)
        val how = if (p.byTaps) "taps" else "drag"
        val result = BoardCheck.verdict(p.before, now, p.grid, p.c1, p.r1, p.c2, p.r2)
        when (result) {
            BoardCheck.Result.MOVED -> {
                // the position changed: a move that failed before may be playable now, and the old notes are out of date
                failCount.clear()
                noteList.clear()
                if (p.byTaps) {
                    tapsWork = true
                    tapFails = 0
                } else {
                    dragsWork = true
                    dragFails = 0
                }
                if (log8.size >= MOVE_LOG_MAX) log8.removeAt(0)
                log8.add("your move from $from to $to was played")
                log("board move check: MOVED $from -> $to (by $how)")
            }
            BoardCheck.Result.SELECTED_ONLY -> failed(p, "the piece on $from was only selected, it did NOT move to $to (an illegal target, not your turn, or the wrong cell?)")
            BoardCheck.Result.NOTHING -> failed(p, "nothing changed on the board after your press ($from to $to)")
        }
        return result
    }

    private fun failed(p: Move, why: String) {
        val n = (failCount[p.key] ?: 0) + 1
        failCount[p.key] = n
        if (noteList.size >= NOTES_MAX) noteList.removeAt(0)
        noteList.add(why)
        log("board move check: NOT moved (#$n, ${if (p.byTaps) "taps" else "drag"}): $why")
        // Never worked this way and failed twice: try the other way of moving a piece (some apps want a drag, most want two taps)
        if (p.byTaps) {
            if (!tapsWork && ++tapFails >= 2 && dragAsTaps && !dragsWork) {
                dragAsTaps = false
                tapFails = 0
                log("two moves by taps did not move a piece: moving pieces by dragging now")
            }
        } else {
            if (!dragsWork && ++dragFails >= 2 && !dragAsTaps && !tapsWork) {
                dragAsTaps = true
                dragFails = 0
                log("two moves by dragging did not move a piece: moving pieces by two taps now")
            }
        }
    }

    private fun thumbDiff(a: IntArray, b: IntArray): Float {
        if (a.size != b.size || a.isEmpty()) return 1f
        var s = 0L
        for (i in a.indices) s += abs(a[i] - b[i])
        return s.toFloat() / a.size / 255f
    }

    companion object {
        const val MEMORY_MS = 25_000L
        const val PENDING_MAX_MS = 9_000L
        const val SCREEN_REPLACED = 0.25f
        const val SAME_SCREEN = 0.2f
        const val MOVE_LOG_MAX = 8
        const val NOTES_MAX = 4
    }
}
