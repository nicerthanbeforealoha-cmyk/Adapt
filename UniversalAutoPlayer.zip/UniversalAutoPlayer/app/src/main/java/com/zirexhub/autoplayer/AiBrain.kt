package com.zirexhub.autoplayer

import android.graphics.Bitmap
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Wrong / rejected API key. The agent stops and tells the user. */
class AuthException(message: String) : Exception(message)

/** A setup problem retrying will not fix (bad model name, bad URL, no credit, no image support). */
open class FatalConfigException(message: String) : Exception(message)

/** The model name is wrong, retired or renamed. The app can often fix this by itself (see [AiBrain.heal]). */
class ModelProblemException(message: String) : FatalConfigException(message)

/** Temporary problem (server busy, bad reply). The agent waits and retries. */
open class ApiException(val code: Int, message: String) : IOException(message)

/**
 * "Too many requests" (HTTP 429). [info] says whether it is the per-minute kind (space the calls out), the per-day kind
 * (AI calls are over for today) or "no quota for this model". The [HybridBrain] handles it; the offline bot plays meanwhile.
 */
class RateLimitException(val info: LimitInfo, message: String) : ApiException(429, message)

private fun withHint(code: Int, msg: String): String {
    val hint = ApiErrors.hint(code, msg)
    return if (hint.isBlank()) "HTTP $code: $msg" else "HTTP $code: $msg\n=> $hint"
}

/** [raw] = the whole error body, when there is one (the 429 details are read from it). */
fun classifyHttpError(code: Int, msg: String, raw: String = ""): Exception {
    val low = msg.lowercase()
    return when {
        code == 429 -> RateLimitException(ApiErrors.limit(if (raw.isNotBlank()) raw else msg), withHint(429, raw.ifBlank { msg }))
        code == 401 || code == 403 -> AuthException(withHint(code, msg))
        code == 400 && ("api key" in low || "api_key" in low) -> AuthException(withHint(400, msg))
        code == 400 && "location is not supported" in low -> FatalConfigException(withHint(400, msg))
        code == 402 -> FatalConfigException("Payment or credit problem: $msg")
        code == 404 -> ModelProblemException("Not found (404). Check the model name and base URL. $msg")
        code == 400 && ("image" in low || "vision" in low || "multimodal" in low || "modalit" in low) ->
            FatalConfigException("This model may not accept images: $msg")
        code == 400 && "model" in low ->
            ModelProblemException("Model name problem (use the model ID, e.g. gemini-3.5-flash-lite): $msg")
        else -> ApiException(code, withHint(code, msg))
    }
}

/**
 * The AI player. Works with Google Gemini, Anthropic Claude, OpenAI and anything OpenAI-compatible
 * (OpenRouter, Groq, Mistral, Ollama...). Each step it sends the screenshot plus the recent history and
 * gets back one or several actions as JSON. Because it re-reads the screen every call it adapts to any game.
 */
class AiBrain(private val cfg: Config) : Brain {

    val config: Config get() = cfg

    class Config(
        val provider: Provider,
        val apiKey: String,
        val model: String,
        val baseUrl: String,
    )

    override fun decide(frame: Bitmap, ctx: AgentContext): Decision {
        val img = FrameTools.encode(frame, 1024, 68)
        val reply = chat(
            Prompts.system(ctx.maxActions),
            Prompts.user(ctx, img.width, img.height),
            img.base64,
        )
        return ActionParser.parse(reply, img.width, img.height, ctx.maxActions)
    }

    /** Tiny text-only request used by the "Test connection" button. */
    fun ping(): String = chat("You are a connection test.", "Reply with the single word OK.", null)

    /**
     * Like [ping] but with a small picture, because the bot always sends a picture: it checks the key, the model AND that the
     * model accepts images with one single call (free keys have few calls per day).
     */
    fun pingWithImage(): String = chat("You are a connection test.", "A picture is attached. Reply with the single word OK.", TINY_JPEG)

    private fun chat(system: String, user: String, imageB64: String?): String {
        if (cfg.model.isBlank() || cfg.model.any { it.isWhitespace() }) {
            throw ModelProblemException(
                "The model name \"${cfg.model}\" is empty or has spaces. That is a display name, not a model ID. " +
                    "Use \"Pick model from list\" or type an ID like gemini-3.5-flash-lite.",
            )
        }
        val req = Requests.build(cfg.provider, cfg.baseUrl, cfg.apiKey, cfg.model, system, user, imageB64)
        return Requests.extractText(cfg.provider.protocol, Http.send(req))
    }

    companion object {
        /** A 32x32 red picture with a white square, JPEG, base64. */
        private const val TINY_JPEG = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAA0JCgsKCA0LCgsODg0PEyAVExISEyccHhcgLikxMC4pLSwzOko+MzZGNywtQFdBRkxOUlNSMj5aYVpQYEpRUk//2wBDAQ4ODhMREyYVFSZPNS01T09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0//wAARCAAgACADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDGoor16uOEOc+ixWK+r20vc8hor16vIaJw5AwuK+sX0tYK9eryGiiE+QMVhfrFtbWPXq8hooonPnDC4X6vfW9z/9k="

        /** Asks the provider which models this key can use. */
        fun listModels(cfg: Config): List<String> {
            val req = Requests.modelsRequest(cfg.provider, cfg.baseUrl, cfg.apiKey)
            return Requests.parseModels(cfg.provider.protocol, Http.send(req))
        }

        /**
         * Fixes a retired / renamed / mistyped model: lists the models of this account, tries the best
         * matches of the same family (newest first) with a tiny test question, and returns the first that
         * answers, or null if none does. [errorText] is the provider's complaint, it often names the new model.
         */
        fun heal(cfg: Config, errorText: String): String? {
            val available = listModels(cfg)
            if (available.isEmpty()) return null
            val reference = cfg.model.ifBlank { cfg.provider.defaultModel }
            val candidates = ModelHealer.rank(reference, available, errorText)
            for (id in candidates.take(4)) {
                try {
                    AiBrain(Config(cfg.provider, cfg.apiKey, id, cfg.baseUrl)).ping()
                    return id
                } catch (e: AuthException) {
                    throw e
                } catch (_: Exception) {
                    // this one does not answer either, try the next best
                }
            }
            return null
        }
    }
}

/** Minimal HTTP client. Throws the typed errors above for non-2xx replies. */
object Http {
    fun send(req: BuiltRequest): String {
        val conn = URL(req.url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = req.method
            conn.connectTimeout = 15_000
            conn.readTimeout = 90_000
            for ((k, v) in req.headers) conn.setRequestProperty(k, v)
            if (req.method != "GET") {
                conn.doOutput = true
                conn.outputStream.use { it.write(req.body.toByteArray(Charsets.UTF_8)) }
            }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code in 200..299) return text
            // some providers send the wait only in the Retry-After header: hand it over as text the parser understands
            val wait = conn.getHeaderField("Retry-After")?.trim()?.toDoubleOrNull()
            throw classifyHttpError(code, Requests.errorMessage(text), if (wait != null && code == 429) "$text retry in ${wait}s" else text)
        } finally {
            conn.disconnect()
        }
    }
}
