package com.zirexhub.autoplayer

import android.graphics.Bitmap
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Wrong / rejected API key. The agent stops and tells the user. */
class AuthException(message: String) : Exception(message)

/** A setup problem retrying will not fix (bad model name, bad URL, no credit, no image support). */
class FatalConfigException(message: String) : Exception(message)

/** Temporary problem (rate limit, server busy, bad reply). The agent waits and retries. */
class ApiException(val code: Int, message: String) : IOException(message)

fun classifyHttpError(code: Int, msg: String): Exception {
    val low = msg.lowercase()
    return when {
        code == 401 || code == 403 -> AuthException("HTTP $code: $msg")
        code == 400 && ("api key" in low || "api_key" in low) -> AuthException("HTTP 400: $msg")
        code == 402 -> FatalConfigException("Payment or credit problem: $msg")
        code == 404 -> FatalConfigException("Not found (404). Check the model name and base URL. $msg")
        code == 400 && ("image" in low || "vision" in low || "multimodal" in low || "modalit" in low) ->
            FatalConfigException("This model may not accept images: $msg")
        else -> ApiException(code, "HTTP $code: $msg")
    }
}

/**
 * The AI player. Works with Google Gemini, Anthropic Claude, OpenAI and anything OpenAI-compatible
 * (OpenRouter, Groq, Mistral, Ollama...). Each step it sends the screenshot plus the recent history and
 * gets back one or several actions as JSON. Because it re-reads the screen every call it adapts to any game.
 */
class AiBrain(private val cfg: Config) : Brain {

    class Config(
        val provider: Provider,
        val apiKey: String,
        val model: String,
        val baseUrl: String,
    )

    override fun decide(frame: Bitmap, ctx: AgentContext): Decision {
        val img = FrameTools.encode(frame, 1024, 68)
        val reply = chat(
            Prompts.system(ctx.maxActions),
            Prompts.user(ctx, img.width, img.height),
            img.base64,
        )
        return ActionParser.parse(reply, img.width, img.height, ctx.maxActions)
    }

    /** Tiny text-only request used by the "Test connection" button. */
    fun ping(): String = chat("You are a connection test.", "Reply with the single word OK.", null)

    private fun chat(system: String, user: String, imageB64: String?): String {
        val req = Requests.build(cfg.provider, cfg.baseUrl, cfg.apiKey, cfg.model, system, user, imageB64)
        return Requests.extractText(cfg.provider.protocol, post(req))
    }

    private fun post(req: BuiltRequest): String {
        val conn = URL(req.url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 90_000
            conn.doOutput = true
            for ((k, v) in req.headers) conn.setRequestProperty(k, v)
            conn.outputStream.use { it.write(req.body.toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code in 200..299) return text
            throw classifyHttpError(code, Requests.errorMessage(text))
        } finally {
            conn.disconnect()
        }
    }
}
