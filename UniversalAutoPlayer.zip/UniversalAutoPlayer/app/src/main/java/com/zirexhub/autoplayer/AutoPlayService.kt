package com.zirexhub.autoplayer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * The heart of the app. As an accessibility service it can
 *  - take screenshots of whatever app is in front (API 30+),
 *  - inject taps / swipes (dispatchGesture),
 *  - show a small floating PLAY/STOP chip on top of any game.
 * When you press PLAY it runs the loop: screenshot -> brain decides -> perform gestures -> repeat.
 *
 * The loop only stops when YOU press STOP, the API key is rejected, or the setup is wrong.
 * Loading screens, frozen screens, network hiccups, screenshot errors and even crashes inside a step
 * never stop it. Everything that matters is written to the debug log.
 *
 * SELF-TAP PROTECTION (v2.2). The bot must never press its own chip. Four independent layers:
 *  1. The chip is located in the screenshot itself by its button colours (ChipLocator), plus where
 *     Android says it is. Both places are painted over before the screen is read.
 *  2. Both places are handed to the brain as no-tap zones (with a safety margin).
 *  3. perform() REFUSES any gesture that would land near the chip, and moves the chip out of the way.
 *  4. If a touch still reaches the chip right when the bot was tapping there, it is ignored, logged,
 *     and the bot learns the real position of the chip.
 */
class AutoPlayService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoPlayService"
        private const val ACTION_GAP_MS = 120L

        /** Gestures closer than this to the chip (dp) are refused. */
        private const val GUARD_DP = 24

        /** No-tap zone given to the brain is the chip grown by this much (dp), a bit bigger than the guard. */
        private const val ZONE_DP = 28

        /** The chip is painted over with this much extra around it (dp). */
        private const val PAINT_DP = 12

        @Volatile
        var instance: AutoPlayService? = null

        @Volatile
        var statusText: String = "Idle"

        private var crashHandlerInstalled = false
    }

    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private var worker: Thread? = null

    @Volatile
    private var lastShotError = 0

    private val maskPaint = Paint().apply { color = 0xFF303030.toInt() }

    // Where the chip is, in screen pixels: [left, top, right, bottom]. Several guesses are kept together.
    @Volatile
    private var chipBoxes: List<IntArray> = emptyList()

    // Correction between Android's view positions and where the touch system really puts them.
    @Volatile
    private var chipOffX = 0

    @Volatile
    private var chipOffY = 0

    @Volatile
    private var chipInfo = ""

    // The bot's own most recent gesture, so its own touches can be recognised.
    @Volatile
    private var gesturePoints = FloatArray(0)

    @Volatile
    private var gestureActive = false

    @Volatile
    private var gestureEndedAt = 0L

    @Volatile
    private var refused = false

    private var gesturesLogged = 0

    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private var overlayLp: WindowManager.LayoutParams? = null
    private var playBtn: TextView? = null
    private var statusView: TextView? = null

    // ---------------------------------------------------------------- service lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        DebugLog.init(this)
        installCrashLogger()
        DebugLog.add("service connected, app v${BuildInfo.VERSION} (build ${BuildInfo.CODE}), android ${Build.VERSION.SDK_INT}, ${Build.MANUFACTURER} ${Build.MODEL}")
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        setStatus("Service connected. Open a game and press PLAY.")
    }

    /** Writes any crash to the debug log before Android handles it. */
    private fun installCrashLogger() {
        if (crashHandlerInstalled) return
        crashHandlerInstalled = true
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            DebugLog.add("CRASH in thread ${t.name}: ${Log.getStackTraceString(e).take(1200)}")
            previous?.uncaughtException(t, e)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed: we work from screenshots, not from the view tree.
    }

    override fun onInterrupt() {
        DebugLog.add("onInterrupt called by Android")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        DebugLog.add("service unbound (Android turned the service off or it was disabled)")
        stopAgent("Service was turned off.")
        removeOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        DebugLog.add("service destroyed")
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- agent control

    fun isRunning(): Boolean = running.get()

    fun toggle() {
        if (running.get()) stopAgent("Stopped.") else startAgent()
    }

    fun startAgent() {
        if (worker?.isAlive == true) {
            setStatus("Still stopping, press PLAY again in a second.")
            return
        }
        val brain = createBrain() ?: return
        if (running.getAndSet(true)) {
            brain.close()
            return
        }
        DebugLog.add("PLAY pressed, mode=${Prefs.mode(this)}")
        setStatus("Starting...")
        updatePlayButton()
        worker = Thread({ runLoop(brain) }, "autoplay-agent").also { it.start() }
    }

    fun stopAgent(message: String?) {
        val caller = Throwable().stackTrace.drop(1).take(3).joinToString(" < ") { it.methodName }
        DebugLog.add("stopAgent(${message ?: "no message"}) called from $caller on thread ${Thread.currentThread().name}")
        running.set(false)
        worker?.interrupt()
        if (message != null) setStatus(message)
        updatePlayButton()
    }

    private fun createBrain(): Brain? {
        if (Prefs.mode(this) != Prefs.MODE_AI) return SmartBrain()

        val p = Prefs.provider(this)
        val key = Prefs.apiKey(this, p)
        val base = Prefs.baseUrl(this, p)
        val model = Prefs.model(this, p)
        if (p.needsKey && key.isBlank()) {
            setStatus("No API key for ${p.label}. Add it in the app, or switch to Offline mode.")
            return null
        }
        if (base.isBlank() || model.isBlank()) {
            setStatus("Set the model name and base URL for ${p.label} in the app.")
            return null
        }
        // A model name with spaces is a display name ("Gemini 3.x Flash"): the loop repairs it by itself.
        return AiBrain(AiBrain.Config(p, key, model, base))
    }

    /**
     * The AI company retired or renamed the model. Ask the account which models exist, pick the newest
     * of the same family, check that it answers, save it and carry on. Returns a new brain, or null.
     */
    private fun repairModel(ai: AiBrain, e: FatalConfigException): Brain? {
        val cfg = ai.config
        setStatus("Model \"${cfg.model.take(24)}\" is not usable. Looking for a working one...")
        DebugLog.add("model problem with \"${cfg.model}\": ${e.message?.take(200)}")
        val fixed = try {
            AiBrain.heal(cfg, e.message ?: "")
        } catch (t: Exception) {
            DebugLog.add("model auto-fix failed: ${t.javaClass.simpleName}: ${t.message}")
            null
        } ?: return null
        Prefs.setModel(this, cfg.provider, fixed)
        DebugLog.add("MODEL AUTO-FIXED: \"${cfg.model}\" -> \"$fixed\"")
        setStatus("Model fixed automatically, now using $fixed")
        return AiBrain(AiBrain.Config(cfg.provider, cfg.apiKey, fixed, cfg.baseUrl))
    }

    // ---------------------------------------------------------------- the main loop

    private fun runLoop(initialBrain: Brain) {
        var brain = initialBrain
        val delayMs = Prefs.delayMs(this)
        val maxActions = if (Prefs.mode(this) == Prefs.MODE_AI) Prefs.actionsPerCall(this) else 1
        val history = ArrayList<String>()
        var prevThumb: IntArray? = null
        var stuck = 0
        var shotFailures = 0
        var failures = 0
        var step = 0
        var finishStreak = 0
        var repairedFor = ""
        val startedAt = SystemClock.elapsedRealtime()
        DebugLog.add("agent loop started (${brain.javaClass.simpleName}, delay ${delayMs}ms, maxActions $maxActions)")

        try {
            while (running.get()) {
                try {
                    // 1) Look at the screen. Failures here are never fatal: just wait and look again.
                    val frame = captureBlocking()
                    if (frame == null) {
                        if (lastShotError == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                            Thread.sleep(120L) // asked too fast, normal at full speed
                        } else {
                            shotFailures++
                            if (shotFailures == 1 || shotFailures % 10 == 0) {
                                DebugLog.add("screenshot failed, code $lastShotError (#$shotFailures)")
                            }
                            setStatus("Waiting for the screen... ($shotFailures)")
                            Thread.sleep((400L * shotFailures).coerceAtMost(3000L))
                        }
                        continue
                    }
                    shotFailures = 0

                    // Hide our own floating chip from the bot, so it can never read or tap itself.
                    val blocked = maskChip(frame)

                    val w = frame.width
                    val h = frame.height
                    val thumb = FrameTools.thumb(frame)
                    val change = prevThumb?.let { FrameTools.diff(it, thumb) }
                    prevThumb = thumb
                    if (change != null) {
                        if (change < 0.004f) stuck++ else stuck = 0
                    }

                    step++
                    if (step <= 3 || step % 50 == 0) {
                        DebugLog.add("frame ${w}x${h}, step $step, chip: $chipInfo, zones=${blocked.size}")
                    }
                    val perSec = step * 1000f / max(1L, SystemClock.elapsedRealtime() - startedAt)
                    val rate = String.format(Locale.US, "%.1f", perSec)
                    setStatus("Step $step ($rate/s): thinking...")

                    // 2) Think. The rules are re-read every step so edits apply immediately.
                    val ctx = AgentContext(Prefs.goal(this), history.takeLast(8), change, stuck, maxActions, blocked)
                    val decision: Decision = try {
                        brain.decide(frame, ctx).also { failures = 0 }
                    } catch (e: AuthException) {
                        DebugLog.add("AUTH error: ${e.message}")
                        stopAgent("API key rejected: ${e.message}")
                        break
                    } catch (e: FatalConfigException) {
                        val ai = brain as? AiBrain
                        val repaired: Brain? =
                            if (e is ModelProblemException && ai != null && ai.config.model != repairedFor) {
                                repairedFor = ai.config.model
                                repairModel(ai, e)
                            } else {
                                null
                            }
                        if (repaired != null) {
                            try {
                                brain.close()
                            } catch (_: Throwable) {
                            }
                            brain = repaired
                            prevThumb = null
                            step--
                            continue
                        }
                        DebugLog.add("SETUP error: ${e.message}")
                        stopAgent("Setup problem: ${e.message}")
                        break
                    } catch (e: InterruptedException) {
                        throw e
                    } catch (e: Exception) {
                        failures++
                        val limited = (e as? ApiException)?.code == 429
                        DebugLog.add("brain error #$failures: ${e.javaClass.simpleName}: ${e.message}")
                        setStatus(
                            if (limited) "Rate limited, waiting a bit..."
                            else "Error, retrying: ${e.message?.take(80)}",
                        )
                        prevThumb = null
                        step--
                        val wait = if (limited) 6000L * failures else 1500L * failures
                        Thread.sleep(wait.coerceAtMost(30000L))
                        continue
                    } finally {
                        frame.recycle()
                    }

                    if (!running.get()) break

                    val actions = decision.actions
                    history.add("$step. ${decision.label} - ${decision.note}")
                    DebugLog.add("step $step: ${decision.label} | ${decision.note} | change=${change ?: -1f}")
                    setStatus("Step $step ($rate/s): ${decision.note.ifBlank { decision.label }}")

                    // 3) "Finish" is only a soft stop: keep watching, pause after 4 in a row.
                    val fin = actions.firstOrNull { it is GameAction.Finish } as? GameAction.Finish
                    if (fin != null) {
                        finishStreak++
                        if (finishStreak >= 4) {
                            stopAgent("Paused: ${fin.reason}. Press PLAY to resume.")
                            break
                        }
                        setStatus("AI thinks it is done (${fin.reason}). Still watching...")
                        Thread.sleep(3000L)
                        continue
                    }
                    finishStreak = 0

                    // 4) Act.
                    refused = false
                    for ((i, a) in actions.withIndex()) {
                        if (!running.get()) break
                        if (!execute(a, w, h) && !refused) DebugLog.add("gesture failed or cancelled: ${decision.label}")
                        if (i < actions.size - 1) Thread.sleep(ACTION_GAP_MS)
                    }
                    if (refused) {
                        // The action would have hit our own chip. It never happened, so do not count it as a miss.
                        brain.onActionRefused()
                        Thread.sleep(350L) // let the chip finish moving before the next screenshot
                    }
                    if (delayMs > 0L) Thread.sleep(delayMs)
                } catch (e: InterruptedException) {
                    throw e
                } catch (e: Throwable) {
                    // Anything unexpected (even an Error): log it, show it, carry on. Never die silently.
                    DebugLog.add("LOOP HICCUP ${e.javaClass.simpleName}: ${Log.getStackTraceString(e).take(900)}")
                    setStatus("Hiccup, continuing: ${e.javaClass.simpleName}")
                    if (e is OutOfMemoryError) System.gc()
                    Thread.sleep(1000L)
                }
            }
        } catch (_: InterruptedException) {
            DebugLog.add("agent loop interrupted (stop requested)")
        } catch (t: Throwable) {
            DebugLog.add("AGENT LOOP DIED ${t.javaClass.simpleName}: ${Log.getStackTraceString(t).take(900)}")
            setStatus("Agent crashed: ${t.javaClass.simpleName}. See debug log.")
        } finally {
            running.set(false)
            DebugLog.add("agent loop ended after $step steps")
            try {
                brain.close()
            } catch (_: Throwable) {
            }
            updatePlayButton()
        }
    }

    // ---------------------------------------------------------------- screen capture

    private fun captureBlocking(): Bitmap? {
        val latch = CountDownLatch(1)
        var result: Bitmap? = null
        lastShotError = 0
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        try {
                            val hw = screenshot.hardwareBuffer
                            val wrapped = Bitmap.wrapHardwareBuffer(hw, screenshot.colorSpace)
                            // mutable copy, so we can paint over our own chip
                            result = wrapped?.copy(Bitmap.Config.ARGB_8888, true)
                            wrapped?.recycle()
                            hw.close()
                        } catch (t: Throwable) {
                            DebugLog.add("screenshot decode failed: ${t.javaClass.simpleName}: ${t.message}")
                            lastShotError = -1
                        } finally {
                            latch.countDown()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        lastShotError = errorCode
                        latch.countDown()
                    }
                },
            )
        } catch (t: Throwable) {
            DebugLog.add("takeScreenshot threw ${t.javaClass.simpleName}: ${t.message}")
            lastShotError = -2
            return null
        }
        latch.await(5, TimeUnit.SECONDS)
        return result
    }

    // ---------------------------------------------------------------- finding and hiding our own chip

    /** What Android says: [chip box, PLAY/STOP button], both in screen pixels, or null if there is no chip. */
    private fun chipApi(): Array<IntArray>? {
        var res: Array<IntArray>? = null
        onMainSync {
            val v = overlay ?: return@onMainSync
            val b = playBtn ?: return@onMainSync
            if (v.width <= 0 || v.height <= 0 || b.width <= 0 || b.height <= 0) return@onMainSync
            val lv = IntArray(2)
            val lb = IntArray(2)
            v.getLocationOnScreen(lv)
            b.getLocationOnScreen(lb)
            res = arrayOf(
                intArrayOf(lv[0], lv[1], lv[0] + v.width, lv[1] + v.height),
                intArrayOf(lb[0], lb[1], lb[0] + b.width, lb[1] + b.height),
            )
        }
        return res
    }

    private fun shifted(r: IntArray): IntArray =
        intArrayOf(r[0] + chipOffX, r[1] + chipOffY, r[2] + chipOffX, r[3] + chipOffY)

    /** Looks for the chip's coloured PLAY/STOP button inside the screenshot. Frame pixels, or null. */
    private fun findButtonInFrame(frame: Bitmap, api: Array<IntArray>?): ChipLocator.Box? {
        val gw = min(540, frame.width)
        val gh = (frame.height.toLong() * gw / frame.width).toInt().coerceAtLeast(1)
        val scale = gw.toFloat() / frame.width
        val small = if (gw == frame.width) frame else Bitmap.createScaledBitmap(frame, gw, gh, true)
        val px = IntArray(gw * gh)
        small.getPixels(px, 0, gw, 0, 0, gw, gh)
        if (small !== frame) small.recycle()

        var ew = -1f
        var eh = -1f
        var hx = -1f
        var hy = -1f
        if (api != null) {
            val btn = shifted(api[1])
            ew = (btn[2] - btn[0]) * scale
            eh = (btn[3] - btn[1]) * scale
            hx = (btn[0] + btn[2]) / 2f * scale
            hy = (btn[1] + btn[3]) / 2f * scale
        }
        val g = ChipLocator.find(px, gw, gh, ew, eh, hx, hy, tol = 26) ?: return null
        return ChipLocator.Box(
            (g.l / scale).toInt(),
            (g.t / scale).toInt(),
            (g.r / scale).toInt(),
            (g.b / scale).toInt(),
        )
    }

    private fun sameRect(a: IntArray, b: IntArray, tol: Int): Boolean =
        abs(a[0] - b[0]) <= tol && abs(a[1] - b[1]) <= tol && abs(a[2] - b[2]) <= tol && abs(a[3] - b[3]) <= tol

    /** Every place the chip might be in this frame (Android's idea plus what the screenshot shows). */
    private fun locateChip(frame: Bitmap): List<IntArray> {
        val api = chipApi()
        val rects = ArrayList<IntArray>()
        var apiBox: IntArray? = null
        if (api != null) {
            apiBox = shifted(api[0])
            rects.add(apiBox)
        }

        var found: ChipLocator.Box? = null
        try {
            found = findButtonInFrame(frame, api)
        } catch (t: Throwable) {
            DebugLog.add("chip finder error ${t.javaClass.simpleName}: ${t.message}")
        }
        if (found != null) {
            val d = resources.displayMetrics.density
            val box = if (api != null) {
                ChipLocator.chipFromButton(found, api[0], api[1])
            } else {
                // Android could not say where the chip is: widen around the button (grip on the left, status + X on the right).
                intArrayOf(
                    (found.l - 56 * d).toInt().coerceAtLeast(0),
                    (found.t - 12 * d).toInt().coerceAtLeast(0),
                    (found.r + 230 * d).toInt().coerceAtMost(frame.width),
                    (found.b + 12 * d).toInt().coerceAtMost(frame.height),
                )
            }
            if (apiBox == null || !sameRect(apiBox, box, 6)) rects.add(box)
        }

        chipInfo = "api=" + (api?.let { fmt(it[0]) } ?: "none") +
            " btn=" + (api?.let { fmt(it[1]) } ?: "none") +
            " found=" + (found?.let { "[${it.l},${it.t},${it.r},${it.b}]" } ?: "none") +
            " off=($chipOffX,$chipOffY)"
        chipBoxes = rects
        return rects
    }

    private fun fmt(r: IntArray) = "[${r[0]},${r[1]},${r[2]},${r[3]}]"

    /** Paints every possible chip spot dark grey in the frame and returns them as no-tap zones. */
    private fun maskChip(frame: Bitmap): List<Zone> {
        val rects = locateChip(frame)
        if (rects.isEmpty()) return emptyList()
        val d = resources.displayMetrics.density
        val paintPad = (PAINT_DP * d).toInt()
        val zonePad = (ZONE_DP * d).toInt()
        val fw = frame.width.toFloat()
        val fh = frame.height.toFloat()
        val canvas = try {
            Canvas(frame)
        } catch (t: Throwable) {
            DebugLog.add("cannot paint over the chip: ${t.javaClass.simpleName}: ${t.message}")
            null
        }
        val zones = ArrayList<Zone>()
        for (r in rects) {
            if (canvas != null) {
                canvas.drawRect(
                    max(0, r[0] - paintPad).toFloat(),
                    max(0, r[1] - paintPad).toFloat(),
                    min(frame.width, r[2] + paintPad).toFloat(),
                    min(frame.height, r[3] + paintPad).toFloat(),
                    maskPaint,
                )
            }
            zones.add(
                Zone(
                    max(0, r[0] - zonePad) / fw,
                    max(0, r[1] - zonePad) / fh,
                    min(frame.width, r[2] + zonePad) / fw,
                    min(frame.height, r[3] + zonePad) / fh,
                ),
            )
        }
        return zones
    }

    // ---------------------------------------------------------------- gestures

    private fun execute(a: GameAction, w: Int, h: Int): Boolean = when (a) {
        is GameAction.Tap -> dispatchTaps(a.x * w, a.y * h, a.count)
        is GameAction.LongPress -> {
            val x = a.x * w
            val y = a.y * h
            val p = Path().apply { moveTo(x, y) }
            perform(single(p, a.ms), a.ms, floatArrayOf(x, y))
        }
        is GameAction.Swipe -> {
            val x1 = a.x1 * w
            val y1 = a.y1 * h
            val x2 = a.x2 * w
            val y2 = a.y2 * h
            val p = Path().apply {
                moveTo(x1, y1)
                lineTo(x2, y2)
            }
            // check the whole path, not just the ends
            val pts = FloatArray(16)
            for (i in 0 until 8) {
                val f = i / 7f
                pts[i * 2] = x1 + (x2 - x1) * f
                pts[i * 2 + 1] = y1 + (y2 - y1) * f
            }
            perform(single(p, a.ms), a.ms, pts)
        }
        is GameAction.Wait -> {
            Thread.sleep(a.ms)
            true
        }
        is GameAction.Back -> performGlobalAction(GLOBAL_ACTION_BACK)
        is GameAction.Finish -> true
    }

    private fun single(path: Path, ms: Long): GestureDescription =
        GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, ms.coerceAtLeast(1L)))
            .build()

    /** Up to 20 taps inside ONE gesture, so rapid tapping does not pay per-tap overhead. */
    private fun dispatchTaps(x: Float, y: Float, count: Int): Boolean {
        val n = count.coerceIn(1, minOf(20, GestureDescription.getMaxStrokeCount()))
        val builder = GestureDescription.Builder()
        for (i in 0 until n) {
            val p = Path().apply { moveTo(x, y) }
            builder.addStroke(GestureDescription.StrokeDescription(p, i * 70L, 40L))
        }
        return perform(builder.build(), n * 70L, floatArrayOf(x, y))
    }

    /** Runs one gesture and blocks until Android reports it finished. Refuses anything near our own chip. */
    private fun perform(gesture: GestureDescription, durationMs: Long, points: FloatArray): Boolean {
        if (hitsChip(points)) {
            refused = true
            DebugLog.add(
                "REFUSED gesture at (${points[0].toInt()},${points[1].toInt()}): it is too close to my own chip. $chipInfo",
            )
            dodgeChip(points[0], points[1])
            return false
        }

        val latch = CountDownLatch(1)
        var ok = false
        gesturePoints = points
        gestureActive = true
        if (gesturesLogged < 12 || gesturesLogged % 40 == 0) {
            DebugLog.add("gesture #$gesturesLogged at (${points[0].toInt()},${points[1].toInt()}) ${durationMs}ms")
        }
        gesturesLogged++
        try {
            val accepted = dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        ok = true
                        latch.countDown()
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        latch.countDown()
                    }
                },
                null,
            )
            if (!accepted) return false
            latch.await(durationMs + 2000L, TimeUnit.MILLISECONDS)
            return ok
        } finally {
            gestureActive = false
            gestureEndedAt = SystemClock.uptimeMillis()
        }
    }

    /** True if any of the points is on or near the chip, by Android's idea or by what the screenshot showed. */
    private fun hitsChip(points: FloatArray): Boolean {
        val rects = ArrayList<IntArray>(chipBoxes)
        chipApi()?.let { rects.add(shifted(it[0])) } // fresh, in case the user just dragged the chip
        if (rects.isEmpty()) return false
        val margin = (GUARD_DP * resources.displayMetrics.density).toInt()
        var i = 0
        while (i + 1 < points.size) {
            if (ChipLocator.hitsAny(points[i], points[i + 1], rects, margin)) return true
            i += 2
        }
        return false
    }

    /** Moves the chip to whichever corner is farthest from (x, y), so the bot can reach what was under it. */
    private fun dodgeChip(x: Float, y: Float) {
        onMainSync {
            val v = overlay ?: return@onMainSync
            val lp = overlayLp ?: return@onMainSync
            val dm = resources.displayMetrics
            val d = dm.density
            val cw = v.width
            val ch = v.height
            val left = (8 * d).toInt()
            val right = max(left, dm.widthPixels - cw - (8 * d).toInt())
            val top = (120 * d).toInt()
            val bottom = max(top, dm.heightPixels - ch - (150 * d).toInt())
            val spots = listOf(intArrayOf(left, top), intArrayOf(left, bottom), intArrayOf(right, top), intArrayOf(right, bottom))
            var best = spots[0]
            var bestD = -1f
            for (s in spots) {
                val dx = s[0] + cw / 2f - x
                val dy = s[1] + ch / 2f - y
                val dist = sqrt(dx * dx + dy * dy)
                if (dist > bestD) {
                    bestD = dist
                    best = s
                }
            }
            lp.x = best[0]
            lp.y = best[1]
            try {
                wm.updateViewLayout(v, lp)
                DebugLog.add("moved the chip out of the way to (${best[0]},${best[1]})")
            } catch (_: Exception) {
            }
        }
    }

    // ---------------------------------------------------------------- recognising our own touches

    /** True if a touch at (x, y) is almost certainly the bot's own gesture, not a finger. */
    private fun looksLikeBotTouch(x: Float, y: Float): Boolean {
        val recent = gestureActive || SystemClock.uptimeMillis() - gestureEndedAt < 700L
        if (!recent) return false
        val pts = gesturePoints
        var i = 0
        while (i + 1 < pts.size) {
            val dx = pts[i] - x
            val dy = pts[i + 1] - y
            if (sqrt(dx * dx + dy * dy) < 48f) return true
            i += 2
        }
        return false
    }

    /** The bot's tap reached its own chip: remember where the chip REALLY is and move it away. */
    private fun learnFromSelfTap(v: View, e: MotionEvent, name: String) {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val inX = (e.rawX - e.x).toInt()
        val inY = (e.rawY - e.y).toInt()
        val dx = inX - loc[0]
        val dy = inY - loc[1]
        DebugLog.add(
            "SELF-TAP IGNORED: my own tap at (${e.rawX.toInt()},${e.rawY.toInt()}) hit the chip's $name button. " +
                "Touch system puts the button at ($inX,$inY), Android says (${loc[0]},${loc[1]}). $chipInfo",
        )
        if (abs(dx) > 3 || abs(dy) > 3) {
            chipOffX = dx
            chipOffY = dy
            DebugLog.add("learned chip offset ($dx,$dy)")
        }
        refused = true
        dodgeChip(e.rawX, e.rawY)
    }

    /** Button handler that ignores the bot's own touches and runs [action] only for a real finger. */
    private fun chipButtonTouch(v: View, e: MotionEvent, name: String, action: () -> Unit): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val own = looksLikeBotTouch(e.rawX, e.rawY)
                v.tag = if (own) "own" else "finger"
                if (own) learnFromSelfTap(v, e, name)
            }
            MotionEvent.ACTION_UP -> {
                val finger = v.tag == "finger"
                v.tag = null
                val inside = e.x >= 0f && e.x <= v.width && e.y >= 0f && e.y <= v.height
                if (finger && inside) action()
            }
            MotionEvent.ACTION_CANCEL -> v.tag = null
        }
        return true
    }

    // ---------------------------------------------------------------- floating chip

    fun showOverlay() {
        main.post {
            if (overlay != null) return@post
            val ctx: Context = this
            val density = resources.displayMetrics.density
            fun dp(v: Int) = (v * density).toInt()

            val grip = TextView(ctx).apply {
                text = "≡"
                textSize = 22f
                setTextColor(0xFF8FA3B8.toInt())
                setPadding(dp(10), dp(4), dp(6), dp(4))
            }
            val play = TextView(ctx).apply {
                text = "PLAY"
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setTextColor(0xFF06210F.toInt())
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = pill(0xFF35E0A1.toInt(), dp(20).toFloat())
                setOnTouchListener { v, e ->
                    chipButtonTouch(v, e, "PLAY/STOP") {
                        DebugLog.add("chip PLAY/STOP pressed by a finger")
                        toggle()
                    }
                }
            }
            // Fixed size, so the chip never changes shape between the screenshot and the moment we hide it.
            val status = TextView(ctx).apply {
                text = "Open your game, then press PLAY"
                textSize = 11f
                setTextColor(0xFFD5DEE8.toInt())
                minLines = 2
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setWidth(dp(150))
                setPadding(dp(8), 0, dp(6), 0)
            }
            val close = TextView(ctx).apply {
                text = "X"
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFFFF8A80.toInt())
                setPadding(dp(8), dp(6), dp(12), dp(6))
                setOnTouchListener { v, e ->
                    chipButtonTouch(v, e, "X") {
                        DebugLog.add("chip X pressed by a finger")
                        stopAgent("Stopped.")
                        removeOverlay()
                    }
                }
            }

            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = pill(0xEE101820.toInt(), dp(26).toFloat())
                setPadding(dp(4), dp(4), dp(4), dp(4))
                addView(grip)
                addView(play)
                addView(status)
                addView(close)
            }

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = dp(8)
                y = dp(140)
            }

            // Drag the chip by its grip.
            grip.setOnTouchListener(object : View.OnTouchListener {
                var startX = 0f
                var startY = 0f
                var originX = 0
                var originY = 0
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            startX = e.rawX
                            startY = e.rawY
                            originX = lp.x
                            originY = lp.y
                        }
                        MotionEvent.ACTION_MOVE -> {
                            lp.x = originX + (e.rawX - startX).toInt()
                            lp.y = originY + (e.rawY - startY).toInt()
                            try {
                                wm.updateViewLayout(box, lp)
                            } catch (_: Exception) {
                            }
                        }
                    }
                    return true
                }
            })

            try {
                wm.addView(box, lp)
                overlay = box
                overlayLp = lp
                playBtn = play
                statusView = status
                status.text = statusText
                updatePlayButton()
                DebugLog.add("overlay shown")
            } catch (t: Throwable) {
                DebugLog.add("cannot show overlay: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    fun removeOverlay() {
        main.post {
            overlay?.let {
                try {
                    wm.removeView(it)
                } catch (_: Exception) {
                }
            }
            overlay = null
            overlayLp = null
            playBtn = null
            statusView = null
            chipBoxes = emptyList()
            DebugLog.add("overlay removed")
        }
    }

    private fun pill(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun updatePlayButton() {
        main.post {
            val btn = playBtn ?: return@post
            val on = running.get()
            btn.text = if (on) "STOP" else "PLAY"
            btn.background = pill(
                if (on) 0xFFFF6B6B.toInt() else 0xFF35E0A1.toInt(),
                (20 * resources.displayMetrics.density),
            )
        }
    }

    private fun onMainSync(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
            return
        }
        val latch = CountDownLatch(1)
        main.post {
            try {
                block()
            } finally {
                latch.countDown()
            }
        }
        try {
            latch.await(2, TimeUnit.SECONDS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt() // keep the stop signal, the block is already queued
        }
    }

    private fun setStatus(s: String) {
        statusText = s
        main.post { statusView?.text = s }
    }
}
