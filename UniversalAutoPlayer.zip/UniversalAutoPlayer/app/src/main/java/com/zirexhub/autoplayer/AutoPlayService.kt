package com.zirexhub.autoplayer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/**
 * The heart of the app. As an accessibility service it can
 *  - take screenshots of whatever app is in front (API 30+),
 *  - inject taps / swipes (dispatchGesture),
 *  - show a small floating PLAY/STOP chip on top of any game.
 * When you press PLAY it runs the loop: screenshot -> brain decides -> perform gestures -> repeat.
 *
 * The loop only stops when YOU press STOP, the API key is rejected, or the setup is wrong.
 * Loading screens, frozen screens, network hiccups and screenshot errors never stop it.
 */
class AutoPlayService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoPlayService"
        private const val ACTION_GAP_MS = 120L

        @Volatile
        var instance: AutoPlayService? = null

        @Volatile
        var statusText: String = "Idle"
    }

    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private var worker: Thread? = null

    @Volatile
    private var lastShotError = 0

    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private var overlayLp: WindowManager.LayoutParams? = null
    private var playBtn: TextView? = null
    private var statusView: TextView? = null

    // ---------------------------------------------------------------- service lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        setStatus("Service connected. Open a game and press PLAY.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed: we work from screenshots, not from the view tree.
    }

    override fun onInterrupt() {
        // Nothing to do.
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopAgent(null)
        removeOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- agent control

    fun isRunning(): Boolean = running.get()

    fun toggle() {
        if (running.get()) stopAgent("Stopped.") else startAgent()
    }

    fun startAgent() {
        if (worker?.isAlive == true) {
            setStatus("Still stopping, press PLAY again in a second.")
            return
        }
        val brain = createBrain() ?: return
        if (running.getAndSet(true)) {
            brain.close()
            return
        }
        setStatus("Starting...")
        updatePlayButton()
        worker = Thread({ runLoop(brain) }, "autoplay-agent").also { it.start() }
    }

    fun stopAgent(message: String?) {
        running.set(false)
        worker?.interrupt()
        if (message != null) setStatus(message)
        updatePlayButton()
    }

    private fun createBrain(): Brain? {
        if (Prefs.mode(this) != Prefs.MODE_AI) return SmartBrain()

        val p = Prefs.provider(this)
        val key = Prefs.apiKey(this, p)
        val base = Prefs.baseUrl(this, p)
        val model = Prefs.model(this, p)
        if (p.needsKey && key.isBlank()) {
            setStatus("No API key for ${p.label}. Add it in the app, or switch to Offline mode.")
            return null
        }
        if (base.isBlank() || model.isBlank()) {
            setStatus("Set the model name and base URL for ${p.label} in the app.")
            return null
        }
        return AiBrain(AiBrain.Config(p, key, model, base))
    }

    // ---------------------------------------------------------------- the main loop

    private fun runLoop(brain: Brain) {
        val delayMs = Prefs.delayMs(this)
        val maxActions = if (Prefs.mode(this) == Prefs.MODE_AI) Prefs.actionsPerCall(this) else 1
        val history = ArrayList<String>()
        var prevThumb: IntArray? = null
        var stuck = 0
        var shotFailures = 0
        var failures = 0
        var step = 0
        var finishStreak = 0
        val startedAt = SystemClock.elapsedRealtime()

        try {
            while (running.get()) {
                try {
                    // 1) Look at the screen. Failures here are never fatal: just wait and look again.
                    val frame = captureBlocking()
                    if (frame == null) {
                        if (lastShotError == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                            Thread.sleep(120L) // asked too fast, normal at full speed
                        } else {
                            shotFailures++
                            setStatus("Waiting for the screen... ($shotFailures)")
                            Thread.sleep((400L * shotFailures).coerceAtMost(3000L))
                        }
                        continue
                    }
                    shotFailures = 0

                    val w = frame.width
                    val h = frame.height
                    val thumb = FrameTools.thumb(frame)
                    val change = prevThumb?.let { FrameTools.diff(it, thumb) }
                    prevThumb = thumb
                    if (change != null) {
                        if (change < 0.004f) stuck++ else stuck = 0
                    }

                    step++
                    val perSec = step * 1000f / max(1L, SystemClock.elapsedRealtime() - startedAt)
                    val rate = String.format(Locale.US, "%.1f", perSec)
                    setStatus("Step $step ($rate/s): thinking...")

                    // 2) Think. The rules are re-read every step so edits apply immediately.
                    val ctx = AgentContext(Prefs.goal(this), history.takeLast(8), change, stuck, maxActions)
                    val decision: Decision = try {
                        brain.decide(frame, ctx).also { failures = 0 }
                    } catch (e: AuthException) {
                        stopAgent("API key rejected: ${e.message}")
                        break
                    } catch (e: FatalConfigException) {
                        stopAgent("Setup problem: ${e.message}")
                        break
                    } catch (e: InterruptedException) {
                        throw e
                    } catch (e: Exception) {
                        failures++
                        val limited = (e as? ApiException)?.code == 429
                        Log.w(TAG, "brain error", e)
                        setStatus(
                            if (limited) "Rate limited, waiting a bit..."
                            else "Error, retrying: ${e.message?.take(80)}",
                        )
                        prevThumb = null
                        step--
                        val wait = if (limited) 6000L * failures else 1500L * failures
                        Thread.sleep(wait.coerceAtMost(30000L))
                        continue
                    } finally {
                        frame.recycle()
                    }

                    if (!running.get()) break

                    val actions = decision.actions
                    history.add("$step. ${decision.label} - ${decision.note}")
                    setStatus("Step $step ($rate/s): ${decision.note.ifBlank { decision.label }}")

                    // 3) "Finish" is only a soft stop: keep watching, pause after 4 in a row.
                    val fin = actions.firstOrNull { it is GameAction.Finish } as? GameAction.Finish
                    if (fin != null) {
                        finishStreak++
                        if (finishStreak >= 4) {
                            stopAgent("Paused: ${fin.reason}. Press PLAY to resume.")
                            break
                        }
                        setStatus("AI thinks it is done (${fin.reason}). Still watching...")
                        Thread.sleep(3000L)
                        continue
                    }
                    finishStreak = 0

                    // 4) Act.
                    for ((i, a) in actions.withIndex()) {
                        if (!running.get()) break
                        if (!execute(a, w, h)) Log.w(TAG, "gesture failed or was cancelled: ${decision.label}")
                        if (i < actions.size - 1) Thread.sleep(ACTION_GAP_MS)
                    }
                    if (delayMs > 0L) Thread.sleep(delayMs)
                } catch (e: InterruptedException) {
                    throw e
                } catch (e: Exception) {
                    // Anything unexpected: log it, show it, carry on. Never die silently.
                    Log.w(TAG, "loop hiccup", e)
                    setStatus("Hiccup, continuing: ${e.message?.take(60)}")
                    Thread.sleep(1000L)
                }
            }
        } catch (_: InterruptedException) {
            // stopAgent() interrupted us.
        } finally {
            running.set(false)
            setPassThrough(false) // never leave the floating chip untouchable
            try {
                brain.close()
            } catch (_: Throwable) {
            }
            updatePlayButton()
        }
    }

    // ---------------------------------------------------------------- screen capture

    private fun captureBlocking(): Bitmap? {
        val latch = CountDownLatch(1)
        var result: Bitmap? = null
        lastShotError = 0
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        try {
                            val hw = screenshot.hardwareBuffer
                            val wrapped = Bitmap.wrapHardwareBuffer(hw, screenshot.colorSpace)
                            result = wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                            wrapped?.recycle()
                            hw.close()
                        } catch (t: Throwable) {
                            Log.w(TAG, "screenshot decode failed", t)
                            lastShotError = -1
                        } finally {
                            latch.countDown()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        lastShotError = errorCode
                        latch.countDown()
                    }
                },
            )
        } catch (t: Throwable) {
            Log.w(TAG, "takeScreenshot threw", t)
            lastShotError = -2
            return null
        }
        latch.await(5, TimeUnit.SECONDS)
        return result
    }

    // ---------------------------------------------------------------- gestures

    private fun execute(a: GameAction, w: Int, h: Int): Boolean = when (a) {
        is GameAction.Tap -> dispatchTaps(a.x * w, a.y * h, a.count)
        is GameAction.LongPress -> {
            val x = a.x * w
            val y = a.y * h
            val p = Path().apply { moveTo(x, y) }
            perform(single(p, a.ms), a.ms, floatArrayOf(x, y))
        }
        is GameAction.Swipe -> {
            val x1 = a.x1 * w
            val y1 = a.y1 * h
            val x2 = a.x2 * w
            val y2 = a.y2 * h
            val p = Path().apply {
                moveTo(x1, y1)
                lineTo(x2, y2)
            }
            perform(single(p, a.ms), a.ms, floatArrayOf(x1, y1, (x1 + x2) / 2f, (y1 + y2) / 2f, x2, y2))
        }
        is GameAction.Wait -> {
            Thread.sleep(a.ms)
            true
        }
        is GameAction.Back -> performGlobalAction(GLOBAL_ACTION_BACK)
        is GameAction.Finish -> true
    }

    private fun single(path: Path, ms: Long): GestureDescription =
        GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, ms.coerceAtLeast(1L)))
            .build()

    /** Up to 20 taps inside ONE gesture, so rapid tapping does not pay per-tap overhead. */
    private fun dispatchTaps(x: Float, y: Float, count: Int): Boolean {
        val n = count.coerceIn(1, minOf(20, GestureDescription.getMaxStrokeCount()))
        val builder = GestureDescription.Builder()
        for (i in 0 until n) {
            val p = Path().apply { moveTo(x, y) }
            builder.addStroke(GestureDescription.StrokeDescription(p, i * 70L, 40L))
        }
        return perform(builder.build(), n * 70L, floatArrayOf(x, y))
    }

    /** Runs one gesture and blocks until Android reports it finished. */
    private fun perform(gesture: GestureDescription, durationMs: Long, points: FloatArray): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        // Only let touches fall "through" our own chip if the gesture actually crosses it.
        val needPass = touchesChip(points)
        if (needPass) setPassThrough(true)
        try {
            val accepted = dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        ok = true
                        latch.countDown()
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        latch.countDown()
                    }
                },
                null,
            )
            if (!accepted) return false
            latch.await(durationMs + 2000L, TimeUnit.MILLISECONDS)
            return ok
        } finally {
            if (needPass) setPassThrough(false)
        }
    }

    private fun touchesChip(points: FloatArray): Boolean {
        val v = overlay ?: return false
        val lp = overlayLp ?: return false
        val margin = 100
        val l = lp.x - margin
        val t = lp.y - margin
        val r = lp.x + v.width + margin
        val b = lp.y + v.height + margin
        var i = 0
        while (i + 1 < points.size) {
            if (points[i] >= l && points[i] <= r && points[i + 1] >= t && points[i + 1] <= b) return true
            i += 2
        }
        return false
    }

    // ---------------------------------------------------------------- floating chip

    fun showOverlay() {
        main.post {
            if (overlay != null) return@post
            val ctx: Context = this
            val density = resources.displayMetrics.density
            fun dp(v: Int) = (v * density).toInt()

            val grip = TextView(ctx).apply {
                text = "≡"
                textSize = 22f
                setTextColor(0xFF8FA3B8.toInt())
                setPadding(dp(10), dp(4), dp(6), dp(4))
            }
            val play = TextView(ctx).apply {
                text = "PLAY"
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setTextColor(0xFF06210F.toInt())
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = pill(0xFF35E0A1.toInt(), dp(20).toFloat())
                setOnClickListener { toggle() }
            }
            val status = TextView(ctx).apply {
                text = "Open your game, then press PLAY"
                textSize = 11f
                setTextColor(0xFFD5DEE8.toInt())
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                maxWidth = dp(150)
                setPadding(dp(8), 0, dp(6), 0)
            }
            val close = TextView(ctx).apply {
                text = "X"
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFFFF8A80.toInt())
                setPadding(dp(8), dp(6), dp(12), dp(6))
                setOnClickListener {
                    stopAgent("Stopped.")
                    removeOverlay()
                }
            }

            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = pill(0xEE101820.toInt(), dp(26).toFloat())
                setPadding(dp(4), dp(4), dp(4), dp(4))
                addView(grip)
                addView(play)
                addView(status)
                addView(close)
            }

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = dp(8)
                y = dp(140)
            }

            // Drag the chip by its grip.
            grip.setOnTouchListener(object : View.OnTouchListener {
                var startX = 0f
                var startY = 0f
                var originX = 0
                var originY = 0
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            startX = e.rawX
                            startY = e.rawY
                            originX = lp.x
                            originY = lp.y
                        }
                        MotionEvent.ACTION_MOVE -> {
                            lp.x = originX + (e.rawX - startX).toInt()
                            lp.y = originY + (e.rawY - startY).toInt()
                            try {
                                wm.updateViewLayout(box, lp)
                            } catch (_: Exception) {
                            }
                        }
                    }
                    return true
                }
            })

            try {
                wm.addView(box, lp)
                overlay = box
                overlayLp = lp
                playBtn = play
                statusView = status
                status.text = statusText
                updatePlayButton()
            } catch (t: Throwable) {
                Log.e(TAG, "cannot show overlay", t)
            }
        }
    }

    fun removeOverlay() {
        main.post {
            overlay?.let {
                try {
                    wm.removeView(it)
                } catch (_: Exception) {
                }
            }
            overlay = null
            overlayLp = null
            playBtn = null
            statusView = null
        }
    }

    private fun pill(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun updatePlayButton() {
        main.post {
            val btn = playBtn ?: return@post
            val on = running.get()
            btn.text = if (on) "STOP" else "PLAY"
            btn.background = pill(
                if (on) 0xFFFF6B6B.toInt() else 0xFF35E0A1.toInt(),
                (20 * resources.displayMetrics.density),
            )
        }
    }

    private fun setPassThrough(on: Boolean) {
        onMainSync {
            val v = overlay ?: return@onMainSync
            val lp = overlayLp ?: return@onMainSync
            lp.flags = if (on) {
                lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            } else {
                lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            }
            try {
                wm.updateViewLayout(v, lp)
            } catch (_: Exception) {
            }
        }
    }

    private fun onMainSync(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
            return
        }
        val latch = CountDownLatch(1)
        main.post {
            try {
                block()
            } finally {
                latch.countDown()
            }
        }
        try {
            latch.await(2, TimeUnit.SECONDS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt() // keep the stop signal, the block is already queued
        }
    }

    private fun setStatus(s: String) {
        statusText = s
        main.post { statusView?.text = s }
    }
}
