package com.zirexhub.autoplayer

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * A regular board of equal cells found in the screenshot (chess, checkers, tic-tac-toe, sudoku, match-3, ...).
 * [l], [t], [r], [b] are fractions of the screen (0..1) around the whole board; columns and rows are counted from 1,
 * from the top-left corner.
 */
class Grid(val l: Float, val t: Float, val r: Float, val b: Float, val cols: Int, val rows: Int) {
    fun cx(col: Int): Float = l + (r - l) * (col.coerceIn(1, cols) - 0.5f) / cols
    fun cy(row: Int): Float = t + (b - t) * (row.coerceIn(1, rows) - 0.5f) / rows

    /** Name of the cell in chess notation when the board is 8x8 and white sits at the bottom ("e2" = col 5, row 7). */
    fun chessName(col: Int, row: Int): String = "${'a' + (col - 1)}${rows - row + 1}"

    override fun toString(): String = "Grid ${cols}x$rows x ${pct(l)}-${pct(r)}% y ${pct(t)}-${pct(b)}%"
    private fun pct(v: Float) = (v * 100).toInt()
}

/**
 * Finds a board of equal cells in a grey picture (pure Kotlin, no Android).
 *
 * The AI reads a board very well but cannot say where a square is: on the chess log it answered "x=567" for a picture only 461
 * pixels wide and the tap went to the screen edge. The edges between the squares are easy for a program: they repeat at one
 * even spacing. How it works:
 *
 *  1. Edge energy per column and per row (how much brightness changes there).
 *  2. The spacing: for each possible cell size and offset, the average energy ON the lines minus the average energy BETWEEN
 *     the lines (a comb). The smallest size that is nearly as good as the best one wins (so 8 cells are not mistaken for 4).
 *  3. The extent: every cell whose left and top lines are really there counts for the board, the rest against it; the
 *     rectangle with the best total is the board. A tic-tac-toe, a chessboard with pieces on it and a sudoku all pass; text,
 *     lists, cards and ordinary game scenes do not (they do not repeat evenly).
 */
object GridFinder {
    private const val EDGE_CAP = 80

    /** Tests set this to see why a picture was rejected. */
    internal var trace: ((String) -> Unit)? = null
    private const val MIN_CELL_PX = 7f

    /** Edge strength between the two neighbours of each pixel, per direction. */
    internal class Edges(val w: Int, val h: Int, val ex: IntArray, val ey: IntArray)

    internal fun edges(g: Gray): Edges {
        val w = g.w
        val h = g.h
        val ex = IntArray(w * h)
        val ey = IntArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                ex[i] = min(EDGE_CAP, abs(g.px[i + 1] - g.px[i - 1]))
                ey[i] = min(EDGE_CAP, abs(g.px[i + w] - g.px[i - w]))
            }
        }
        return Edges(w, h, ex, ey)
    }

    internal fun profile(e: Edges, horizontal: Boolean): FloatArray {
        val n = if (horizontal) e.w else e.h
        val p = FloatArray(n)
        for (y in 0 until e.h) for (x in 0 until e.w) {
            if (horizontal) p[x] += e.ex[y * e.w + x] else p[y] += e.ey[y * e.w + x]
        }
        // [1 2 1] smoothing so a line that falls between two pixels still counts
        val s = FloatArray(n)
        for (i in 0 until n) s[i] = (p[max(0, i - 1)] + 2 * p[i] + p[min(n - 1, i + 1)]) / 4f
        return s
    }

    private fun at(p: FloatArray, pos: Float): Float {
        if (pos < 0f || pos > p.size - 1) return Float.NaN
        val i = pos.toInt()
        val f = pos - i
        return if (i + 1 < p.size) p[i] * (1 - f) + p[i + 1] * f else p[i]
    }

    internal class Lattice(val period: Float, val offset: Float, val contrast: Float)

    /** Best spacing and offset of evenly repeated lines in a profile, or null when there is no clear one. */
    internal fun lattice(p: FloatArray, minP: Float, maxP: Float): Lattice? {
        if (maxP <= minP) return null
        val mean = p.average().toFloat()
        val peak = max(1f, p.max())
        // (period, best offset, contrast) for every size on a fine ladder
        val cands = ArrayList<Lattice>()
        var per = minP
        while (per <= maxP) {
            var bestO = 0f
            var bestC = -1f
            var o = 0f
            while (o < per) {
                var on = 0f
                var off = 0f
                var n = 0
                var k = 0
                while (true) {
                    val pos = o + k * per
                    val mid = pos + per / 2f
                    if (mid > p.size - 1) break
                    val a = at(p, pos)
                    val m = at(p, mid)
                    if (!a.isNaN() && !m.isNaN()) {
                        // squared, so a line that sits exactly on the spacing counts clearly more than one that is two pixels off
                        on += a * a / peak
                        off += m * m / peak
                        n++
                    }
                    k++
                }
                if (n >= 3) {
                    val c = (on - off) / n
                    if (c > bestC) {
                        bestC = c
                        bestO = o
                    }
                }
                o += 0.5f
            }
            if (bestC > 0f) cands.add(Lattice(per, bestO, bestC))
            per += 0.25f
        }
        if (cands.isEmpty()) return null
        val top = cands.maxOf { it.contrast }
        if (top < mean * 0.12f * mean / peak) return null // the lines hardly stand out from the rest
        // the smallest size that is a local peak of the ladder and nearly as good as the best
        for (i in cands.indices) {
            val c = cands[i]
            if (c.contrast < top * 0.6f) continue
            val lo = cands.getOrNull(i - 1)?.contrast ?: -1f
            val hi = cands.getOrNull(i + 1)?.contrast ?: -1f
            if (c.contrast >= lo && c.contrast >= hi) {
                // refine inside the peak: the best of the neighbours within 1 px
                var best = c
                for (d in cands) if (abs(d.period - c.period) <= 1f && d.contrast > best.contrast) best = d
                return best
            }
        }
        return null
    }

    /** Mean edge strength along a line segment (taking the strongest of five neighbouring pixels across, so a line that is a
     *  pixel or two off the measured spacing still counts). A segment partly outside the picture is cut to the picture. */
    internal fun lineStrength(e: Edges, vertical: Boolean, pos: Float, from: Float, to: Float): Float {
        val a = max(1, from.toInt())
        val z = min(if (vertical) e.h - 2 else e.w - 2, to.toInt())
        if (z <= a) return 0f
        var sum = 0L
        for (s in a..z) {
            var best = 0
            for (d in -2..2) {
                val q = (pos + d).toInt()
                val x = if (vertical) q else s
                val y = if (vertical) s else q
                if (x < 1 || y < 1 || x >= e.w - 1 || y >= e.h - 1) continue
                val v = if (vertical) e.ex[y * e.w + x] else e.ey[y * e.w + x]
                if (v > best) best = v
            }
            sum += best
        }
        return sum.toFloat() / (z - a + 1)
    }

    /** Mean of the largest [k] values (a stand-in for "how strong a real line is on this screen"). */
    private fun topMean(vals: List<Float>, k: Int): Float {
        if (vals.isEmpty()) return 0f
        val sorted = vals.sortedDescending()
        val n = min(k, sorted.size)
        var s = 0f
        for (i in 0 until n) s += sorted[i]
        return s / n
    }

    /** The rectangle of cells with the best total score (Kadane in 2D): left, right, top, bottom cell indexes. */
    private fun bestRect(score: Array<FloatArray>): IntArray? {
        val rowsN = score.size
        val cols = score[0].size
        var best = 0f
        var res: IntArray? = null
        for (l in 0 until cols) {
            val sums = FloatArray(rowsN)
            for (r in l until cols) {
                for (j in 0 until rowsN) sums[j] += score[j][r]
                var cur = 0f
                var start = 0
                for (j in 0 until rowsN) {
                    if (cur <= 0f) {
                        cur = sums[j]
                        start = j
                    } else cur += sums[j]
                    if (cur > best) {
                        best = cur
                        res = intArrayOf(l, r, start, j)
                    }
                }
            }
        }
        return res
    }

    /**
     * Moves the lines onto the real ones: with the board known, only the board's own rows count for the column profile (and
     * the other way round), so text and buttons above or below cannot pull the lines aside. Returns the new start and spacing.
     */
    private fun refine(prof: FloatArray, start: Float, period: Float, n: Int): Pair<Float, Float> {
        if (n < 3) return start to period
        var bestS = 0f
        var bestD = 0f
        var bestV = -1f
        // wide enough to repair a coarse spacing that was a little off (a 3x3 board has only two lines to go by)
        var s = -0.2f * period
        while (s <= 0.2f * period) {
            var d = -0.14f
            while (d <= 0.141f) {
                val per = period * (1f + d)
                var sum = 0f
                var cnt = 0
                for (k in 1 until n) { // the lines between cells exist on every kind of board
                    val v = at(prof, start + s + k * per)
                    if (!v.isNaN()) {
                        sum += v
                        cnt++
                    }
                }
                if (cnt == n - 1 && sum > bestV) {
                    bestV = sum
                    bestS = s
                    bestD = d
                }
                d += 0.005f
            }
            s += 0.25f
        }
        return (start + bestS) to (period * (1f + bestD))
    }

    /** Finds the board in [g] (about 180 px wide is plenty), or null when the picture holds none. */
    fun find(g: Gray): Grid? {
        if (g.w < 40 || g.h < 40) return null
        val e = edges(g)
        val profX = profile(e, true)
        val profY = profile(e, false)
        val minP = max(MIN_CELL_PX, g.w / 20f)
        // One axis is searched freely, the other only for cells of about the same size (0.6 .. 1.7 times): a board has
        // roughly square cells, and without this a spacing of three cells can win by luck over the real one.
        var px = lattice(profX, minP, g.w / 2.5f)
        var py = if (px != null) lattice(profY, max(minP, px.period * 0.6f), min(g.h / 2.5f, px.period * 1.7f)) else null
        if (px == null || py == null) {
            py = lattice(profY, minP, g.h / 2.5f)
            px = if (py != null) lattice(profX, max(minP, py.period * 0.6f), min(g.w / 2.5f, py.period * 1.7f)) else null
        }
        if (px == null || py == null) {
            trace?.invoke("no lattice")
            return null
        }
        trace?.invoke("lattice x ${px.period}/${px.offset} y ${py.period}/${py.offset}")
        val ratio = px.period / py.period
        if (ratio < 0.6f || ratio > 1.7f) return null

        // lattice lines: x_i = ox + i*px for i = -1 .. ; cell (i,j) lies between line i and i+1 (and line j and j+1)
        val i0 = -1
        val cols = ((g.w - px.offset) / px.period).toInt() + 2 - i0
        val rowsN = ((g.h - py.offset) / py.period).toInt() + 2 - i0
        if (cols < 3 || rowsN < 3) return null
        // strength of the vertical lines at the left and right of each cell and of the horizontal lines at its top and
        // bottom, measured along the inner 60 % of the cell side
        val vL = Array(rowsN) { FloatArray(cols) }
        val vR = Array(rowsN) { FloatArray(cols) }
        val hT = Array(rowsN) { FloatArray(cols) }
        val hB = Array(rowsN) { FloatArray(cols) }
        val valid = Array(rowsN) { BooleanArray(cols) }
        val slackX = 0.2f * px.period // a cell that sticks out a little over the screen edge still counts
        val slackY = 0.2f * py.period
        for (j in 0 until rowsN) {
            for (i in 0 until cols) {
                val x0 = px.offset + (i + i0) * px.period
                val y0 = py.offset + (j + i0) * py.period
                val x1 = x0 + px.period
                val y1 = y0 + py.period
                if (x0 < -slackX || y0 < -slackY || x1 > g.w - 1 + slackX || y1 > g.h - 1 + slackY) continue
                valid[j][i] = true
                val ya = y0 + 0.2f * py.period
                val yb = y1 - 0.2f * py.period
                val xa = x0 + 0.2f * px.period
                val xb = x1 - 0.2f * px.period
                vL[j][i] = lineStrength(e, true, x0, ya, yb)
                vR[j][i] = lineStrength(e, true, x1, ya, yb)
                hT[j][i] = lineStrength(e, false, y0, xa, xb)
                hB[j][i] = lineStrength(e, false, y1, xa, xb)
            }
        }
        val vals = ArrayList<Float>()
        val valsH = ArrayList<Float>()
        for (j in 0 until rowsN) for (i in 0 until cols) if (valid[j][i]) {
            vals.add(vL[j][i])
            valsH.add(hT[j][i])
        }
        // "a real line" = at least 40 % as strong as the strongest lines on this screen (and clearly above the noise)
        val tv = max(9f, 0.4f * topMean(vals, 12))
        val th = max(9f, 0.4f * topMean(valsH, 12))

        // a cell belongs to a board when a line is drawn at one of its sides across AND one of its sides down
        val score = Array(rowsN) { FloatArray(cols) }
        val ok = Array(rowsN) { BooleanArray(cols) }
        for (j in 0 until rowsN) for (i in 0 until cols) {
            if (!valid[j][i]) {
                score[j][i] = -2f
                continue
            }
            ok[j][i] = (vL[j][i] >= tv || vR[j][i] >= tv) && (hT[j][i] >= th || hB[j][i] >= th)
            score[j][i] = if (ok[j][i]) 1f else -1.5f
        }
        trace?.let { t ->
            for (j in 0 until rowsN) t("   " + (0 until cols).joinToString("") { i -> if (!valid[j][i]) "-" else if (ok[j][i]) "#" else "." })
        }
        val rect = bestRect(score) ?: return null
        val (bl, br, bt, bb) = rect
        val c = br - bl + 1
        val r = bb - bt + 1
        if (c < 3 || r < 3 || c > 20 || r > 24) return null
        var goodCells = 0
        for (j in bt..bb) for (i in bl..br) if (ok[j][i]) goodCells++
        if (goodCells < 9 || goodCells < 0.75f * c * r) {
            trace?.invoke("too gappy: $goodCells of ${c * r}")
            return null
        }
        // every line between two cells is drawn along (nearly) the whole board; the outer lines need not be (tic-tac-toe)
        for (m in bl + 1..br) {
            var n = 0
            for (j in bt..bb) if (vL[j][m] >= tv) n++
            if (n < 0.75f * r) {
                trace?.invoke("vertical line $m only on $n of $r rows")
                return null
            }
        }
        for (m in bt + 1..bb) {
            var n = 0
            for (i in bl..br) if (hT[m][i] >= th) n++
            if (n < 0.75f * c) {
                trace?.invoke("horizontal line $m only on $n of $c columns")
                return null
            }
        }
        var left = px.offset + (bl + i0) * px.period
        var top = py.offset + (bt + i0) * py.period
        var perX = px.period
        var perY = py.period
        // exact lines from the board's own rows / columns only
        val sub = Edges(g.w, g.h, e.ex, e.ey)
        val colProf = FloatArray(g.w)
        val rowProf = FloatArray(g.h)
        val yFrom = max(1, top.toInt())
        val yTo = min(g.h - 2, (top + r * perY).toInt())
        val xFrom = max(1, left.toInt())
        val xTo = min(g.w - 2, (left + c * perX).toInt())
        for (y in yFrom..yTo) for (x in 1 until g.w - 1) colProf[x] += sub.ex[y * g.w + x].toFloat()
        for (x in xFrom..xTo) for (y in 1 until g.h - 1) rowProf[y] += sub.ey[y * g.w + x].toFloat()
        // a thick line has an edge on each side: blur until the two sides melt into one peak in the middle of the line
        val rx = refine(blur(colProf, 12), left, perX, c)
        val ry = refine(blur(rowProf, 12), top, perY, r)
        trace?.invoke("refine x: ${left}/${perX} -> ${rx.first}/${rx.second}; y: ${top}/${perY} -> ${ry.first}/${ry.second}; rows $yFrom..$yTo cols $xFrom..$xTo")
        left = rx.first
        perX = rx.second
        top = ry.first
        perY = ry.second
        val right = left + c * perX
        val bottom = top + r * perY
        if ((right - left) < 0.28f * g.w) return null // a board is a main part of the screen, not a corner widget
        return Grid(
            (left / g.w).coerceIn(0f, 1f), (top / g.h).coerceIn(0f, 1f),
            (right / g.w).coerceIn(0f, 1f), (bottom / g.h).coerceIn(0f, 1f), c, r,
        )
    }

    private fun blur(p: FloatArray, passes: Int): FloatArray {
        var cur = p
        repeat(passes) { cur = smooth(cur) }
        return cur
    }

    private fun smooth(p: FloatArray): FloatArray {
        val s = FloatArray(p.size)
        for (i in p.indices) s[i] = (p[max(0, i - 1)] + 2 * p[i] + p[min(p.size - 1, i + 1)]) / 4f
        return s
    }
}
