package com.zirexhub.autoplayer

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Makes the AI's presses land (pure Kotlin).
 *
 * A vision model reads a picture well but guesses pixel positions badly: a button is often missed by 5 to 10 percent of the
 * screen, and the AI then "clicks the button" again and again without anything happening. The on-device OCR knows exactly
 * where every word is. So a press is moved onto the OCR line the AI meant: the line whose text matches the "text" the AI
 * named, or else the button-like line closest to the point it gave.
 */
object Snap {
    /** How far (as a fraction of the screen, x and y alike) a guessed point may be from a word and still count as "that word". */
    private const val NEAR = 0.07f

    private fun letters(s: String) = s.count { it in 'a'..'z' }

    /** Similarity 0..1 of two normalized texts: containment counts as a match, otherwise edit distance. */
    fun similarity(a: String, b: String): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        if (a == b) return 1f
        val shortLen = min(a.length, b.length)
        if (shortLen >= 3 && (a.contains(b) || b.contains(a))) return 0.5f + 0.5f * shortLen / max(a.length, b.length)
        val d = editDistance(a, b)
        return 1f - d.toFloat() / max(a.length, b.length)
    }

    private fun editDistance(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + c)
            }
            prev = cur
        }
        return prev[b.length]
    }

    /** The OCR line the press was meant for, or null when nothing fits. */
    fun target(label: String, x: Float, y: Float, lines: List<TextLine>, aspect: Float): TextLine? {
        val usable = lines.filter {
            val n = Planner.normalize(it.text)
            n.length >= 2 && letters(n) >= 2 && !Hud.isStatic(it, n)
        }
        if (usable.isEmpty()) return null
        val want = Planner.normalize(label)
        if (letters(want) >= 3) {
            var best: TextLine? = null
            var bestScore = 0.62f
            for (ln in usable) {
                val sim = similarity(want, Planner.normalize(ln.text))
                if (sim < 0.62f) continue
                // among equal matches the one nearest to where the AI pointed
                val d = dist(ln.cx, ln.cy, x, y, aspect)
                val score = sim - d * 0.15f
                if (score > bestScore) {
                    bestScore = score
                    best = ln
                }
            }
            if (best != null) return best
        }
        // no (usable) label: the button-like word nearest to the point, or the word the point is already inside of
        var best: TextLine? = null
        var bestD = NEAR
        for (ln in usable) {
            val n = Planner.normalize(ln.text)
            if (n.split(' ').size > 4 || n.any { it in '0'..'9' }) continue // sentences and counters are not what one taps
            val inside = x >= ln.l - 0.01f && x <= ln.r + 0.01f && y >= ln.t - 0.01f && y <= ln.b + 0.01f
            val d = if (inside) 0f else dist(ln.cx, ln.cy, x, y, aspect)
            if (d < bestD) {
                bestD = d
                best = ln
            }
        }
        return best
    }

    private fun dist(ax: Float, ay: Float, bx: Float, by: Float, @Suppress("UNUSED_PARAMETER") aspect: Float): Float {
        val dx = ax - bx
        val dy = ay - by // the model's pointing error is about the same fraction of the width and of the height
        return sqrt(dx * dx + dy * dy)
    }

    /** Taps and long presses of [d] moved onto the words they mean. Returns [d] itself when nothing had to change. */
    fun apply(d: Decision, lines: List<TextLine>, aspect: Float, blocked: List<Zone> = emptyList()): Decision {
        if (lines.isEmpty()) return d
        var changed = false
        val snappedNames = ArrayList<String>()
        val acts = d.actions.map { a ->
            when (a) {
                is GameAction.Tap -> {
                    val t = if (a.exact) null else target(a.label, a.x, a.y, lines, aspect)
                    if (t != null && blocked.none { it.contains(t.cx, t.cy, 0.01f) } && (abs(t.cx - a.x) > 0.004f || abs(t.cy - a.y) > 0.004f)) {
                        changed = true
                        snappedNames.add(t.text.take(20))
                        a.copy(x = t.cx, y = t.cy, label = a.label.ifBlank { t.text })
                    } else a
                }
                is GameAction.LongPress -> {
                    val t = target("", a.x, a.y, lines, aspect)
                    if (t != null && blocked.none { it.contains(t.cx, t.cy, 0.01f) }) {
                        changed = true
                        snappedNames.add(t.text.take(20))
                        a.copy(x = t.cx, y = t.cy)
                    } else a
                }
                else -> a
            }
        }
        if (!changed) return d
        return d.copy(actions = acts, note = d.note + " [press moved onto \"${snappedNames.first()}\"]")
    }
}
