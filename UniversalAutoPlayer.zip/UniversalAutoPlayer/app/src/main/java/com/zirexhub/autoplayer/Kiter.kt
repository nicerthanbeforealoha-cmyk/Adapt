package com.zirexhub.autoplayer

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Where to run, and why. [calm] = nothing dangerous near, [heading] then only leans toward a gem. */
class KitePlan(val heading: Double, val calm: Boolean, val level: Float, val note: String)

/**
 * "Scan the screen, find the enemies, go where it is survivable" (pure Kotlin).
 *
 * The character stands in the middle of the picture. Every enemy found on the screen is turned into a position relative
 * to the character (in screen widths). For each of 16 headings the planner looks where the character would be after a
 * short and a long walk that way and adds up how close the enemies would be there, counting where they will be by then
 * (they walk toward us). Lava and thorn walls add a large penalty. Turning a lot costs a little, so the path stays
 * smooth and does not jitter between two equal ways. The cheapest heading is the survivable gap.
 *
 * With nothing dangerous near it only leans toward the nearest green gem (experience), when the way there is clear.
 */
object Kiter {
    @JvmField var L1 = 0.10
    @JvmField var L2 = 0.24
    @JvmField var L3 = 0.0 // optional third, longer look-ahead (0 = off)

    /** How far an enemy walks toward the character before the character has got to the look-ahead point. */
    @JvmField var CHASE = 0.07

    /** Cost of turning away from the present heading (full turn = this much). */
    @JvmField var INERTIA = 0.35

    /** Keep the present heading when it is within this much of the best one. */
    @JvmField var KEEP = 0.12

    /** Share of the screen width within which enemies count at all. */
    private const val SIGHT = 0.80

    private fun phi(d: Double): Double = min(25.0, 1.0 / (0.02 + d * d)) / 25.0

    fun angleOf(k: Int): Double = k * (2 * PI / Hazards.DIRS)

    private fun rel(b: Blip, aspect: Float): DoubleArray = doubleArrayOf((b.x - Threats.HERO_X).toDouble(), ((b.y - Threats.HERO_Y) * aspect).toDouble())

    /** How much danger is within reach of the character right now (about 1.0 = one enemy next to us). */
    fun level(th: ThreatMap): Float {
        var s = 0.0
        for (e in th.enemies) {
            val r = rel(e, th.aspect)
            val d = sqrt(r[0] * r[0] + r[1] * r[1])
            s += e.weight * exp(-(d / 0.28) * (d / 0.28))
        }
        return s.toFloat()
    }

    fun plan(th: ThreatMap, hz: HazardInfo?, current: Double, hpFrac: Float?, hurt: Boolean): KitePlan? {
        val lvl = level(th)
        val low = hpFrac != null && hpFrac < 0.4f
        val calm = lvl < 0.9f && !hurt && !(low && lvl > 0.4f)
        if (calm) return gemPlan(th, hz, lvl)

        val es = th.enemies.map { rel(it, th.aspect) to it.weight }.filter { it.first[0] * it.first[0] + it.first[1] * it.first[1] < SIGHT * SIGHT }
        if (es.isEmpty()) return null
        val panic = if (low || hurt) 1.4 else 1.0
        // where each enemy will be: a step closer to the character
        val pred = es.map { (p, w) ->
            val d = sqrt(p[0] * p[0] + p[1] * p[1])
            if (d < 1e-6) Triple(p[0], p[1], w)
            else {
                val step = min(CHASE, d)
                Triple(p[0] - p[0] / d * step, p[1] - p[1] / d * step, w)
            }
        }
        val cost = DoubleArray(Hazards.DIRS)
        for (k in 0 until Hazards.DIRS) {
            val a = angleOf(k)
            val ux = cos(a)
            val uy = sin(a)
            var c = 0.0
            for ((ex, ey, w) in pred) {
                val d1 = sqrt((ex - ux * L1) * (ex - ux * L1) + (ey - uy * L1) * (ey - uy * L1))
                val d2 = sqrt((ex - ux * L2) * (ex - ux * L2) + (ey - uy * L2) * (ey - uy * L2))
                c += w * panic * (phi(d1) + phi(d2))
                if (L3 > 0.0) {
                    val d3 = sqrt((ex - ux * L3) * (ex - ux * L3) + (ey - uy * L3) * (ey - uy * L3))
                    c += w * panic * phi(d3)
                }
            }
            if (hz != null) c += 3.0 * hz.danger[k]
            c += INERTIA * Hazards.angDiff(current, a) / PI
            cost[k] = c
        }
        var best = 0
        for (k in 1 until Hazards.DIRS) if (cost[k] < cost[best]) best = k
        // keep the present heading when it is nearly as good: no zig-zag between two equal ways
        var curK = ((current / (2 * PI / Hazards.DIRS)).let { Math.round(it).toInt() } % Hazards.DIRS + Hazards.DIRS) % Hazards.DIRS
        val keep = cost[curK] - cost[best] < KEEP
        val h = if (keep) current else angleOf(best)
        val where = Hazards.angleName(((if (keep) curK else best)))
        return KitePlan(h, false, lvl, "enemies ${es.size} near (level ${"%.1f".format(lvl)}) -> running $where")
    }

    private fun gemPlan(th: ThreatMap, hz: HazardInfo?, lvl: Float): KitePlan? {
        var bestD = 0.5
        var bestA = 0.0
        var found = false
        for (g in th.gems) {
            val r = rel(g, th.aspect)
            val d = sqrt(r[0] * r[0] + r[1] * r[1])
            if (d < 0.05 || d >= bestD) continue
            val a = atan2(r[1], r[0])
            if (hz != null && Hazards.dangerAt(hz, a) >= 0.25f) continue
            // do not walk into a crowd for a gem
            var crowd = 0.0
            for (e in th.enemies) {
                val er = rel(e, th.aspect)
                val dx = er[0] - r[0]
                val dy = er[1] - r[1]
                crowd += exp(-(dx * dx + dy * dy) / (0.15 * 0.15))
            }
            if (crowd > 0.6) continue
            bestD = d
            bestA = a
            found = true
        }
        return if (found) KitePlan(bestA, true, lvl, "calm, going for a gem") else null
    }
}
