package com.zirexhub.autoplayer

/** What the offline bot knows about the screen right now. The AI is asked only when this says it is worth it. */
class PlannerSignals(
    /** A game that keeps moving on its own and is played with a joystick / drags (the offline bot is good at those). */
    val realtime: Boolean,
    /** A popup or menu with choices is on top (level-up cards, pacts, shops). */
    val popup: Boolean,
    /** Steps in a row where nothing real happened. */
    val idleSteps: Int,
    /** A game-over screen. */
    val dead: Boolean,
)

/**
 * When is the AI worth a call? (pure Kotlin)
 *
 * A call takes seconds and a free key allows only a handful per minute, so the AI cannot steer a real-time game step by step
 * (by the time its answer arrives the picture has moved on). What it is good at is understanding: which of three upgrade cards
 * is best, what a strange screen wants, why the bot is stuck. So:
 *  - a slow game (puzzle, idle, menu, turn based, or one that is not recognised yet): the AI LEADS, whenever a call is allowed;
 *  - a real-time game the offline bot already plays: the AI is a COPILOT, asked when a popup with choices appears and when the
 *    bot has been stuck for a while. The offline bot does the moving and fighting.
 */
class CopilotPolicy(private val clock: () -> Long = { System.currentTimeMillis() }) {
    private var lastAsk = Long.MIN_VALUE / 2
    private var popupAsked = false

    fun wantAdvice(s: PlannerSignals): String? {
        if (!s.popup) popupAsked = false
        if (!s.realtime) return "this is a slow or unknown screen: you lead"
        if (s.popup && !popupAsked) {
            popupAsked = true
            return "a popup with choices appeared in a real-time game"
        }
        if (s.idleSteps >= 6 && clock() - lastAsk >= STUCK_EVERY_MS) return "the offline bot has been stuck for a while"
        return null
    }

    fun asked() {
        lastAsk = clock()
    }

    companion object {
        const val STUCK_EVERY_MS = 20_000L
    }
}

/**
 * Tells when the opponent has had time to answer after the AI's move (pure Kotlin).
 *
 * Found in the chess log: the AI moved, 1.8 s later the next question went out, the AI saw only its own move and answered
 * "wait for black's response" (a whole call, 3.7 s, and one of the few a free key has per day). So after a move the next
 * question waits until at least [MIN_MS] have passed and the screen has been still for two steps in a row (the opponent
 * moved and the animation is over), or [MAX_MS] have passed, whatever the screen does.
 */
class TurnSettle(private val clock: () -> Long) {
    private var pressAt = Long.MIN_VALUE / 2
    private var still = 0

    /** Call on every step with the change since the last step. */
    fun step(change: Float?) {
        still = if (change != null && change < STILL) still + 1 else 0
    }

    /** The AI's move just went out. */
    fun pressed() {
        pressAt = clock()
        still = 0
    }

    fun settled(): Boolean {
        val since = clock() - pressAt
        return since >= MAX_MS || (since >= MIN_MS && still >= 2)
    }

    companion object {
        const val STILL = 0.001f
        const val MIN_MS = 2500L
        const val MAX_MS = 6000L
    }
}

/** The answer of one AI call (or the reason it failed). [snapshot] is whatever the caller needs to judge if it is still current. */
class Reply(val reason: String, val decision: Decision?, val error: Throwable?, val tookMs: Long, val snapshot: Any? = null)

/** What to do on this step. */
sealed class Turn {
    /** The AI's answer is fresh enough: do what it says. */
    class Use(val decision: Decision) : Turn()

    /** Start an AI call now ([hold] = also stand still this step, the screen is not going anywhere). */
    class Ask(val reason: String, val hold: Boolean) : Turn()

    /** Stand still: the AI is about to answer about a screen that does not change. */
    object Hold : Turn()

    /** The offline bot plays this step. */
    class Fill(val why: String) : Turn()
}

/**
 * The state machine behind the hybrid brain (pure Kotlin, so it can be tested with a pretend AI).
 *
 * The AI call runs in the background ([deliver] is called from that thread), so the game never waits for the network. When
 * the answer comes, [next] gives it to the caller once, unless the screen has moved on since the question was asked
 * (the caller's [stale] check). Between calls the offline bot plays. The [RateGuard] keeps the calls inside the limit.
 */
class CopilotCore(
    private val clock: () -> Long,
    val guard: RateGuard,
    private val policy: CopilotPolicy,
    private val log: (String) -> Unit,
) {
    /**
     * The caller can hold the next question back (for example: a move on a board was just made and the opponent has not
     * answered yet, so a screenshot now would only make the AI say "wait", and burn one of the few calls a free key has).
     */
    var gate: (PlannerSignals) -> Boolean = { true }

    @Volatile private var reply: Reply? = null
    private var flying = false
    private var flightStart = 0L
    private var errors = 0
    private var loggedOut = false

    var asks = 0
        private set
    var used = 0
        private set
    var dropped = 0
        private set
    var fills = 0
        private set
    var holds = 0
        private set

    val inFlight: Boolean get() = flying

    /** Called from the AI thread. */
    fun deliver(r: Reply) {
        reply = r
    }

    private fun mayHold(sig: PlannerSignals, change: Float?): Boolean =
        change != null && change < 0.03f && (!sig.realtime || sig.popup)

    fun next(sig: PlannerSignals, change: Float?, stale: (Reply) -> Boolean): Turn {
        val r = reply
        if (r != null) {
            reply = null
            flying = false
            val err = r.error
            if (err != null) {
                when (err) {
                    is RateLimitException -> {
                        guard.limited(err.info)
                        log("AI limit (${err.info.kind}, wait ${err.info.retryAfterMs / 1000}s, limit ${err.info.limitValue}): ${err.message?.take(300)}")
                    }
                    is AuthException -> throw err
                    is FatalConfigException -> throw err
                    is InterruptedException -> throw err
                    else -> {
                        errors++
                        guard.blockFor((2000L * errors).coerceAtMost(20_000L))
                        log("AI error #$errors: ${err.javaClass.simpleName}: ${err.message?.take(300)}")
                    }
                }
            } else {
                errors = 0
                guard.success()
                val d = r.decision
                if (d != null) {
                    if (stale(r)) {
                        dropped++
                        log("AI answer dropped after ${r.tookMs}ms: the screen changed since the question (${d.note.take(80)})")
                    } else {
                        used++
                        log("AI answer used after ${r.tookMs}ms (${r.reason}): ${d.label} | ${d.note.take(100)}")
                        return Turn.Use(d)
                    }
                }
            }
        }
        val now = clock()
        if (flying) {
            if (now - flightStart > TIMEOUT_MS) {
                flying = false
                log("AI call took more than ${TIMEOUT_MS / 1000}s: given up")
                guard.blockFor(5000L)
            } else if (now - flightStart < HOLD_MS && mayHold(sig, change)) {
                holds++
                return Turn.Hold
            } else {
                fills++
                return Turn.Fill("AI is thinking")
            }
        }
        if (guard.outForToday) {
            if (!loggedOut) {
                loggedOut = true
                log("AI calls are over for this run: ${guard.why}. The offline bot plays from now on (press STOP and PLAY later to try the AI again).")
            }
            fills++
            return Turn.Fill(guard.why)
        }
        val wait = guard.waitMs()
        if (wait > 0L) {
            fills++
            return Turn.Fill("next AI call in ${(wait + 999) / 1000}s")
        }
        val reason = policy.wantAdvice(sig)
        if (reason == null) {
            fills++
            return Turn.Fill("the AI is asked at popups and when stuck")
        }
        if (!gate(sig)) {
            fills++
            return Turn.Fill("waiting for the opponent to answer")
        }
        flying = true
        flightStart = now
        guard.started()
        policy.asked()
        asks++
        // A popup that has just appeared in a real-time game: stand still this one step even though the picture just changed
        // (it changed BECAUSE the popup appeared). If the game keeps moving afterwards it was no popup: the next step lets go.
        return Turn.Ask(reason, if (sig.realtime) sig.popup else mayHold(sig, change))
    }

    companion object {
        const val HOLD_MS = 12_000L
        const val TIMEOUT_MS = 30_000L
    }
}
