package com.zirexhub.autoplayer

import android.graphics.Bitmap
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.roundToInt

/** Helpers for comparing and encoding screenshots. */
object FrameTools {
    private const val THUMB = 32

    class Encoded(val base64: String, val width: Int, val height: Int)

    /** Tiny grayscale version of the frame, used to measure how much the screen changed. */
    fun thumb(b: Bitmap): IntArray {
        val s = Bitmap.createScaledBitmap(b, THUMB, THUMB, true)
        val px = IntArray(THUMB * THUMB)
        s.getPixels(px, 0, THUMB, 0, 0, THUMB, THUMB)
        if (s !== b) s.recycle()
        return IntArray(px.size) { i ->
            val c = px[i]
            (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
        }
    }

    /** Mean absolute brightness difference between two thumbnails, 0.0 (same) .. 1.0 (opposite). */
    fun diff(a: IntArray?, b: IntArray): Float {
        if (a == null || a.size != b.size) return 1f
        var sum = 0L
        for (i in a.indices) sum += abs(a[i] - b[i])
        return sum / (a.size * 255f)
    }

    /** Downscale (longest side <= maxSide) and JPEG + base64 encode for the API. */
    fun encode(b: Bitmap, maxSide: Int, quality: Int): Encoded {
        val scale = minOf(1f, maxSide.toFloat() / maxOf(b.width, b.height))
        val w = (b.width * scale).roundToInt().coerceAtLeast(1)
        val h = (b.height * scale).roundToInt().coerceAtLeast(1)
        val s = if (scale < 1f) Bitmap.createScaledBitmap(b, w, h, true) else b
        val out = ByteArrayOutputStream()
        s.compress(Bitmap.CompressFormat.JPEG, quality, out)
        if (s !== b) s.recycle()
        return Encoded(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP), w, h)
    }
}
