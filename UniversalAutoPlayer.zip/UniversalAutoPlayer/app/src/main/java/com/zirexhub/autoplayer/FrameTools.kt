package com.zirexhub.autoplayer

import android.graphics.Bitmap
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.roundToInt

/** Helpers for comparing and encoding screenshots. */
object FrameTools {
    private const val THUMB = 32

    class Encoded(val base64: String, val width: Int, val height: Int)

    /**
     * Scales [b] down to w x h by halving first. One big bilinear step (1080 px wide down to 64) only samples a few
     * pixels of the picture, so small moving sprites make quiet pictures flicker. Halving averages them instead, which is
     * what the movement and "is it frozen" thresholds were measured on. The caller recycles the result when it is not [b].
     */
    fun shrink(b: Bitmap, w: Int, h: Int): Bitmap {
        var cur = b
        try {
            while (cur.width >= w * 2 && cur.height >= h * 2) {
                val next = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
                if (cur !== b) cur.recycle()
                cur = next
            }
            val out = Bitmap.createScaledBitmap(cur, w, h, true)
            if (cur !== b && out !== cur) cur.recycle()
            return out
        } catch (t: Throwable) {
            if (cur !== b) cur.recycle()
            return Bitmap.createScaledBitmap(b, w, h, true)
        }
    }

    /** Tiny grayscale version of the frame, used to measure how much the screen changed. */
    fun thumb(b: Bitmap): IntArray {
        val s = shrink(b, THUMB, THUMB)
        val px = IntArray(THUMB * THUMB)
        s.getPixels(px, 0, THUMB, 0, 0, THUMB, THUMB)
        if (s !== b) s.recycle()
        return IntArray(px.size) { i ->
            val c = px[i]
            (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
        }
    }

    /** Grayscale picture [w] wide (height follows the screen shape), used to see how the scene moves. */
    fun gray(b: Bitmap, w: Int = 64): Gray {
        val h = (b.height.toFloat() * w / b.width).roundToInt().coerceIn(16, 200)
        val s = shrink(b, w, h)
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        if (s !== b) s.recycle()
        for (i in px.indices) {
            val c = px[i]
            px[i] = (((c shr 16) and 0xFF) * 77 + ((c shr 8) and 0xFF) * 150 + (c and 0xFF) * 29) shr 8
        }
        return Gray(w, h, px)
    }

    /** Mean absolute brightness difference between two thumbnails, 0.0 (same) .. 1.0 (opposite). */
    fun diff(a: IntArray?, b: IntArray): Float {
        if (a == null || a.size != b.size) return 1f
        var sum = 0L
        for (i in a.indices) sum += abs(a[i] - b[i])
        return sum / (a.size * 255f)
    }

    /** Downscale (longest side <= maxSide) and JPEG + base64 encode for the API. */
    fun encode(b: Bitmap, maxSide: Int, quality: Int): Encoded {
        val scale = minOf(1f, maxSide.toFloat() / maxOf(b.width, b.height))
        val w = (b.width * scale).roundToInt().coerceAtLeast(1)
        val h = (b.height * scale).roundToInt().coerceAtLeast(1)
        val s = if (scale < 1f) Bitmap.createScaledBitmap(b, w, h, true) else b
        val out = ByteArrayOutputStream()
        s.compress(Bitmap.CompressFormat.JPEG, quality, out)
        if (s !== b) s.recycle()
        return Encoded(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP), w, h)
    }
}
