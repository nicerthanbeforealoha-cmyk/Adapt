package com.zirexhub.autoplayer

/** One place for the version so the app screen and the debug log always agree. */
object BuildInfo {
    const val VERSION = "2.9"
    const val CODE = 11
}
