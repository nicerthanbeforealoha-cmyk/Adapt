package com.zirexhub.autoplayer

import android.graphics.Bitmap
import android.os.SystemClock

/**
 * AI mode that never stands still.
 *
 * The AI brain plays when the provider lets it. When the provider says "too many calls" (free keys allow only a few per
 * minute and per day), when it is busy, or when its answer cannot be read, the offline bot plays that step instead, and the
 * [RateGuard] keeps the AI calls inside the provider's limit. Found with a Google AI Studio free key: gemini-3.8-flash allows
 * 5 calls a minute and 20 a day, the old loop made a call every second and then only waited and failed.
 *
 * Setup problems (wrong key, wrong model) are NOT hidden: they are thrown to the service, which stops and says what is wrong.
 */
class HybridBrain(ai: AiBrain, private val offlineFactory: () -> Brain) : Brain {
    var ai: AiBrain = ai
        private set
    private var offline: Brain? = null
    private val guard = RateGuard { SystemClock.elapsedRealtime() }
    private var aiErrors = 0
    private var loggedDaily = false
    private var aiCalls = 0
    private var offlineSteps = 0

    /** The service repaired the model name: keep the offline helper and the learned limits, swap only the AI. */
    fun replaceAi(newAi: AiBrain) {
        try {
            ai.close()
        } catch (_: Throwable) {
        }
        ai = newAi
        aiErrors = 0
    }

    private fun off(): Brain = offline ?: offlineFactory().also { offline = it }

    private fun fill(frame: Bitmap, ctx: AgentContext, why: String): Decision {
        offlineSteps++
        val d = off().decide(frame, ctx)
        return d.copy(note = "AI paused ($why). Offline bot: ${d.note}")
    }

    override fun decide(frame: Bitmap, ctx: AgentContext): Decision {
        if (guard.outForToday) {
            if (!loggedDaily) {
                loggedDaily = true
                DebugLog.add("AI calls are over for this run: ${guard.why}. The offline bot plays from now on (press STOP and PLAY later to try the AI again).")
            }
            return fill(frame, ctx, guard.why)
        }
        val wait = guard.waitMs()
        if (wait > 0L) return fill(frame, ctx, "next AI call in ${(wait + 999) / 1000}s")
        guard.started()
        try {
            val d = ai.decide(frame, ctx)
            guard.success()
            aiErrors = 0
            aiCalls++
            if (aiCalls == 1 || aiCalls % 20 == 0) DebugLog.add("AI call #$aiCalls ok (offline steps so far $offlineSteps, pace ${guard.gapMs / 1000}s)")
            return d
        } catch (e: RateLimitException) {
            guard.limited(e.info)
            DebugLog.add("AI limit (${e.info.kind}, wait ${e.info.retryAfterMs / 1000}s, limit ${e.info.limitValue}): ${e.message?.take(300)}")
            return fill(frame, ctx, if (guard.outForToday) guard.why else "provider limit, ${guard.why}")
        } catch (e: AuthException) {
            throw e
        } catch (e: FatalConfigException) {
            throw e
        } catch (e: InterruptedException) {
            throw e
        } catch (e: Exception) {
            // server busy, no network, an answer that cannot be read: do not stall, the offline bot plays this step
            aiErrors++
            guard.blockFor((2000L * aiErrors).coerceAtMost(20_000L))
            DebugLog.add("AI error #$aiErrors: ${e.javaClass.simpleName}: ${e.message?.take(300)}")
            return fill(frame, ctx, "AI error: ${e.message?.take(60)}")
        }
    }

    override fun onActionRefused() {
        try {
            offline?.onActionRefused()
            ai.onActionRefused()
        } catch (_: Throwable) {
        }
    }

    override fun close() {
        try {
            ai.close()
        } catch (_: Throwable) {
        }
        try {
            offline?.close()
        } catch (_: Throwable) {
        }
    }
}
