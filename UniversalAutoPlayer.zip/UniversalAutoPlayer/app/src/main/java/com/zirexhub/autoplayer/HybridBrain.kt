package com.zirexhub.autoplayer

import android.graphics.Bitmap
import android.os.SystemClock
import java.util.concurrent.Executors

/**
 * AI mode that is useful and never stands still.
 *
 * Found with a free Google AI Studio key: the old AI mode asked the AI for EVERY step. Each call blocked the whole bot for
 * 2 to 5 seconds (steps of 1.4 s instead of 0.6 s), the answer described a screen that had already moved on, the AI guessed
 * button positions several percent off and then "clicked the button" again and again without anything happening, and a free key
 * allows only 5 to 10 calls a minute anyway. Now:
 *
 *  - the AI call runs in the BACKGROUND; the offline bot keeps playing at full speed meanwhile ([CopilotCore]);
 *  - the AI is asked where it helps: it LEADS slow or unknown screens (menus, puzzles, idle games) and is a COPILOT in
 *    real-time games the offline bot already plays (popups with choices, being stuck), see [CopilotPolicy];
 *  - the screenshot goes with the OCR word list and exact positions, and the AI's presses are moved onto the words they mean
 *    ([Snap]); a press the AI chose that did nothing is reported back, and never repeated more than twice;
 *  - an answer is used only if the screen it was about is still there (checked around the press point);
 *  - the [RateGuard] keeps the calls inside the provider's limit.
 *
 * Setup problems (wrong key, wrong model) are NOT hidden: they are thrown to the service, which stops and says what is wrong.
 */
class HybridBrain(ai: AiBrain, private val offline: SmartBrain) : Brain {
    var ai: AiBrain = ai
        private set

    private val clock = { SystemClock.elapsedRealtime() }
    private val guard = RateGuard(clock)
    private val core = CopilotCore(clock, guard, CopilotPolicy(clock)) { DebugLog.add(it) }
    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "ai-call").apply { isDaemon = true } }

    /** What the screen looked like when the question was asked. */
    private class Snapshot(val gray: Gray, val thumb: IntArray, val lines: List<TextLine>, val boardGray: Gray? = null, val grid: Grid? = null)

    private var lastPress: Pair<String, String>? = null // description, label (the AI's press of the previous step)
    private val failed = ArrayList<String>()
    private val failCount = HashMap<String, Int>()
    private var steps = 0
    private var boardSeenAt = Long.MIN_VALUE / 2 // when the last screenshot sent to the AI held a board of cells
    private val settle = TurnSettle(clock)

    private var askedSnap: Snapshot? = null // what the question in flight is about
    private val board = BoardTracker(clock) { DebugLog.add(it) }
    private val engine = ChessEngine(clock) // used by the AI thread only

    /**
     * Set by the service: the bot's own chip covers part of the board, so the AI cannot see those squares (it guessed black's
     * back rank in a real game). The service moves the chip away and says whether it did. Asked at most every 15 s.
     */
    @Volatile var onBoardCovered: ((Zone) -> Boolean)? = null
    private var chipMovedAt = Long.MIN_VALUE / 2

    init {
        // After a move in a slow game, do not ask again before the opponent has answered and the screen is calm.
        core.gate = { sig -> sig.realtime || settle.settled() }
    }

    /** The service repaired the model name: keep the offline helper and the learned limits, swap only the AI. */
    fun replaceAi(newAi: AiBrain) {
        newAi.dragAsTaps = board.dragAsTaps
        ai = newAi
    }

    private fun judgeLastPress(change: Float?) {
        val p = lastPress ?: return
        lastPress = null
        // "nothing happened" is a change of exactly 0.000; a real chess move (a pawn two squares forward) measured 0.0025 in the
        // log of a real game, so 0.01 called every successful board move a failure
        if (change != null && change < NO_EFFECT) {
            val n = (failCount[p.second] ?: 0) + 1
            failCount[p.second] = n
            if (failed.size >= 5) failed.removeAt(0)
            failed.add(p.first + ": the screen did not change")
            DebugLog.add("AI press had no effect (#$n): ${p.first}")
        } else {
            failCount.remove(p.second)
        }
    }

    /**
     * After a board move: did a piece really move? Found in a real chess log: a drag only SELECTED the pawn, and the screen
     * change (0.0025) looked exactly like a move, so the AI believed it had played and "played" it again and again. Judged only
     * once the opponent has had time to answer ([TurnSettle]), by what happened on the two squares ([BoardTracker]).
     */
    private fun judgePending(frame: Bitmap) {
        if (!board.due(settle.settled())) return
        try {
            val gray = FrameTools.gray(frame, BOARD_W, BOARD_H)
            val before = askedSnap?.thumb
            val change = if (before != null) FrameTools.diff(before, FrameTools.thumb(frame)) else 0f
            board.judge(gray, change)
        } catch (t: Throwable) {
            board.cancel()
            DebugLog.add("board move check failed: ${t.message}")
        }
        ai.dragAsTaps = board.dragAsTaps
    }

    /** The offline bot's own decision for this step, with a note on why the AI is not (yet) steering. */
    private fun standby(base: Decision, why: String): Decision {
        // On a board game screen the offline bot stays out of it: it would poke at RESTART / UNDO / HINT between the AI's moves
        val pokes = base.actions.any { it is GameAction.Tap || it is GameAction.LongPress || it is GameAction.Swipe || it is GameAction.Back }
        if (pokes && clock() - boardSeenAt < BOARD_MEMORY_MS) return hold("board game, waiting for the AI ($why)")
        return base.copy(note = "${base.note} [AI standby: $why]")
    }

    override fun decide(frame: Bitmap, ctx: AgentContext): Decision {
        steps++
        settle.step(ctx.changeScore)
        judgeLastPress(ctx.changeScore)
        judgePending(frame)
        // The offline bot always looks and thinks first (so it keeps learning the game and knows what kind of screen this is);
        // its decision is used unless the AI has something better for this step.
        val base = offline.decide(frame, ctx)
        val sig = offline.signals()
        val gray = FrameTools.gray(frame)
        return when (val turn = core.next(sig, ctx.changeScore) { r -> isStale(r, frame, gray) }) {
            is Turn.Use -> useAnswer(turn.decision, base, sig)
            is Turn.Ask -> {
                launch(frame, ctx, turn.reason)
                if (turn.hold) hold("AI asked: ${turn.reason}") else standby(base, "AI asked: ${turn.reason}")
            }
            is Turn.Hold -> hold("waiting for the AI's answer, the screen is still")
            is Turn.Fill -> standby(base, turn.why)
        }
    }

    /** Stand still this step. The offline bot's decision is cancelled: it never happened. */
    private fun hold(why: String): Decision {
        offline.onActionRefused()
        return Decision(GameAction.Wait(350L), why, "wait(350ms)")
    }

    private fun useAnswer(d: Decision, base: Decision, sig: PlannerSignals): Decision {
        val acts = d.actions
        val pressesSomething = acts.any { it is GameAction.Tap || it is GameAction.LongPress || it is GameAction.Swipe }
        // in a real-time game the offline bot plays the moving: an AI "wait" or "finish" there would only waste a step
        if (sig.realtime && !pressesSomething) return standby(base, "AI saw: ${d.note.take(60)}")
        val play = d.play
        val move = if (play != null) {
            board.moveCells(play.cells[0], play.cells[1], play.cells[2], play.cells[3], askedSnap?.grid, askedSnap?.boardGray)
        } else {
            board.moveFrom(acts, askedSnap?.grid, askedSnap?.boardGray)
        }
        if (move != null) {
            if (play != null) board.played(play.afterKey)
            if (board.blocked(move)) {
                DebugLog.add("AI repeated a board move that failed twice (\"${move.text}\"): the offline bot plays instead")
                return standby(base, "AI repeated a failed move")
            }
            board.begin(move)
            lastPress = null // the board check judges this press, not the "did the screen change" test
            settle.pressed()
            offline.onActionRefused() // the offline bot's own decision for this step is replaced
            // ONE move per reply: a second move would be played without seeing the opponent's answer
            val keep = if (move.byTaps) acts.take(2) else acts.take(1)
            return d.copy(actions = keep, note = if (play != null) d.note else "AI: ${d.note}", verifyTap = d.verifyTap || move.byTaps)
        }
        val tap = acts.firstOrNull() as? GameAction.Tap
        if (tap != null) {
            fun name(t: GameAction.Tap) = t.label.ifBlank { "${(t.x * 100).toInt()},${(t.y * 100).toInt()}" }
            val taps = acts.filterIsInstance<GameAction.Tap>()
            val key = taps.joinToString(" > ") { name(it) } // a move on a board is two presses: judge them together
            if ((failCount[key] ?: 0) >= 2) {
                DebugLog.add("AI repeated a press that failed twice (\"$key\"): the offline bot plays instead")
                return standby(base, "AI repeated a failed press")
            }
            val shown = taps.joinToString(" then ") { "\"${name(it)}\" at (${(it.x * 100).toInt()}%,${(it.y * 100).toInt()}%)" }
            lastPress = Pair("tapped $shown", key)
        }
        val drag = acts.firstOrNull() as? GameAction.Swipe
        if (tap == null && drag != null && !sig.realtime) {
            // a piece dragged on a board: report it too when it did nothing (in real-time games swipes are the joystick)
            fun p(v: Float) = (v * 100).toInt()
            val key = "drag ${p(drag.x1)},${p(drag.y1)}>${p(drag.x2)},${p(drag.y2)}"
            if ((failCount[key] ?: 0) >= 2) {
                DebugLog.add("AI repeated a drag that failed twice (\"$key\"): the offline bot plays instead")
                return standby(base, "AI repeated a failed drag")
            }
            lastPress = Pair("dragged from (${p(drag.x1)}%,${p(drag.y1)}%) to (${p(drag.x2)}%,${p(drag.y2)}%)", key)
        }
        if (pressesSomething && !sig.realtime) {
            settle.pressed()
        }
        offline.onActionRefused() // the offline bot's own decision for this step is replaced
        return d.copy(note = "AI: ${d.note}", verifyTap = d.verifyTap || tap != null)
    }

    /** Is the answer about a screen that is gone? The press point is checked, like the service does right before pressing. */
    private fun isStale(r: Reply, frame: Bitmap, gray: Gray): Boolean {
        val snap = r.snapshot as? Snapshot ?: return false
        val a = r.decision?.actions?.firstOrNull() ?: return false
        return when (a) {
            is GameAction.Tap -> Motion.regionDiff(snap.gray, gray, a.x, a.y) > STALE_REGION_DIFF
            is GameAction.LongPress -> Motion.regionDiff(snap.gray, gray, a.x, a.y) > STALE_REGION_DIFF
            is GameAction.Swipe, GameAction.Back -> FrameTools.diff(snap.thumb, FrameTools.thumb(frame)) > 0.15f
            else -> false
        }
    }

    /** Starts one AI call in the background. The frame can be recycled right after this returns. */
    private fun launch(frame: Bitmap, ctx: AgentContext, reason: String) {
        val t0 = clock()
        try {
            val lines = offline.scan(frame)
            val aspect = frame.height.toFloat() / frame.width
            val boardGray = FrameTools.gray(frame, BOARD_W, BOARD_H)
            val found = try {
                // the bot's own chip is painted over the picture: its zone is told to the finder, so a board row hidden under it still counts
                GridFinder.find(boardGray, ctx.blocked)
            } catch (_: Throwable) {
                null
            }
            val thumb = FrameTools.thumb(frame)
            val grid = board.gridFor(found, thumb)
            if (grid != null) {
                boardSeenAt = clock()
                DebugLog.add("board found: $grid")
            } else if (clock() - boardSeenAt > MOVE_LOG_KEEP_MS) {
                board.newGame() // no board for a long time: another game
            }
            ai.dragAsTaps = board.dragAsTaps
            val cover = onBoardCovered
            if (grid != null && cover != null && clock() - chipMovedAt > CHIP_RETRY_MS && ctx.blocked.any { it.intersects(grid.l, grid.t, grid.r, grid.b) }) {
                chipMovedAt = clock()
                val moved = try {
                    cover(Zone(grid.l, grid.t, grid.r, grid.b))
                } catch (_: Throwable) {
                    false
                }
                if (moved) {
                    DebugLog.add("my chip covered part of the board: moved it off the board, looking again before asking the AI")
                    core.deliver(Reply(reason, Decision(GameAction.Wait(500L), "moving my chip off the board", "wait(500ms)"), null, clock() - t0, null))
                    return
                }
            }
            val ctx2 = AgentContext(
                ctx.goal, ctx.history, ctx.changeScore, ctx.stuckCount, ctx.maxActions, ctx.blocked, lines, reason, failed.toList() + (if (grid != null) board.notes else emptyList()), grid,
                if (grid != null) board.moveLog else emptyList(), !board.dragAsTaps,
            )
            val req = ai.prepare(frame, ctx2)
            val snap = Snapshot(FrameTools.gray(frame), thumb, lines, if (grid != null) boardGray else null, grid)
            askedSnap = snap
            val worker = ai
            val failedCells = board.failedCells
            val seenKeys = board.seenKeys
            val selectedCell = board.selected
            DebugLog.add("AI asked (${reason}); model ${worker.modelNow}, thinking ${worker.thinkingFor(grid != null)}${if (grid != null) ", moves by ${if (worker.dragAsTaps) "taps" else "drag"}" else ""}; ${lines.size} words sent, prepared in ${clock() - t0}ms")
            exec.execute {
                val reply = try {
                    var d = Snap.apply(worker.call(req), lines, aspect, ctx.blocked)
                    // chess: the AI READ the board, the engine chooses the move
                    if (grid != null && d.read != null) d = withEngine(d, grid, boardGray, ctx.blocked, failedCells, seenKeys, selectedCell)
                    Reply(reason, d, null, clock() - t0, snap)
                } catch (t: Throwable) {
                    Reply(reason, null, t, clock() - t0, snap)
                }
                core.deliver(reply)
            }
        } catch (t: Throwable) {
            core.deliver(Reply(reason, null, t, clock() - t0, null))
        }
    }

    /**
     * The AI read a chess board ([Decision.read]): the engine plays the move instead of the AI's own, which is only the backup
     * for a reading that cannot be used (the reason is logged). Runs on the AI thread, the game does not wait for it.
     */
    private fun withEngine(
        d: Decision, grid: Grid, picture: Gray, blocked: List<Zone>, failedCells: List<IntArray>, seen: Set<String>, selected: Pair<Int, Int>?,
    ): Decision {
        val read = d.read ?: return d
        val t = clock()
        val out = try {
            BoardPlan.plan(read, grid, picture, blocked, failedCells, seen, selected, engine, ENGINE_MS)
        } catch (e: Throwable) {
            DebugLog.add("chess engine failed: ${e.javaClass.simpleName}: ${e.message?.take(120)}")
            return d
        }
        val plan = out.plan
        if (plan == null) {
            DebugLog.add("chess engine not used: ${out.why}. The AI's own move is played: ${d.label}")
            return d
        }
        DebugLog.add("${plan.note}; ${clock() - t}ms. The AI's own move would have been: ${d.label}")
        return d.copy(actions = plan.actions, label = plan.label, note = plan.note, verifyTap = true, play = ChessPlay(plan.cells, plan.afterKey))
    }

    override fun onActionRefused() {
        lastPress = null
        board.cancel() // a refused press never happened: there is no move to judge
        try {
            offline.onActionRefused()
        } catch (_: Throwable) {
        }
    }

    override fun close() {
        try {
            exec.shutdownNow()
        } catch (_: Throwable) {
        }
        try {
            ai.close()
        } catch (_: Throwable) {
        }
        try {
            offline.close()
        } catch (_: Throwable) {
        }
    }

    companion object {
        private const val STALE_REGION_DIFF = 8f
        private const val NO_EFFECT = 0.001f
        private const val BOARD_MEMORY_MS = 25_000L // how long the offline bot stays out of a board screen
        private const val MOVE_LOG_KEEP_MS = 60_000L
        private const val BOARD_W = 180
        private const val BOARD_H = 420
        private const val ENGINE_MS = 1800L
        private const val CHIP_RETRY_MS = 15_000L
    }
}
