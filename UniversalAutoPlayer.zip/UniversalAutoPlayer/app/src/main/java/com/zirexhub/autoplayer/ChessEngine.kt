package com.zirexhub.autoplayer

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * The chess engine (v2). An alpha-beta searcher in the style of the strong open engines, small enough for a phone:
 *  - iterative deepening with aspiration windows, principal-variation search, a transposition table (Zobrist hash),
 *  - null-move pruning, late-move reductions and pruning, futility / reverse-futility pruning, check extensions,
 *  - move ordering: hash move, captures by value and static exchange, killers, counter moves, history,
 *  - quiescence search with static exchange pruning and check evasions,
 *  - draws by repetition and the fifty-move rule (also against the positions of the game so far, see [best]'s `past`),
 *  - a tapered evaluation: material and square values, bishop pair, pawn structure (isolated, doubled, passed, connected),
 *    knight outposts, mobility, rooks on open files and on the seventh, king shelter and king attackers, "mop-up" to finish
 *    won endings, drawn material,
 *  - a time manager (stops early when the move is clear, thinks longer when the position is hard),
 *  - pondering: [startPonder] searches while the opponent is thinking; the next [best] starts with a warm table.
 * It is single threaded in the sense that only one search runs at a time (a ponder search is stopped first).
 */
class ChessEngine(private val clock: () -> Long, ttBits: Int = 19) {

    companion object {
        const val INF = 1_000_000
        const val MATE = 30_000
        const val MAX_DEPTH = 64
        const val MAX_PLY = 100
        const val REPEAT_PENALTY = 40
        const val PROMOTE_NOW = 40

        val VALUE = intArrayOf(0, 100, 320, 330, 500, 900, 20_000)
        private val SEE_VAL = intArrayOf(0, 100, 325, 340, 500, 975, 20_000)
        private val EMPTY_LONGS = LongArray(0)

        private val LMR = Array(MAX_DEPTH + 1) { d ->
            IntArray(65) { n -> if (d < 3 || n < 2) 0 else (0.75 + Math.log(d.toDouble()) * Math.log(n.toDouble()) / 2.25).toInt() }
        }

        private val PASS_MG = intArrayOf(0, 0, 6, 12, 25, 45, 75, 0)
        private val PASS_EG = intArrayOf(0, 0, 10, 25, 50, 85, 140, 0)
        private val SAFETY = IntArray(40) { min(220, it * it / 4) }
        private val CENTRE_DIST = IntArray(64) { sq -> val f = sq and 7; val r = sq shr 3; min(max(3 - f, f - 4), 3) + min(max(3 - r, r - 4), 3) }
    }

    private val tt = ttBits
    private val ttMask = (1 shl ttBits) - 1
    private var ttKey = LongArray(0)
    private var ttData = LongArray(0)
    private var age = 0

    @Volatile private var abort = false
    private val lock = Any()
    private var ponderToken = 0
    private var ponderThread: Thread? = null

    private var stop = false
    private var hardDeadline = 0L
    private var nodes = 0L
    private var pos = ChessPos()
    private var past = EMPTY_LONGS
    private var contempt = 15
    private var iterDepth = 0

    private val pvTable = Array(MAX_PLY + 2) { IntArray(MAX_PLY + 2) }
    private val pvLen = IntArray(MAX_PLY + 2)
    private val moveBuf = Array(MAX_PLY + 2) { IntArray(256) }
    private val scoreBuf = Array(MAX_PLY + 2) { IntArray(256) }
    private val quiets = Array(MAX_PLY + 2) { IntArray(64) }
    private val killers = Array(MAX_PLY + 2) { IntArray(2) }
    private val history = Array(2) { IntArray(4096) }
    private val counter = Array(2) { IntArray(4096) }
    private val moveStack = IntArray(MAX_PLY + 2)

    private var rootMv = IntArray(256)
    private var rootSc = IntArray(256)
    private var rootAdj = IntArray(256)
    private var rootN = 0
    private var iterBest = 0

    private val seeGain = IntArray(40)
    private val seeSq = IntArray(40)
    private val seePc = IntArray(40)

    private val wPawns = IntArray(10) // pawn ranks (as bits) per file, files 1..8 (0 and 9 are the guard files)
    private val bPawns = IntArray(10)
    private val zoneW = BooleanArray(64) // the white king and the squares around it
    private val zoneB = BooleanArray(64)

    // ------------------------------------------------------------------ public API

    /**
     * The best move for the side to move, or null when there is none (checkmate, stalemate) or every move is in [exclude]
     * (as UCI text, "e2e4"). [avoid] holds position keys ([ChessPos.key]) seen before: a move into one costs a little, so a
     * game does not shuffle back and forth. [past] holds the hashes ([ChessPos.zobrist]) of the positions of the game before
     * [root]: reaching one again counts as a draw in the search. [contempt]: how much a draw is worth less than an even
     * position for the engine (positive = it avoids draws, negative = it accepts them).
     */
    fun best(
        root: ChessPos,
        timeMs: Long,
        maxDepth: Int = 40,
        exclude: Set<String> = emptySet(),
        avoid: Set<String> = emptySet(),
        past: LongArray = EMPTY_LONGS,
        contempt: Int = 15,
    ): ChessChoice? {
        ponderToken++
        abort = true
        synchronized(lock) {
            abort = false
            ponderThread = null
            return run(root, timeMs, maxDepth, exclude, avoid, past, contempt, false)
        }
    }

    /** Starts thinking on [root] (usually the position after our move, the opponent to move) in the background, for at most [maxMs]. */
    fun startPonder(root: ChessPos, past: LongArray = EMPTY_LONGS, maxMs: Long = 8000, contempt: Int = 15) {
        stopPonder()
        val r = root.copy()
        val token = ++ponderToken
        val t = Thread({
            try {
                synchronized(lock) {
                    if (token == ponderToken && !abort) run(r, maxMs, MAX_DEPTH, emptySet(), emptySet(), past, contempt, true)
                }
            } catch (_: Throwable) {
            }
        }, "chess-ponder")
        t.isDaemon = true
        ponderThread = t
        t.start()
    }

    /** Stops a background search (returns when it has stopped). */
    fun stopPonder() {
        if (ponderThread == null) return
        ponderToken++
        abort = true
        synchronized(lock) { abort = false }
        ponderThread = null
    }

    fun isPondering(): Boolean = ponderThread?.isAlive == true

    /** Forgets what the table holds (a new game). */
    fun newGame() {
        stopPonder()
        synchronized(lock) {
            if (ttKey.isNotEmpty()) java.util.Arrays.fill(ttKey, 0L)
            for (h in history) java.util.Arrays.fill(h, 0)
            for (c in counter) java.util.Arrays.fill(c, 0)
        }
    }

    // ------------------------------------------------------------------ driver

    private fun run(
        root: ChessPos, timeMs: Long, maxDepth: Int, exclude: Set<String>, avoid: Set<String>, pastIn: LongArray, contemptIn: Int,
        ponder: Boolean,
    ): ChessChoice? {
        val start = clock()
        if (ttKey.isEmpty()) {
            ttKey = LongArray(1 shl tt)
            ttData = LongArray(1 shl tt)
        }
        age = (age + 1) and 63
        stop = false
        nodes = 0
        past = pastIn.copyOf().also { java.util.Arrays.sort(it) }
        contempt = contemptIn
        for (k in killers) { k[0] = 0; k[1] = 0 }
        for (h in history) for (i in h.indices) h[i] = h[i] / 2
        pos = root.copy()
        val p = pos
        val all = IntArray(256)
        val n = p.legal(all)
        rootN = 0
        for (i in 0 until n) {
            if (ChessPos.uci(all[i]) in exclude) continue
            rootMv[rootN++] = all[i]
        }
        if (rootN == 0) return null
        if (rootN == 1 && !ponder) return ChessChoice(rootMv[0], 0, 0, 0, intArrayOf(rootMv[0]))
        // root penalties: a promotion now is better than later, a move into a position seen before costs a little
        for (i in 0 until rootN) {
            val m = rootMv[i]
            var adj = 0
            if ((m shr 12) and 7 != 0) adj += PROMOTE_NOW
            if (avoid.isNotEmpty()) {
                p.make(m)
                if (p.key() in avoid) adj -= REPEAT_PENALTY
                p.unmake(m)
            }
            rootAdj[i] = adj
        }
        // first order: the hash move, then captures, then the rest
        val ttm = probeMove(p.hash)
        for (i in 0 until rootN) rootSc[i] = orderScore(p, rootMv[i], ttm, 0)
        sortRoot(-1)

        hardDeadline = if (ponder) start + timeMs else start + timeMs
        var soft = (timeMs * 0.55).toLong()
        var bestMove = rootMv[0]
        var bestScore = 0
        var doneDepth = 0
        var bestPv = intArrayOf(bestMove)
        var prevScore = 0
        var changed = 0
        val limit = min(maxDepth, MAX_DEPTH)
        for (depth in 1..limit) {
            iterDepth = depth
            iterBest = 0
            var alpha = -INF
            var beta = INF
            var delta = 18
            if (depth >= 5) {
                alpha = max(-INF, prevScore - delta)
                beta = min(INF, prevScore + delta)
            }
            var score: Int
            while (true) {
                score = searchRoot(depth, alpha, beta)
                if (stop) break
                if (score <= alpha && alpha > -INF) {
                    beta = (alpha + beta) / 2
                    alpha = max(-INF, score - delta)
                } else if (score >= beta && beta < INF) {
                    beta = min(INF, score + delta)
                } else {
                    break
                }
                delta += delta / 2 + 4
                if (delta > 600) { alpha = -INF; beta = INF }
            }
            if (stop) {
                // a half finished depth still counts when a move already beat the window
                if (iterBest != 0 && doneDepth > 0) {
                    if (iterBest != bestMove) changed++
                    bestMove = iterBest
                    bestScore = max(bestScore, rootBestScore())
                    bestPv = pvFromTable(bestMove)
                }
                break
            }
            if (iterBest != 0) {
                if (iterBest != bestMove && doneDepth > 0) changed++
                bestMove = iterBest
                bestScore = score
                bestPv = pvFromTable(bestMove)
            }
            doneDepth = depth
            sortRoot(bestMove)
            // time: stop when another depth will not finish; think longer when the move is unstable or the score fell
            val elapsed = clock() - start
            if (!ponder) {
                if (abs(bestScore) > MATE - 100 && depth >= 4) break
                var allow = soft
                if (depth >= 5 && (bestScore < prevScore - 30 || changed > 0)) allow = min((timeMs * 0.8).toLong(), soft * 3 / 2)
                if (elapsed >= allow) break
                if (rootN == 2 && depth >= 12 && abs(bestScore) > 600) break
            }
            if (ponder && elapsed >= timeMs) break
            prevScore = bestScore
            changed = 0
        }
        return ChessChoice(bestMove, bestScore, doneDepth, nodes, bestPv)
    }

    private fun rootBestScore(): Int {
        for (i in 0 until rootN) if (rootMv[i] == iterBest) return rootSc[i]
        return -INF
    }

    private fun pvFromTable(first: Int): IntArray {
        val len = pvLen[0]
        if (len <= 0 || pvTable[0][0] != first) return intArrayOf(first)
        return IntArray(len) { pvTable[0][it] }
    }

    /** Sorts the root moves by their last score, [first] (if given) in front. */
    private fun sortRoot(first: Int) {
        for (i in 1 until rootN) {
            val m = rootMv[i]
            val sc = rootSc[i]
            val a = rootAdj[i]
            var j = i - 1
            while (j >= 0 && rootSc[j] < sc) {
                rootMv[j + 1] = rootMv[j]; rootSc[j + 1] = rootSc[j]; rootAdj[j + 1] = rootAdj[j]
                j--
            }
            rootMv[j + 1] = m; rootSc[j + 1] = sc; rootAdj[j + 1] = a
        }
        if (first >= 0) {
            var idx = -1
            for (i in 0 until rootN) if (rootMv[i] == first) { idx = i; break }
            if (idx > 0) {
                val m = rootMv[idx]; val sc = rootSc[idx]; val a = rootAdj[idx]
                for (j in idx downTo 1) { rootMv[j] = rootMv[j - 1]; rootSc[j] = rootSc[j - 1]; rootAdj[j] = rootAdj[j - 1] }
                rootMv[0] = m; rootSc[0] = sc; rootAdj[0] = a
            }
        }
    }

    private fun searchRoot(depth: Int, alphaIn: Int, beta: Int): Int {
        var alpha = alphaIn
        var best = -INF
        val p = pos
        pvLen[0] = 0
        for (i in 0 until rootN) {
            val m = rootMv[i]
            p.make(m)
            moveStack[0] = m
            var s: Int
            if (i == 0) {
                s = -search(depth - 1, -beta, -alpha, 1, true)
            } else {
                var r = 0
                if (depth >= 3 && i >= 4 && !isTactical(p, m)) r = 1 + (if (i >= 10) 1 else 0)
                s = -search(depth - 1 - r, -alpha - 1, -alpha, 1, true)
                if (s > alpha && r > 0) s = -search(depth - 1, -alpha - 1, -alpha, 1, true)
                if (s > alpha && s < beta) s = -search(depth - 1, -beta, -alpha, 1, true)
            }
            p.unmake(m)
            if (stop) return best
            s += rootAdj[i]
            rootSc[i] = s
            if (s > best) {
                best = s
                if (s > alpha) {
                    alpha = s
                    iterBest = m
                    pvTable[0][0] = m
                    val cl = pvLen[1]
                    for (k in 1 until cl) pvTable[0][k] = pvTable[1][k]
                    pvLen[0] = max(1, cl)
                    if (s >= beta) break
                }
            }
        }
        return best
    }

    /** After a move was made: was it a capture/promotion (the capture is gone from the board, so ask the undo data)? */
    private fun isTactical(p: ChessPos, m: Int): Boolean = (m shr 12) and 7 != 0 || p.inCheck(p.side) || capturedBy(p)

    private fun capturedBy(p: ChessPos): Boolean = p.lastCapture() != 0

    // ------------------------------------------------------------------ transposition table

    private fun probeMove(key: Long): Int {
        if (ttKey.isEmpty()) return 0
        val i = (key ushr (64 - tt)).toInt()
        if (ttKey[i] != key) return 0
        return (ttData[i] and 0x7FFF).toInt()
    }

    private fun ttStore(key: Long, move: Int, score: Int, depth: Int, bound: Int, ply: Int) {
        val i = (key ushr (64 - tt)).toInt()
        val old = ttData[i]
        val oldKey = ttKey[i]
        val oldDepth = ((old shr 31) and 0xFF).toInt()
        val oldAge = ((old shr 41) and 63).toInt()
        var mv = move
        if (oldKey == key) {
            if (mv == 0) mv = (old and 0x7FFF).toInt() // keep the earlier move
        } else if (oldKey != 0L && oldAge == age && oldDepth > depth + 2) {
            return
        }
        val sc = when {
            score >= MATE - 150 -> score + ply
            score <= -MATE + 150 -> score - ply
            else -> score
        }
        ttKey[i] = key
        ttData[i] = (mv and 0x7FFF).toLong() or ((sc + 32768).toLong() shl 15) or ((depth.coerceIn(0, 255)).toLong() shl 31) or (bound.toLong() shl 39) or (age.toLong() shl 41)
    }

    // ------------------------------------------------------------------ search

    private fun drawScore(ply: Int): Int = if (ply and 1 == 0) -contempt else contempt

    private fun isDraw(p: ChessPos, ply: Int): Boolean {
        if (p.half >= 100) return true
        if (p.half >= 4 && p.repeated()) return true
        if (p.half >= ply + 1 && past.isNotEmpty() && java.util.Arrays.binarySearch(past, p.hash) >= 0) return true
        return false
    }

    private fun hasNonPawn(p: ChessPos, color: Int): Boolean {
        val b = p.b
        for (i in 0 until 64) {
            val v = b[i] * color
            if (v in 2..5) return true
        }
        return false
    }

    private fun search(depthIn: Int, alphaIn: Int, betaIn: Int, ply: Int, nullOk: Boolean): Int {
        nodes++
        if ((nodes and 1023L) == 0L && (abort || clock() >= hardDeadline)) stop = true
        if (stop) return 0
        pvLen[ply] = ply
        val p = pos
        var alpha = alphaIn
        var beta = betaIn
        val pvNode = betaIn - alphaIn > 1
        if (isDraw(p, ply)) return drawScore(ply)
        if (ply >= MAX_PLY - 1) return evaluate(p)
        val mated = -MATE + ply
        if (alpha < mated) alpha = mated
        val mating = MATE - ply - 1
        if (beta > mating) beta = mating
        if (alpha >= beta) return alpha

        val me = p.side
        val inCheck = p.inCheck(me)
        var depth = depthIn
        if (inCheck && ply < iterDepth * 2 + 6) depth++
        if (depth <= 0) return qsearch(alpha, beta, ply, 0)

        val key = p.hash
        val ti = (key ushr (64 - tt)).toInt()
        var ttMove = 0
        if (ttKey[ti] == key) {
            val d = ttData[ti]
            ttMove = (d and 0x7FFF).toInt()
            val tDepth = ((d shr 31) and 0xFF).toInt()
            val bound = ((d shr 39) and 3).toInt()
            if (tDepth >= depth && !pvNode) {
                var s = ((d shr 15) and 0xFFFF).toInt() - 32768
                if (s >= MATE - 150) s -= ply else if (s <= -MATE + 150) s += ply
                if (bound == 3 || (bound == 1 && s >= beta) || (bound == 2 && s <= alpha)) return s
            }
        }

        val staticEval = if (inCheck) -INF else evaluate(p)
        if (!pvNode && !inCheck) {
            // reverse futility: far above beta already
            if (depth <= 6 && staticEval - 85 * depth >= beta && abs(beta) < MATE - 200) return staticEval
            // razoring: far below alpha, only a capture can save it
            if (depth <= 2 && staticEval + 250 + 120 * depth <= alpha) {
                val q = qsearch(alpha, beta, ply, 0)
                if (stop) return 0
                if (q <= alpha) return q
            }
            // null move: pass; if still above beta the position is too good
            if (nullOk && depth >= 3 && staticEval >= beta && hasNonPawn(p, me)) {
                val r = 3 + depth / 4 + min((staticEval - beta) / 200, 3)
                p.makeNull()
                moveStack[ply] = 0
                val s = -search(depth - 1 - r, -beta, -beta + 1, ply + 1, false)
                p.unmakeNull()
                if (stop) return 0
                if (s >= beta) return if (s >= MATE - 200) beta else s
            }
        }
        if (ttMove == 0 && depth >= 4) depth-- // internal iterative reduction

        val buf = moveBuf[ply]
        val sc = scoreBuf[ply]
        val n = p.gen(buf, false)
        val counterMove = if (ply > 0) counter[if (me > 0) 0 else 1][moveStack[ply - 1] and 4095] else 0
        for (i in 0 until n) sc[i] = orderScore(p, buf[i], ttMove, ply, counterMove)
        val sideIdx = if (me > 0) 0 else 1
        var best = -INF
        var bestMove = 0
        var legal = 0
        var quietCount = 0
        val alphaOrig = alpha
        val q = quiets[ply]
        for (i in 0 until n) {
            var bi = i
            for (j in i + 1 until n) if (sc[j] > sc[bi]) bi = j
            if (bi != i) {
                val tm = buf[i]; buf[i] = buf[bi]; buf[bi] = tm
                val ts = sc[i]; sc[i] = sc[bi]; sc[bi] = ts
            }
            val m = buf[i]
            val promo = (m shr 12) and 7
            val to = (m shr 6) and 63
            val isCap = p.b[to] != 0 || (abs(p.b[m and 63]) == 1 && to == p.ep && (m and 7) != (to and 7))
            val quiet = !isCap && promo == 0
            val badCapture = isCap && sc[i] < -500_000
            // pruning of moves that are unlikely to matter (never the first move, never in check, never when mate is in the air)
            if (!pvNode && !inCheck && legal > 0 && best > -MATE + 200) {
                if (quiet && depth <= 5 && quietCount >= 3 + depth * depth) continue
                if (badCapture && depth <= 3) continue
            }
            p.make(m)
            if (p.inCheck(me)) {
                p.unmake(m)
                continue
            }
            legal++
            val gives = p.inCheck(p.side)
            if (!pvNode && !inCheck && !gives && legal > 1 && quiet && depth <= 4 && best > -MATE + 200 && staticEval + 100 + 90 * depth <= alpha) {
                p.unmake(m)
                quietCount++
                continue
            }
            moveStack[ply] = m and 4095
            val newDepth = depth - 1
            var s: Int
            if (legal == 1) {
                s = -search(newDepth, -beta, -alpha, ply + 1, true)
            } else {
                var r = 0
                if (depth >= 3 && quiet && !gives) {
                    r = LMR[min(depth, MAX_DEPTH)][min(legal, 64)]
                    if (!pvNode) r++
                    if (inCheck) r--
                    if (m == killers[ply][0] || m == killers[ply][1] || m == counterMove) r--
                    val hv = history[sideIdx][(m and 63) * 64 + to]
                    if (hv > 3000) r-- else if (hv < -3000) r++
                    if (r < 0) r = 0
                    if (r > newDepth - 1) r = max(0, newDepth - 1)
                } else if (depth >= 3 && badCapture) {
                    r = 1
                }
                s = -search(newDepth - r, -alpha - 1, -alpha, ply + 1, true)
                if (s > alpha && r > 0) s = -search(newDepth, -alpha - 1, -alpha, ply + 1, true)
                if (s > alpha && s < beta) s = -search(newDepth, -beta, -alpha, ply + 1, true)
            }
            p.unmake(m)
            if (stop) return 0
            if (s > best) {
                best = s
                bestMove = m
                if (s > alpha) {
                    alpha = s
                    pvTable[ply][ply] = m
                    val cl = pvLen[ply + 1]
                    for (k in ply + 1 until cl) pvTable[ply][k] = pvTable[ply + 1][k]
                    pvLen[ply] = max(ply + 1, cl)
                    if (alpha >= beta) {
                        if (quiet) {
                            if (killers[ply][0] != m) { killers[ply][1] = killers[ply][0]; killers[ply][0] = m }
                            val bonus = min(depth * depth, 400)
                            bump(history[sideIdx], (m and 63) * 64 + to, bonus)
                            for (k in 0 until quietCount) {
                                val qm = q[k]
                                bump(history[sideIdx], (qm and 63) * 64 + ((qm shr 6) and 63), -bonus)
                            }
                            if (ply > 0) counter[sideIdx][moveStack[ply - 1] and 4095] = m
                        }
                        break
                    }
                }
            }
            if (quiet && quietCount < 63) q[quietCount++] = m
        }
        if (legal == 0) return if (inCheck) -MATE + ply else drawScore(ply)
        val bound = if (best >= beta) 1 else if (best > alphaOrig) 3 else 2
        ttStore(key, bestMove, best, depth, bound, ply)
        return best
    }

    private fun bump(h: IntArray, idx: Int, bonus: Int) {
        h[idx] += bonus - h[idx] * abs(bonus) / 16384
    }

    private fun qsearch(alphaIn: Int, beta: Int, ply: Int, qd: Int): Int {
        nodes++
        if ((nodes and 1023L) == 0L && (abort || clock() >= hardDeadline)) stop = true
        if (stop) return 0
        pvLen[ply] = ply
        val p = pos
        if (isDraw(p, ply)) return drawScore(ply)
        if (ply >= MAX_PLY - 1) return evaluate(p)
        var alpha = alphaIn
        val me = p.side
        val inCheck = p.inCheck(me)
        val evasions = inCheck && qd < 4
        var best: Int
        if (!inCheck) {
            val stand = evaluate(p)
            if (stand >= beta) return stand
            if (stand > alpha) alpha = stand
            best = stand
        } else {
            best = -INF
        }
        val standPat = if (inCheck) -INF else best
        val buf = moveBuf[ply]
        val sc = scoreBuf[ply]
        val n = p.gen(buf, !evasions)
        for (i in 0 until n) sc[i] = qScore(p, buf[i])
        var legal = 0
        for (i in 0 until n) {
            var bi = i
            for (j in i + 1 until n) if (sc[j] > sc[bi]) bi = j
            if (bi != i) {
                val tm = buf[i]; buf[i] = buf[bi]; buf[bi] = tm
                val ts = sc[i]; sc[i] = sc[bi]; sc[bi] = ts
            }
            val m = buf[i]
            val promo = (m shr 12) and 7
            if (!evasions || legal > 0) {
                if (!inCheck) {
                    val victim = abs(p.b[(m shr 6) and 63])
                    // a capture that cannot bring the score up to alpha even with a bonus, or that loses material
                    if (promo == 0 && standPat + SEE_VAL[victim] + 200 <= alpha) continue
                    if (sc[i] < -500_000) continue
                } else if (sc[i] < -500_000 && qd >= 1) {
                    continue
                }
            }
            p.make(m)
            if (p.inCheck(me)) {
                p.unmake(m)
                continue
            }
            legal++
            val s = -qsearch(-beta, -alpha, ply + 1, qd + 1)
            p.unmake(m)
            if (stop) return 0
            if (s > best) {
                best = s
                if (s > alpha) {
                    alpha = s
                    if (alpha >= beta) break
                }
            }
        }
        if (evasions && legal == 0) return -MATE + ply
        if (inCheck && best == -INF) return evaluate(p)
        return best
    }

    // ------------------------------------------------------------------ move ordering and exchange values

    private fun qScore(p: ChessPos, m: Int): Int {
        val from = m and 63
        val to = (m shr 6) and 63
        val promo = (m shr 12) and 7
        val victim = abs(p.b[to])
        val attacker = abs(p.b[from])
        var s = 1_000_000 + victim * 16 - attacker
        if (victim == 0 && attacker == 1 && (from and 7) != (to and 7) && to == p.ep) s = 1_000_000 + 16 - 1
        if (promo != 0) s += 500_000 + promo
        if (victim == 0 && promo == 0 && !(attacker == 1 && to == p.ep)) return 100_000 - attacker // evasions: quiet moves after captures
        if (attacker > victim && SEE_VAL[attacker] > SEE_VAL[victim] && see(p, m) < 0) s -= 2_000_000
        return s
    }

    private fun orderScore(p: ChessPos, m: Int, ttMove: Int, ply: Int, counterMove: Int = 0): Int {
        if (m == ttMove) return 2_000_000
        val from = m and 63
        val to = (m shr 6) and 63
        val promo = (m shr 12) and 7
        val b = p.b
        val victim = abs(b[to])
        val attacker = abs(b[from])
        val epCap = victim == 0 && attacker == 1 && (from and 7) != (to and 7) && to == p.ep
        if (victim != 0 || epCap || promo != 0) {
            var s = 1_000_000 + (if (epCap) 1 else victim) * 16 - attacker
            if (promo == 5) s += 500_000 else if (promo != 0) return -100_000 + promo
            if (attacker > 1 && SEE_VAL[attacker] > SEE_VAL[if (epCap) 1 else victim] && see(p, m) < 0) s -= 2_000_000
            return s
        }
        if (ply < MAX_PLY) {
            if (m == killers[ply][0]) return 900_000
            if (m == killers[ply][1]) return 800_000
        }
        if (m == counterMove) return 700_000
        return history[if (p.side > 0) 0 else 1][from * 64 + to]
    }

    /** Static exchange: what the side to move gains (centipawns) by playing the capture [m] and exchanging on that square. */
    private fun see(p: ChessPos, m: Int): Int {
        val b = p.b
        val from = m and 63
        val to = (m shr 6) and 63
        val promo = (m shr 12) and 7
        var victim = abs(b[to])
        if (victim == 0 && abs(b[from]) == 1 && (from and 7) != (to and 7)) victim = 1
        var gain = SEE_VAL[victim]
        var onSq = SEE_VAL[abs(b[from])]
        if (promo != 0) {
            gain += SEE_VAL[promo] - 100
            onSq = SEE_VAL[promo]
        }
        var d = 0
        seeGain[0] = gain
        var removed = 0
        seeSq[removed] = from; seePc[removed] = b[from]; removed++
        b[from] = 0
        var side = -p.side
        while (d < 30) {
            val a = leastAttacker(b, to, side)
            if (a < 0) break
            d++
            seeGain[d] = onSq - seeGain[d - 1]
            onSq = SEE_VAL[abs(b[a])]
            seeSq[removed] = a; seePc[removed] = b[a]; removed++
            b[a] = 0
            side = -side
        }
        while (d > 0) {
            seeGain[d - 1] = -max(-seeGain[d - 1], seeGain[d])
            d--
        }
        for (i in removed - 1 downTo 0) b[seeSq[i]] = seePc[i]
        return seeGain[0]
    }

    private fun leastAttacker(b: IntArray, sq: Int, side: Int): Int {
        for (s in ChessTables.PAT[if (side > 0) 1 else 0][sq]) if (b[s] == side) return s
        val n = 2 * side
        for (s in ChessTables.KN[sq]) if (b[s] == n) return s
        val rays = ChessTables.RAYS
        val bi = 3 * side
        var d = 1
        while (d < 8) {
            for (s in rays[sq * 8 + d]) {
                val v = b[s]
                if (v != 0) { if (v == bi) return s; break }
            }
            d += 2
        }
        val ro = 4 * side
        d = 0
        while (d < 8) {
            for (s in rays[sq * 8 + d]) {
                val v = b[s]
                if (v != 0) { if (v == ro) return s; break }
            }
            d += 2
        }
        val qu = 5 * side
        d = 0
        while (d < 8) {
            for (s in rays[sq * 8 + d]) {
                val v = b[s]
                if (v != 0) { if (v == qu) return s; break }
            }
            d++
        }
        val k = 6 * side
        for (s in ChessTables.KG[sq]) if (b[s] == k) return s
        return -1
    }

    // ------------------------------------------------------------------ evaluation

    /** The value of the position in centipawns from the point of view of the side to move. */
    fun evaluate(p: ChessPos): Int {
        val b = p.b
        var mg = p.mg
        var eg = p.eg
        val ph = if (p.phase > 24) 24 else p.phase
        val rays = ChessTables.RAYS
        val wp = wPawns
        val bp = bPawns
        java.util.Arrays.fill(wp, 0)
        java.util.Arrays.fill(bp, 0)
        var wN = 0; var wB = 0; var wR = 0; var wQ = 0
        var bN = 0; var bB = 0; var bR = 0; var bQ = 0
        var wBsq = 0; var bBsq = 0 // colour (0/1) of the last bishop's square
        for (sq in 0 until 64) {
            val v = b[sq]
            if (v == 0) continue
            when (v) {
                1 -> wp[(sq and 7) + 1] = wp[(sq and 7) + 1] or (1 shl (sq shr 3))
                -1 -> bp[(sq and 7) + 1] = bp[(sq and 7) + 1] or (1 shl (sq shr 3))
                2 -> wN++
                -2 -> bN++
                3 -> { wB++; wBsq = ((sq shr 3) + (sq and 7)) and 1 }
                -3 -> { bB++; bBsq = ((sq shr 3) + (sq and 7)) and 1 }
                4 -> wR++
                -4 -> bR++
                5 -> wQ++
                -5 -> bQ++
            }
        }
        var wPawnCount = 0
        var bPawnCount = 0
        for (f in 1..8) { wPawnCount += Integer.bitCount(wp[f]); bPawnCount += Integer.bitCount(bp[f]) }
        // drawn material: no pawns and nothing to mate with
        if (wPawnCount + bPawnCount == 0 && wR + bR + wQ + bQ == 0) {
            val wm = wN + wB
            val bm = bN + bB
            if ((wm <= 1 && bm <= 1) || (wm == 0 && bB == 0 && bN <= 2) || (bm == 0 && wB == 0 && wN <= 2)) return 0
        }
        val wk = p.kingSq(1)
        val bk = p.kingSq(-1)
        // king zones (the king and the squares around it) for the attack count
        var wDanger = 0; var bDanger = 0 // danger to the white / black king
        var wAtt = 0; var bAtt = 0 // number of pieces attacking the white / black king's zone
        if (wk >= 0) { zoneW[wk] = true; for (s in ChessTables.KG[wk]) zoneW[s] = true }
        if (bk >= 0) { zoneB[bk] = true; for (s in ChessTables.KG[bk]) zoneB[s] = true }
        // pieces
        for (sq in 0 until 64) {
            val v = b[sq]
            if (v == 0) continue
            val f = sq and 7
            val r = sq shr 3
            val white = v > 0
            val t = if (white) v else -v
            val sgn = if (white) 1 else -1
            when (t) {
                1 -> {
                    val rr = if (white) r else 7 - r // rank from the pawn's own side
                    val own = if (white) wp else bp
                    val enemy = if (white) bp else wp
                    val fi = f + 1
                    var smg = 0
                    var seg = 0
                    // doubled: another own pawn behind
                    val behind = if (white) own[fi] and ((1 shl r) - 1) else own[fi] and (0xFF shl (r + 1) and 0xFF)
                    if (behind != 0) { smg -= 10; seg -= 18 }
                    // isolated
                    if (own[fi - 1] == 0 && own[fi + 1] == 0) { smg -= 12; seg -= 16 }
                    // passed: no enemy pawn ahead on this or the neighbouring files
                    val aheadMask = if (white) (0xFF shl (r + 1)) and 0xFF else (1 shl r) - 1
                    if ((enemy[fi - 1] or enemy[fi] or enemy[fi + 1]) and aheadMask == 0) {
                        smg += PASS_MG[rr]
                        seg += PASS_EG[rr]
                        val stop1 = sq + 8 * sgn
                        if (stop1 in 0..63 && b[stop1] != 0 && (b[stop1] > 0) != white) { smg -= PASS_MG[rr] / 3; seg -= PASS_EG[rr] / 3 } // blocked
                        // king proximity in the ending
                        val ownK = if (white) wk else bk
                        val oppK = if (white) bk else wk
                        val promoSq = (if (white) 56 else 0) + f
                        if (ownK >= 0 && oppK >= 0) seg += (dist(oppK, promoSq) - dist(ownK, promoSq)) * 3 * (rr - 1).coerceAtLeast(0) / 2
                    }
                    // protected / side by side with a friend
                    val friends = own[fi - 1] or own[fi + 1]
                    val linkMask = if (white) (1 shl r) or (1 shl (r - 1)) else (1 shl r) or (1 shl (r + 1))
                    if (friends and linkMask != 0) { smg += 4 + rr; seg += 5 + rr }
                    mg += sgn * smg
                    eg += sgn * seg
                }
                2 -> {
                    var cnt = 0
                    var hit = 0
                    val ez = if (white) zoneB else zoneW
                    for (s in ChessTables.KN[sq]) {
                        val o = b[s]
                        if (o == 0 || (o > 0) != white) cnt++
                        if (ez[s]) hit += 2
                    }
                    mg += sgn * (cnt - 4) * 4
                    eg += sgn * (cnt - 4) * 4
                    // outpost: advanced, supported by a pawn, no enemy pawn can chase it
                    val rr = if (white) r else 7 - r
                    if (rr in 3..5 && f in 1..6) {
                        val own = if (white) wp else bp
                        val enemy = if (white) bp else wp
                        val fi = f + 1
                        val aheadMask = if (white) (0xFF shl (r + 1)) and 0xFF else (1 shl r) - 1
                        val chased = (enemy[fi - 1] or enemy[fi + 1]) and aheadMask
                        val supported = (own[fi - 1] or own[fi + 1]) and (if (white) 1 shl (r - 1) else 1 shl (r + 1))
                        if (chased == 0 && supported != 0) { mg += sgn * 22; eg += sgn * 14 }
                    }
                    if (hit > 0) { if (white) { bDanger += hit; bAtt++ } else { wDanger += hit; wAtt++ } }
                }
                3, 4, 5 -> {
                    var cnt = 0
                    var hit = 0
                    val ez = if (white) zoneB else zoneW
                    var d = if (t == 3) 1 else 0
                    val step = if (t == 5) 1 else 2
                    while (d < 8) {
                        for (s in rays[sq * 8 + d]) {
                            val o = b[s]
                            if (o == 0 || (o > 0) != white) {
                                cnt++
                                if (ez[s]) hit += if (t == 5) 4 else if (t == 4) 3 else 2
                            }
                            if (o != 0) break
                        }
                        d += step
                    }
                    when (t) {
                        3 -> { mg += sgn * (cnt - 6) * 4; eg += sgn * (cnt - 6) * 5 }
                        4 -> {
                            mg += sgn * (cnt - 7) * 2; eg += sgn * (cnt - 7) * 4
                            val own = if (white) wp else bp
                            val enemy = if (white) bp else wp
                            val fi = f + 1
                            if (own[fi] == 0) {
                                if (enemy[fi] == 0) { mg += sgn * 22; eg += sgn * 12 } else { mg += sgn * 10; eg += sgn * 6 }
                            }
                            val rr = if (white) r else 7 - r
                            val eKing = if (white) bk else wk
                            if (rr == 6 && eKing >= 0 && (if (white) eKing shr 3 else 7 - (eKing shr 3)) >= 7) { mg += sgn * 18; eg += sgn * 22 }
                        }
                        else -> { mg += sgn * (cnt - 13); eg += sgn * (cnt - 13) * 2 }
                    }
                    if (hit > 0) { if (white) { bDanger += hit; bAtt++ } else { wDanger += hit; wAtt++ } }
                }
            }
        }
        if (wk >= 0) { zoneW[wk] = false; for (s in ChessTables.KG[wk]) zoneW[s] = false }
        if (bk >= 0) { zoneB[bk] = false; for (s in ChessTables.KG[bk]) zoneB[s] = false }
        // bishop pair
        if (wB >= 2) { mg += 30; eg += 45 }
        if (bB >= 2) { mg -= 30; eg -= 45 }
        // king: shelter and attackers (middle game only)
        if (wk >= 0) mg += shelter(wp, bp, wk, true)
        if (bk >= 0) mg -= shelter(bp, wp, bk, false)
        if (wAtt >= 2 || (wAtt == 1 && bQ > 0 && wDanger >= 5)) mg -= SAFETY[min(wDanger, 39)] / (if (bQ == 0) 2 else 1)
        if (bAtt >= 2 || (bAtt == 1 && wQ > 0 && bDanger >= 5)) mg += SAFETY[min(bDanger, 39)] / (if (wQ == 0) 2 else 1)
        // opposite coloured bishops (and nothing else but pawns) draw a lot
        if (wB == 1 && bB == 1 && wN + bN + wR + bR + wQ + bQ == 0 && wBsq != bBsq) eg /= 2
        var score = (mg * ph + eg * (24 - ph)) / 24
        // mop-up: a side that is far ahead in material and the other has no pawns drives the king to the edge
        val wNp = wN * 325 + wB * 340 + wR * 500 + wQ * 975
        val bNp = bN * 325 + bB * 340 + bR * 500 + bQ * 975
        if (wk >= 0 && bk >= 0) {
            if (wNp - bNp >= 450 && bPawnCount == 0) score += mopUp(wk, bk)
            else if (bNp - wNp >= 450 && wPawnCount == 0) score -= mopUp(bk, wk)
        }
        score += if (p.side > 0) 10 else -10 // the move
        return if (p.side > 0) score else -score
    }

    private fun dist(a: Int, b: Int): Int = max(abs((a and 7) - (b and 7)), abs((a shr 3) - (b shr 3)))

    private fun mopUp(winner: Int, loser: Int): Int {
        val manhattan = abs((winner and 7) - (loser and 7)) + abs((winner shr 3) - (loser shr 3))
        return CENTRE_DIST[loser] * 12 + (14 - manhattan) * 5
    }

    /** King shelter for the king of [white] on [k]: pawns in front of it (mg value, positive = good for that king). */
    private fun shelter(own: IntArray, enemy: IntArray, k: Int, white: Boolean): Int {
        val kr = k shr 3
        val rr = if (white) kr else 7 - kr
        if (rr > 1) return 0
        val kf = k and 7
        var s = 0
        for (f in max(0, kf - 1)..min(7, kf + 1)) {
            val mask = own[f + 1]
            var dist = -1
            if (white) {
                var r = kr + 1
                while (r < 8) { if (mask and (1 shl r) != 0) { dist = r - kr - 1; break }; r++ }
            } else {
                var r = kr - 1
                while (r >= 0) { if (mask and (1 shl r) != 0) { dist = kr - 1 - r; break }; r-- }
            }
            s += when {
                dist < 0 -> if (enemy[f + 1] == 0) -30 else -20
                dist == 0 -> 8
                dist == 1 -> 2
                else -> -8
            }
        }
        return s
    }
}
