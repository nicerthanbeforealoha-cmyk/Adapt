package com.zirexhub.autoplayer

import kotlin.math.max
import kotlin.math.min

/** Finds vivid, button-shaped colour regions in a small pixel grid. Pure Kotlin, no Android. */
object Blobs {

    fun find(px: IntArray, gw: Int, gh: Int): List<Blob> {
        val n = gw * gh
        if (n == 0 || px.size < n) return emptyList()

        val vivid = BooleanArray(n)
        val sat = FloatArray(n)
        for (i in 0 until n) {
            val c = px[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val s = if (mx == 0) 0f else (mx - mn).toFloat() / mx
            sat[i] = s
            vivid[i] = s > 0.45f && mx > 115
        }

        val seen = BooleanArray(n)
        val stack = IntArray(n)
        val out = ArrayList<Blob>()

        for (start in 0 until n) {
            if (!vivid[start] || seen[start]) continue

            var sp = 0
            stack[sp++] = start
            seen[start] = true
            var count = 0
            var minX = gw
            var maxX = 0
            var minY = gh
            var maxY = 0
            var sumSat = 0f

            while (sp > 0) {
                val cur = stack[--sp]
                val x = cur % gw
                val y = cur / gw
                count++
                sumSat += sat[cur]
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y

                if (x > 0 && vivid[cur - 1] && !seen[cur - 1]) {
                    seen[cur - 1] = true
                    stack[sp++] = cur - 1
                }
                if (x < gw - 1 && vivid[cur + 1] && !seen[cur + 1]) {
                    seen[cur + 1] = true
                    stack[sp++] = cur + 1
                }
                if (y > 0 && vivid[cur - gw] && !seen[cur - gw]) {
                    seen[cur - gw] = true
                    stack[sp++] = cur - gw
                }
                if (y < gh - 1 && vivid[cur + gw] && !seen[cur + gw]) {
                    seen[cur + gw] = true
                    stack[sp++] = cur + gw
                }
            }

            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            val areaFrac = count.toFloat() / n
            val fill = count.toFloat() / (bw * bh)
            if (areaFrac < 0.004f || areaFrac > 0.30f || fill < 0.45f) continue

            val aspect = bw.toFloat() / bh
            var score = 0.4f * (sumSat / count) + min(areaFrac * 6f, 0.2f)
            score += if (aspect in 1.2f..6f) 0.4f else 0.1f
            out.add(
                Blob(
                    (minX + maxX + 1) / 2f / gw,
                    (minY + maxY + 1) / 2f / gh,
                    bw.toFloat() / gw,
                    bh.toFloat() / gh,
                    score.coerceIn(0f, 1f),
                ),
            )
        }
        return out.sortedByDescending { it.score }.take(8)
    }
}
