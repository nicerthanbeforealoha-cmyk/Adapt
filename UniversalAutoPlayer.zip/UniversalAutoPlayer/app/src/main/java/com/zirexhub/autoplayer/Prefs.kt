package com.zirexhub.autoplayer

import android.content.Context

/** Small wrapper around SharedPreferences for every user setting. */
object Prefs {
    const val MODE_AI = "ai"
    const val MODE_OFFLINE = "offline"

    const val DEFAULT_GOAL =
        "Work out which game this is and how it is played, then play it to win. " +
            "Clear tutorials, pop-ups and level-complete screens and keep progressing. " +
            "Survive as long as possible: avoid damage, keep moving, and learn from every death so the next run lasts longer."

    private fun sp(c: Context) = c.getSharedPreferences("zirex_autoplayer", Context.MODE_PRIVATE)

    /** Offline is the default so the app works out of the box with no key. */
    fun mode(c: Context): String = sp(c).getString("mode", MODE_OFFLINE) ?: MODE_OFFLINE

    fun provider(c: Context): Provider = Providers.byId(sp(c).getString("provider", null))

    fun apiKey(c: Context, p: Provider): String = sp(c).getString("key_${p.id}", "") ?: ""

    /** A saved model that used to be our default but has since been retired is replaced by the new default. */
    fun model(c: Context, p: Provider): String {
        val stored = (sp(c).getString("model_${p.id}", "") ?: "").trim()
        if (stored.isBlank() || stored in p.oldDefaults) return p.defaultModel
        return stored
    }

    /** Used when the app repairs a retired model by itself. */
    fun setModel(c: Context, p: Provider, model: String) {
        sp(c).edit().putString("model_${p.id}", model.trim()).apply()
    }

    fun baseUrl(c: Context, p: Provider): String =
        (sp(c).getString("base_${p.id}", "") ?: "").ifBlank { p.defaultBase }

    fun rawGoal(c: Context): String = sp(c).getString("goal", "") ?: ""

    /** Read this every step (not once) so a future "type new rules while playing" box just works. */
    fun goal(c: Context): String = rawGoal(c).ifBlank { DEFAULT_GOAL }

    /** Pause after each step. 0 = as fast as the phone can go. */
    fun delayMs(c: Context): Long = sp(c).getLong("delay_ms", 200L).coerceIn(0L, 15000L)

    /** How many actions the AI may return per call (fewer calls = faster and cheaper). */
    fun actionsPerCall(c: Context): Int = sp(c).getInt("actions_per_call", 3).coerceIn(1, 6)

    fun setGoal(c: Context, goal: String) {
        sp(c).edit().putString("goal", goal.trim()).apply()
    }

    fun save(
        c: Context,
        mode: String,
        p: Provider,
        apiKey: String,
        model: String,
        baseUrl: String,
        goal: String,
        delayMs: Long,
        actionsPerCall: Int,
    ) {
        sp(c).edit()
            .putString("mode", mode)
            .putString("provider", p.id)
            .putString("key_${p.id}", apiKey.trim())
            .putString("model_${p.id}", model.trim())
            .putString("base_${p.id}", baseUrl.trim())
            .putString("goal", goal.trim())
            .putLong("delay_ms", delayMs.coerceIn(0L, 15000L))
            .putInt("actions_per_call", actionsPerCall.coerceIn(1, 6))
            .apply()
    }
}
