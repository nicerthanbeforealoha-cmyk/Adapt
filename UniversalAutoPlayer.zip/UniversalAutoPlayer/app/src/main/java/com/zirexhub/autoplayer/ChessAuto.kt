package com.zirexhub.autoplayer

import kotlin.math.abs

/**
 * What a board picture shows, square by square (pure Kotlin, no Android). Index = row * 8 + col, row 0 = top of the screen.
 * [fg] = share of the square that differs from its own background, [lum] = brightness at the centre, [bg] = background
 * brightness (taken from the corners of the square, so a highlighted square still has the right one).
 */
class BoardMeasure(val fg: FloatArray, val lum: FloatArray, val bg: FloatArray)

object BoardEyes {
    private const val DIFF = 12

    /**
     * [img] is the board area only, 8 x 8 squares of equal size. A square's own background is the middle value of a ring of
     * pixels just inside its edge (a piece rarely reaches it, and a board cut a pixel or two off still has our colour in most
     * of the ring), and "how much of the square is a piece" is the share of pixels inside the ring that differ from it.
     */
    fun measure(img: Gray): BoardMeasure {
        val cw = img.w / 8
        val ch = img.h / 8
        val mx = maxOf(2, cw / 10)
        val my = maxOf(2, ch / 10)
        val tx = maxOf(2, cw / 12)
        val ty = maxOf(2, ch / 12)
        val fg = FloatArray(64)
        val lum = FloatArray(64)
        val bg = FloatArray(64)
        val ring = IntArray(cw * ch)
        val dev = IntArray(cw * ch)
        for (r in 0 until 8) for (c in 0 until 8) {
            val x0 = c * cw + mx
            val x1 = (c + 1) * cw - mx
            val y0 = r * ch + my
            val y1 = (r + 1) * ch - my
            var n = 0
            for (y in y0 until y1) for (x in x0 until x1) {
                if (x < x0 + tx || x >= x1 - tx || y < y0 + ty || y >= y1 - ty) ring[n++] = img.px[y * img.w + x]
            }
            java.util.Arrays.sort(ring, 0, n)
            val b = ring[n / 2]
            for (i in 0 until n) dev[i] = abs(ring[i] - b)
            java.util.Arrays.sort(dev, 0, n)
            val mad = dev[n / 2]
            bg[r * 8 + c] = b.toFloat()
            // a textured square (wood grain, a gradient) needs a higher bar than a flat one
            val bar = maxOf(DIFF, mad * 5)
            var count = 0
            for (y in y0 until y1) for (x in x0 until x1) if (abs(img.px[y * img.w + x] - b) > bar) count++
            fg[r * 8 + c] = count.toFloat() / ((x1 - x0) * (y1 - y0))
            // centre window: about a third of the square
            val wx = maxOf(2, cw / 6)
            val wy = maxOf(2, ch / 6)
            val cx0 = c * cw + cw / 2 - wx
            val cy0 = r * ch + ch / 2 - wy
            val win = IntArray(4 * wx * wy)
            var q = 0
            for (y in cy0 until cy0 + 2 * wy) for (x in cx0 until cx0 + 2 * wx) win[q++] = img.px[y * img.w + x]
            win.sort()
            lum[r * 8 + c] = win[win.size / 2].toFloat()
        }
        return BoardMeasure(fg, lum, bg)
    }
}

/**
 * Plays chess with no AI and no internet: it follows the game from the starting position (pure Kotlin, tested on a PC).
 *
 * How it sees without knowing what a piece looks like: at the start of a game every piece stands where it always stands, so the
 * picture of that moment teaches everything it needs: how much of a square a piece covers (to tell an empty square from a
 * busy one), how bright white pieces are against black ones (to tell the colours), which colour is at the bottom. From then
 * on it only has to tell "piece or no piece, which colour" on each of the 64 squares. The game itself is tracked with the
 * rules ([ChessPos]): the opponent's reply is the ONE legal move that explains the change in the picture, so castling rights
 * and en passant are exact and no piece has to be recognised. The engine ([ChessEngine]) chooses our moves.
 *
 * If the picture stops fitting the tracked game (a dialog, a restart, an animation) it counts a few observations and then
 * gives up ([Out.Lost]); a new starting position starts a new game. It never plays a move without a position that fits.
 */
class ChessAuto(private val clock: () -> Long, private val log: (String) -> Unit = {}) {

    sealed class Out {
        /** No chess game is being followed (the starting position has not been seen). */
        object NotReady : Out()

        /** Do nothing this step. */
        class Hold(val why: String) : Out()

        /** Press these cells: [cells] = col1,row1,col2,row2 (1 = left column / top row). */
        class Play(val actions: List<GameAction>, val label: String, val note: String, val cells: IntArray) : Out()

        /** The game ended (nobody can move). Whatever comes next (a "new game" button) is for another brain. */
        class Over(val why: String) : Out()

        /** The picture no longer fits the game that was followed. The game is forgotten. */
        class Lost(val why: String) : Out()
    }

    private class Sent(val move: Int, val at: Long, val fromTinted: Boolean) {
        var beforeSince = 0L
        var promoTaps = 0
    }

    private val engine = ChessEngine(clock)
    private var pos: ChessPos? = null
    private var whiteBottom = true
    private var lumSplit = 128f
    private var occThr = 0.15f
    private var baseBg = floatArrayOf(0f, 0f) // background brightness of the two square colours, by (row + col) % 2
    private var sent: Sent? = null
    private val failed = ArrayList<Int>()
    private val seen = HashSet<String>()
    private var selected = -1 // a real square whose piece is believed to be selected already
    private var mismatches = 0
    private var moves = 0
    private var skip: BooleanArray? = null // squares under the bot's own chip: not judged

    val ready: Boolean get() = pos != null

    /** Our colour: the one at the bottom of the screen. */
    val weAreWhite: Boolean get() = whiteBottom

    fun reset() {
        pos = null
        sent = null
        failed.clear()
        seen.clear()
        selected = -1
        mismatches = 0
        moves = 0
    }

    // ------------------------------------------------------------------ what the picture says

    private fun occupied(m: BoardMeasure, i: Int) = m.fg[i] >= occThr
    private fun isWhite(m: BoardMeasure, i: Int) = m.lum[i] >= lumSplit

    /** How many squares disagree between the picture and position [p] (a piece or not; the colour where both have one). */
    private fun mismatch(m: BoardMeasure, p: ChessPos): Int {
        var n = 0
        for (r in 0 until 8) for (c in 0 until 8) {
            val v = p.b[BoardPlan.squareOf(c + 1, r + 1, whiteBottom)]
            val i = r * 8 + c
            if (skip?.get(i) == true) continue
            val occ = occupied(m, i)
            if (occ != (v != 0)) n++ else if (occ && isWhite(m, i) != (v > 0)) n++
        }
        return n
    }

    /** Splits [values] into a low and a high group; returns (threshold, gap between the groups) or null when there is no clear split. */
    private fun split(values: List<Float>): Pair<Float, Float>? {
        val v = values.sorted()
        if (v.size < 4) return null
        var bestScore = -1f
        var bestAt = -1
        for (i in 1 until v.size) {
            val lo = v.subList(0, i)
            val hi = v.subList(i, v.size)
            val ml = lo.average().toFloat()
            val mh = hi.average().toFloat()
            val score = lo.size.toFloat() * hi.size * (mh - ml) * (mh - ml)
            if (score > bestScore) { bestScore = score; bestAt = i }
        }
        if (bestAt < 0) return null
        return Pair((v[bestAt - 1] + v[bestAt]) / 2f, v[bestAt] - v[bestAt - 1])
    }

    /**
     * Learns from a picture of a game that has only just begun: the starting position, or the starting position after the
     * first moves (a bot started a moment after the opponent's first move is the common case when we play black). Everything
     * it needs comes from that picture: which squares hold a piece (they differ from their own background much more than an
     * empty square or a square with a dot), how bright white pieces are against black ones, and which colour is at the bottom.
     * It accepts the picture only when exactly ONE position within two moves of the start explains every square.
     */
    private fun learn(m: BoardMeasure): Boolean {
        val fgSplit = split(m.fg.toList()) ?: return false
        if (fgSplit.second < 0.04f) return false
        val high = (0 until 64).filter { m.fg[it] >= fgSplit.first }
        if (high.size < 24 || high.size > 34) return false
        if (high.minOf { m.fg[it] } < 0.10f) return false
        val lumSplitFound = split(high.map { m.lum[it] }) ?: return false
        if (lumSplitFound.second < 25f) return false
        occThr = fgSplit.first
        lumSplit = lumSplitFound.first

        val start = ChessPos.fromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq -")!!
        val candidates = ArrayList<ChessPos>()
        val plyOf = ArrayList<Int>()
        candidates.add(start)
        plyOf.add(0)
        val buf = IntArray(256)
        val n1 = start.legal(buf)
        for (i in 0 until n1) {
            val a = start.copy().also { it.make(buf[i]) }
            candidates.add(a)
            plyOf.add(1)
            val buf2 = IntArray(256)
            val n2 = a.legal(buf2)
            for (j in 0 until n2) { candidates.add(a.copy().also { it.make(buf2[j]) }); plyOf.add(2) }
        }
        var found: ChessPos? = null
        var foundBottom = true
        var foundPlies = 0
        var matches = 0
        for (bottom in listOf(true, false)) {
            whiteBottom = bottom
            for ((k, cnd) in candidates.withIndex()) {
                if (mismatch(m, cnd) == 0) {
                    matches++
                    found = cnd
                    foundBottom = bottom
                    foundPlies = plyOf[k]
                }
            }
        }
        if (matches != 1 || found == null) return false
        whiteBottom = foundBottom
        // the colours of the two kinds of square (the middle value of the empty ones, so a highlighted square does not count)
        val base = FloatArray(2)
        for (parity in 0..1) {
            val list = (0 until 64).filter { m.fg[it] < occThr && (it / 8 + it % 8) % 2 == parity }.map { m.bg[it] }.sorted()
            base[parity] = if (list.isEmpty()) m.bg[parity] else list[list.size / 2]
        }
        baseBg = base
        reset()
        pos = found
        moves = foundPlies
        log("chess: the game was learned (we play ${if (whiteBottom) "white" else "black"}, a piece covers >= ${"%.2f".format(java.util.Locale.US, occThr)} of a square, white/black split ${lumSplit.toInt()}, ${if (found.side == 1) "white" else "black"} to move)")
        return true
    }

    private fun looksLikeStart(m: BoardMeasure): Boolean {
        for (r in 0 until 8) for (c in 0 until 8) {
            if (skip?.get(r * 8 + c) == true) continue
            if (occupied(m, r * 8 + c) != (r < 2 || r > 5)) return false
        }
        for (i in 0 until 16) if (skip?.get(i) != true && isWhite(m, i) == whiteBottom) return false
        for (i in 48 until 64) if (skip?.get(i) != true && isWhite(m, i) != whiteBottom) return false
        return true
    }

    private fun tinted(m: BoardMeasure, row: Int, col: Int): Boolean = abs(m.bg[row * 8 + col] - baseBg[(row + col) % 2]) > TINT

    /** The legal reply of the opponent in [p] that explains the picture, or null (none fits, or two fit equally well). */
    private fun reply(m: BoardMeasure, p: ChessPos): Int? {
        val buf = IntArray(256)
        val n = p.legal(buf)
        var best = Int.MAX_VALUE
        var second = Int.MAX_VALUE
        var bestMove = -1
        val q = p.copy()
        for (i in 0 until n) {
            val mv = buf[i]
            q.make(mv)
            val d = mismatch(m, q)
            q.unmake(mv)
            if (d < best) {
                // a promotion to another piece looks the same on the screen: the same move to the same square is no rival
                if (bestMove >= 0 && (mv and 4095) == (bestMove and 4095)) { best = d; bestMove = mv; continue }
                second = best
                best = d
                bestMove = mv
            } else if (d < second && (mv and 4095) != (bestMove and 4095)) {
                second = d
            }
        }
        if (bestMove < 0 || best > TOLERANCE) return null
        if (second != Int.MAX_VALUE && second - best < 2) return null
        // an unfinished promotion choice is played as a queen
        return if (((bestMove shr 12) and 7) != 0) (bestMove and 4095) or (5 shl 12) else bestMove
    }

    // ------------------------------------------------------------------ one step

    /**
     * [img] = the board area as a picture of 8 x 8 equal squares, [grid] = where the board is on the screen, [settled] = the
     * screen has stopped moving (an opponent's piece sliding across would read as a wrong position).
     */
    fun step(img: Gray, grid: Grid, settled: Boolean, covered: BooleanArray? = null): Out {
        if (grid.cols != 8 || grid.rows != 8) return Out.NotReady
        val m = BoardEyes.measure(img)
        skip = covered
        val anyCovered = covered != null && covered.any { it }
        var p0 = pos
        if (p0 == null) {
            // learning needs every square in view
            if (anyCovered || !learn(m)) return Out.NotReady
            p0 = pos ?: return Out.NotReady
        }
        if (!settled) return Out.Hold("waiting for the screen to settle")

        // a new game began while an old one was followed
        if (moves > 0 && looksLikeStart(m)) {
            log("chess: the starting position is on the screen again: a new game")
            pos = null
            sent = null
            if (anyCovered || !learn(m)) return Out.NotReady
            p0 = pos ?: return Out.NotReady
        }

        val s = sent
        if (s != null) {
            // the finger needs a moment to land and the app a moment to draw: judging at once would call every move a failure
            if (clock() - s.at < JUDGE_AFTER_MS) return Out.Hold("our move was just sent")
            val after = p0.copy().also { it.make(s.move) }
            val dAfter = mismatch(m, after)
            val dBefore = mismatch(m, p0)
            if (dAfter <= TOLERANCE && dAfter < dBefore) {
                mismatches = 0
                s.beforeSince = 0L
                val buf = IntArray(256)
                if (after.legal(buf) == 0) return Out.Over("our move ${ChessPos.uci(s.move)} ends the game")
                return Out.Hold("our move ${ChessPos.uci(s.move)} is on the board, waiting for the reply")
            }
            if (dBefore <= TOLERANCE && dBefore < dAfter) {
                // the picture still shows the position before our move. An app that draws slowly would look the same, so the
                // verdict needs the same picture twice, a moment apart
                val now = clock()
                if (s.beforeSince == 0L) s.beforeSince = now
                if (now - s.beforeSince < FAIL_CONFIRM_MS) return Out.Hold("checking whether our move ${ChessPos.uci(s.move)} happened")
                // our move did not happen (a piece that was only selected, or nothing): never choose it again
                failed.add(s.move)
                sent = null
                mismatches = 0
                val from = s.move and 63
                val cell = BoardPlan.cellOf(from, whiteBottom)
                // selected = the square is tinted now and was not before the press
                selected = if (!s.fromTinted && tinted(m, cell[1] - 1, cell[0] - 1)) from else -1
                log("chess: the move ${ChessPos.uci(s.move)} did not happen on the screen (${failed.size} failed so far, piece ${if (selected >= 0) "still selected" else "not selected"})")
            } else {
                s.beforeSince = 0L
                val rep = reply(m, after)
                if (rep == null) {
                    // a pawn that reached the last row: most apps ask what to promote to, with the queen on the target square
                    if (((s.move shr 12) and 7) != 0 && s.promoTaps < 2 && !anyCovered) {
                        s.promoTaps++
                        val to = BoardPlan.cellOf((s.move shr 6) and 63, whiteBottom)
                        val tap = GameAction.Tap(grid.cx(to[0]), grid.cy(to[1]), 1, "cell(${to[0]},${to[1]})", true)
                        log("chess: the promotion is not finished on the screen: pressing the target square again for the queen (#${s.promoTaps})")
                        return Out.Play(listOf(tap), tap.label, "offline chess: choosing the queen for the promotion", intArrayOf(to[0], to[1], to[0], to[1]))
                    }
                    return mismatch("the picture fits neither our move nor any reply (${minOf(dAfter, dBefore)} squares differ)")
                }
                after.make(rep)
                pos = after
                sent = null
                failed.clear()
                selected = -1
                mismatches = 0
                moves++
                log("chess: the opponent played ${ChessPos.uci(rep)}")
            }
        } else {
            val d = mismatch(m, p0)
            if (d > TOLERANCE) {
                // the opponent's move (it is their turn), or a mismatch
                val rep = if (p0.side != ownSide()) reply(m, p0) else null
                if (rep == null) return mismatch("the picture does not fit the game ($d squares differ)")
                val q = p0.copy()
                q.make(rep)
                pos = q
                failed.clear()
                selected = -1
                mismatches = 0
                moves++
                log("chess: the opponent played ${ChessPos.uci(rep)}")
            } else {
                mismatches = 0
            }
        }

        val p = pos ?: return Out.NotReady
        if (p.side != ownSide()) return Out.Hold("waiting for the opponent to move")

        // our move
        val exclude = HashSet<String>()
        for (mv in failed) exclude.add(ChessPos.uci(mv))
        val t0 = clock()
        val choice = engine.best(p, ENGINE_MS, 6, exclude, seen)
        if (choice == null) {
            if (failed.isEmpty()) return Out.Over("no legal move for us: the game is over")
            // every move was refused by the screen: forget the refusals and try again from the start
            failed.clear()
            return Out.Hold("every move failed on the screen, trying them again")
        }
        val from = BoardPlan.cellOf(choice.move and 63, whiteBottom)
        val to = BoardPlan.cellOf((choice.move shr 6) and 63, whiteBottom)
        val tapTo = GameAction.Tap(grid.cx(to[0]), grid.cy(to[1]), 1, "cell(${to[0]},${to[1]})", true)
        val actions: List<GameAction> =
            if (selected >= 0 && selected == (choice.move and 63)) {
                listOf(tapTo)
            } else {
                listOf(GameAction.Tap(grid.cx(from[0]), grid.cy(from[1]), 1, "cell(${from[0]},${from[1]})", true), tapTo)
            }
        val after = p.copy().also { it.make(choice.move) }
        seen.add(after.key())
        sent = Sent(choice.move, clock(), tinted(m, from[1] - 1, from[0] - 1))
        selected = -1
        val score = if (abs(choice.score) > ChessEngine.MATE - 100) "mate" else (if (choice.score >= 0) "+" else "") + choice.score
        val note = "offline chess: ${choice.uci} ($score cp, depth ${choice.depth}, ${choice.nodes / 1000}k nodes, ${clock() - t0}ms; we play ${if (whiteBottom) "white" else "black"})"
        val label = actions.joinToString(" ; ") { (it as GameAction.Tap).label }
        return Out.Play(actions, label, note, intArrayOf(from[0], from[1], to[0], to[1]))
    }

    /** Starts from a known position, after the thresholds were learned once (used by tests of rare endings). */
    internal fun adopt(p: ChessPos, bottom: Boolean) {
        pos = p
        whiteBottom = bottom
        sent = null
        failed.clear()
        selected = -1
        mismatches = 0
    }

    /** The press was refused (it would have hit the bot's own chip), so the move never happened: no verdict on it. */
    fun cancelSent() {
        val s = sent ?: return
        sent = null
        seen.remove(pos?.copy()?.also { it.make(s.move) }?.key() ?: "")
    }

    private fun ownSide(): Int = if (whiteBottom) 1 else -1

    /** A picture that does not fit: wait a few observations (an animation, a popup edge), then give the game up. */
    private fun mismatch(why: String): Out {
        // squares under the bot's own chip cannot be judged: the picture is not wrong, it is hidden. The chip is moved away.
        if (skip?.any { it } == true) return Out.Hold("$why (some squares are covered, waiting)")
        mismatches++
        if (mismatches < GIVE_UP) return Out.Hold("$why (looking again, $mismatches of $GIVE_UP)")
        log("chess: giving up the game: $why")
        reset()
        return Out.Lost(why)
    }

    private companion object {
        const val TOLERANCE = 1
        const val TINT = 12f
        const val GIVE_UP = 4
        const val ENGINE_MS = 1800L
        const val JUDGE_AFTER_MS = 900L
        const val FAIL_CONFIRM_MS = 700L
    }
}
