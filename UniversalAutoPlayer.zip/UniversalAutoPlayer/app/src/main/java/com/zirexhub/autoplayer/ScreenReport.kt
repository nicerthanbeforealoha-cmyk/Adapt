package com.zirexhub.autoplayer

/**
 * Describes a grey picture of the screen in a few lines of text, for the debug log: when the chess board is not found, the log
 * must show what the bot actually receives (a normal screen, or a black picture because the app blocks screenshots). Pure
 * Kotlin, tested on a PC.
 */
object ScreenReport {
    class Stats(val mean: Int, val spread: Int, val blackPct: Int, val whitePct: Int) {
        /** A picture that is (almost) one colour or black: nothing can be read from it. */
        val blank: Boolean get() = blackPct >= 97 || spread < 5
        override fun toString() = "brightness $mean/255, spread $spread, black ${blackPct}%, white ${whitePct}%"
    }

    /** Statistics of the middle of the picture (the app, not the status bar and the navigation bar). */
    fun stats(g: Gray): Stats {
        val y0 = g.h * 8 / 100
        val y1 = maxOf(y0 + 1, g.h * 92 / 100)
        var n = 0
        var sum = 0L
        var sum2 = 0L
        var dark = 0
        var bright = 0
        for (y in y0 until minOf(y1, g.h)) for (x in 0 until g.w) {
            val v = g.px[y * g.w + x]
            n++
            sum += v
            sum2 += v.toLong() * v
            if (v < 20) dark++
            if (v > 235) bright++
        }
        if (n == 0) return Stats(0, 0, 100, 0)
        val mean = sum / n
        val sd = Math.sqrt(maxOf(0.0, sum2.toDouble() / n - mean.toDouble() * mean)).toInt()
        return Stats(mean.toInt(), sd, dark * 100 / n, bright * 100 / n)
    }

    /** The picture as rows of digits, 0 = black ... 9 = white, [cols] x [rows] blocks. */
    fun map(g: Gray, cols: Int = 32, rows: Int = 48): List<String> {
        val out = ArrayList<String>()
        for (r in 0 until rows) {
            val sb = StringBuilder()
            for (c in 0 until cols) {
                val xa = c * g.w / cols
                val xb = maxOf(xa + 1, (c + 1) * g.w / cols)
                val ya = r * g.h / rows
                val yb = maxOf(ya + 1, (r + 1) * g.h / rows)
                var s = 0
                var k = 0
                for (y in ya until minOf(yb, g.h)) for (x in xa until minOf(xb, g.w)) {
                    s += g.px[y * g.w + x]
                    k++
                }
                sb.append(if (k == 0) '0' else ('0' + minOf(9, s / k / 26)))
            }
            out.add(sb.toString())
        }
        return out
    }
}
