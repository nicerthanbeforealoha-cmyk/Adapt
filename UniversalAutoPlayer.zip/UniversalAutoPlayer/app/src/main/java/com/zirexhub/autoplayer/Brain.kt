package com.zirexhub.autoplayer

import android.graphics.Bitmap

/**
 * One thing the agent can do on the screen.
 * All coordinates are NORMALIZED (0.0 .. 1.0) so they do not depend on screen size.
 */
sealed class GameAction {
    /** [count] > 1 sends a fast burst of taps inside ONE gesture (up to 20). */
    data class Tap(val x: Float, val y: Float, val count: Int = 1) : GameAction()
    data class LongPress(val x: Float, val y: Float, val ms: Long = 700L) : GameAction()
    /**
     * A slow, long swipe is a joystick push: finger down at the start, held while it slides to the end.
     * [keepGoing] = true means "do not wait for it to finish": the next screenshot is taken while the
     * finger is still down, so the character keeps moving while the bot thinks.
     * [taps] are extra fingers pressed WHILE the first one is held (move + press a skill button at once).
     */
    data class Swipe(
        val x1: Float,
        val y1: Float,
        val x2: Float,
        val y2: Float,
        val ms: Long = 300L,
        val keepGoing: Boolean = false,
        val taps: List<Pair<Float, Float>> = emptyList(),
    ) : GameAction()

    data class Wait(val ms: Long = 1000L) : GameAction()
    object Back : GameAction()
    data class Finish(val reason: String) : GameAction()
}

/** What a brain decided: one or more actions, a short human note, and a compact history label. */
data class Decision(val actions: List<GameAction>, val note: String, val label: String) {
    constructor(action: GameAction, note: String, label: String) : this(listOf(action), note, label)
}

/** Everything a brain gets besides the screenshot. */
class AgentContext(
    /** The user's rules / instructions. Read fresh every step so it can be edited live later. */
    val goal: String,
    val history: List<String>,
    /** 0..1 fraction of the screen that changed since the previous step (null on the first step). */
    val changeScore: Float?,
    /** How many steps in a row did not visibly change the screen. */
    val stuckCount: Int,
    /** How many actions an AI brain may return in one reply. */
    val maxActions: Int = 1,
    /** Screen areas that must never be tapped (the agent's own floating chip). */
    val blocked: List<Zone> = emptyList(),
)

/** A "brain" looks at one frame and picks the next action(s). */
interface Brain {
    fun decide(frame: Bitmap, ctx: AgentContext): Decision

    /** The last action was refused (it would have touched the agent's own chip), so it did not really happen. */
    fun onActionRefused() {}

    /** Release resources (OCR engine etc.). */
    fun close() {}
}
