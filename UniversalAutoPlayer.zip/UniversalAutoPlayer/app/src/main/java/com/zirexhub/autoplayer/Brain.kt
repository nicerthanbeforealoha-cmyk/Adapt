package com.zirexhub.autoplayer

import android.graphics.Bitmap

/**
 * One thing the agent can do on the screen.
 * All coordinates are NORMALIZED (0.0 .. 1.0) so they do not depend on screen size.
 */
sealed class GameAction {
    /**
     * [count] > 1 sends a fast burst of taps inside ONE gesture (up to 20). [exact] = the point is the computed centre of a
     * board cell: it is never moved onto a nearby word.
     */
    data class Tap(val x: Float, val y: Float, val count: Int = 1, val label: String = "", val exact: Boolean = false) : GameAction()
    data class LongPress(val x: Float, val y: Float, val ms: Long = 700L) : GameAction()
    /**
     * A slow, long swipe is a joystick push: finger down at the start, held while it slides to the end.
     * [keepGoing] = true means "do not wait for it to finish": the next screenshot is taken while the
     * finger is still down, so the character keeps moving while the bot thinks.
     * [taps] are extra fingers pressed WHILE the first one is held (move + press a skill button at once).
     */
    data class Swipe(
        val x1: Float,
        val y1: Float,
        val x2: Float,
        val y2: Float,
        val ms: Long = 300L,
        val keepGoing: Boolean = false,
        val taps: List<Pair<Float, Float>> = emptyList(),
    ) : GameAction()

    data class Wait(val ms: Long = 1000L) : GameAction()
    object Back : GameAction()
    data class Finish(val reason: String) : GameAction()
}

/** What a brain decided: one or more actions, a short human note, and a compact history label. */
data class Decision(
    val actions: List<GameAction>,
    val note: String,
    val label: String,
    /**
     * A button press chosen from the words on the screen. The screen can change between the screenshot the decision was
     * made on and the moment the finger lands (a popup finishes its animation, a new button appears where the old text
     * was), so the service looks once more right before pressing and skips the press if the area changed.
     */
    val verifyTap: Boolean = false,
    /** What the AI read from a chess board (see [BoardPlan]). The move itself is then chosen by the chess engine. */
    val read: BoardRead? = null,
    /** Set when the move was chosen by the chess engine: the cells it goes between. */
    val play: ChessPlay? = null,
) {
    constructor(action: GameAction, note: String, label: String, verifyTap: Boolean = false) :
        this(listOf(action), note, label, verifyTap)
}

/** Everything a brain gets besides the screenshot. */
class AgentContext(
    /** The user's rules / instructions. Read fresh every step so it can be edited live later. */
    val goal: String,
    val history: List<String>,
    /** 0..1 fraction of the screen that changed since the previous step (null on the first step). */
    val changeScore: Float?,
    /** How many steps in a row did not visibly change the screen. */
    val stuckCount: Int,
    /** How many actions an AI brain may return in one reply. */
    val maxActions: Int = 1,
    /** Screen areas that must never be tapped (the agent's own floating chip). */
    val blocked: List<Zone> = emptyList(),
    /** The words on THIS screenshot found by the on-device OCR, with exact positions (only filled for AI requests). */
    val screenText: List<TextLine> = emptyList(),
    /** Why the AI is being asked now ("popup with choices", "the bot is stuck", ...). Empty = it plays on its own. */
    val situation: String = "",
    /** Presses the AI chose earlier that did nothing, so it does not repeat them. */
    val failedPresses: List<String> = emptyList(),
    /** A board of equal cells found on this screenshot (chess, checkers, ...), so the AI can say "column 5, row 7". */
    val grid: Grid? = null,
    /** On a board: the moves already played in this game and what became of them, so the AI does not repeat them. */
    val moveLog: List<String> = emptyList(),
    /** Taps did not move pieces in this game: move them by dragging (drag_cell) instead. */
    val dragMoves: Boolean = false,
)

/** A "brain" looks at one frame and picks the next action(s). */
interface Brain {
    fun decide(frame: Bitmap, ctx: AgentContext): Decision

    /** The last action was refused (it would have touched the agent's own chip), so it did not really happen. */
    fun onActionRefused() {}

    /** Release resources (OCR engine etc.). */
    fun close() {}
}
