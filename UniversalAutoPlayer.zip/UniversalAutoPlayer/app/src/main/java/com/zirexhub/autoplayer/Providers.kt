package com.zirexhub.autoplayer

/** The three wire formats that cover almost every AI service. */
enum class Protocol { ANTHROPIC, OPENAI, GEMINI }

class Provider(
    val id: String,
    val label: String,
    val protocol: Protocol,
    val defaultBase: String,
    val defaultModel: String,
    val needsKey: Boolean,
    val note: String,
    /** Names we used to suggest that have since been retired. A saved one of these is upgraded automatically. */
    val oldDefaults: List<String> = emptyList(),
)

/**
 * Presets. Model names are only defaults and AI companies retire models, so the app lets the user
 * edit the model name and base URL. "Custom" works with anything that speaks the OpenAI chat API
 * (Mistral, Together, xAI, DeepSeek-VL hosts, Ollama / LM Studio on a PC, ...). The model MUST accept images.
 */
object Providers {
    val GEMINI = Provider(
        "gemini", "Google Gemini", Protocol.GEMINI,
        "https://generativelanguage.googleapis.com/v1beta", "gemini-3.8-flash", true,
        "Get a key at aistudio.google.com. It often has a free tier, check the current limits.",
        listOf("gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash"),
    )
    val ANTHROPIC = Provider(
        "anthropic", "Anthropic (Claude)", Protocol.ANTHROPIC,
        "https://api.anthropic.com", "claude-haiku-5-5", true,
        "Key from console.anthropic.com. Haiku is fast and cheap, Sonnet plays smarter.",
    )
    val OPENAI = Provider(
        "openai", "OpenAI (ChatGPT)", Protocol.OPENAI,
        "https://api.openai.com/v1", "gpt-4o-mini", true,
        "Key from platform.openai.com. Pay per use.",
    )
    val OPENROUTER = Provider(
        "openrouter", "OpenRouter (many models)", Protocol.OPENAI,
        "https://openrouter.ai/api/v1", "google/gemini-2.5-flash", true,
        "One key, many models, some free. Pick a model that accepts images.",
    )
    val GROQ = Provider(
        "groq", "Groq", Protocol.OPENAI,
        "https://api.groq.com/openai/v1", "meta-llama/llama-4-scout-17b-16e-instruct", true,
        "Very fast. Key from console.groq.com. It has a free tier, check the current limits.",
    )
    val CUSTOM = Provider(
        "custom", "Custom (OpenAI-compatible)", Protocol.OPENAI,
        "", "", false,
        "Any server that speaks the OpenAI chat API: Mistral, Together, xAI, or Ollama / LM Studio " +
            "on your own PC (example base URL: http://192.168.1.5:11434/v1). The model must accept images. " +
            "Leave the key empty if the server has none.",
    )

    val all: List<Provider> = listOf(GEMINI, ANTHROPIC, OPENAI, OPENROUTER, GROQ, CUSTOM)

    fun byId(id: String?): Provider = all.firstOrNull { it.id == id } ?: GEMINI
}
