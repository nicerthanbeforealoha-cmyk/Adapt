package com.zirexhub.autoplayer

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.roundToInt

/**
 * The offline brain: reads the screen text with on-device OCR, watches how the picture moves, spots
 * button-like colour areas, and lets the [Planner] decide. No internet, no API key, nothing leaves the phone.
 *
 * In a live game that is played with a joystick it skips the slow text reading on most steps (the words
 * on screen are the same HUD every time) so it can look, think and push the joystick much more often.
 * It reads the text again every few steps and whenever the picture suddenly changes shape (a popup,
 * a death screen), which is when buttons appear.
 */
class SmartBrain : Brain {
    private val planner = Planner()
    private val ocr = TextReader()
    private var lastReading: Reading? = null
    private var reads = 0
    private var stepsSinceRead = 0
    private var steps = 0
    private var prevGray: Gray? = null
    private var prevCoherence = 0f
    private var lastStyleLog = ""
    private var readBurst = 0 // after a sudden change of the picture, keep reading for a few steps while the new screen settles

    override fun decide(frame: Bitmap, ctx: AgentContext): Decision {
        steps++
        val change = ctx.changeScore
        val now = SystemClock.elapsedRealtime()

        // How did the scene move since the last step? (also tells us whether our joystick push worked)
        val gray = FrameTools.gray(frame)
        val motion = prevGray?.let { Motion.analyze(it, gray) }
        prevGray = gray

        val cached = lastReading
        val needRead = cached == null || change == null || (change >= 0.002f && readNow(change, motion))
        val fresh = if (needRead) analyze(frame) else cached!!
        stepsSinceRead = if (needRead) 0 else stepsSinceRead + 1
        lastReading = fresh
        prevCoherence = motion?.coherence ?: 0f

        // The no-tap zones can change (chip moved), so always attach the current ones.
        val aspect = frame.height.toFloat() / frame.width
        var hazards: HazardInfo? = null
        var threats: ThreatMap? = null
        if (planner.movementMode()) {
            val seen = perceive(frame, aspect, ctx.blocked)
            hazards = seen.first
            threats = seen.second
        }
        val reading = Reading(fresh.lines, fresh.blobs, ctx.blocked, aspect, hazards, threats, fresh.seq)
        // The service counts "stuck" from the coarse change score, which also reads a standing character in a dark
        // running game as frozen. A picture that still moves a little when looked at closely is not stuck.
        val stuck = if (motion != null && motion.meanDiff >= 1.0f) 0 else ctx.stuckCount
        val decision = planner.decide(reading, change, stuck, motion, now)

        for (n in planner.takeNotes()) DebugLog.add(n)
        val style = planner.styleStatus()
        if (style != lastStyleLog && !style.startsWith("Learning")) {
            lastStyleLog = style
            DebugLog.add("STYLE: $style | ${planner.styleDetails()}")
        } else if (steps % 25 == 0) {
            DebugLog.add("style check: ${planner.styleDetails()} motion=${motion?.let { "(${it.dx},${it.dy}) coh=${"%.2f".format(it.coherence)}" } ?: "-"}")
        }
        return decision
    }

    /** Is it worth the slow text reading on this step? */
    private fun readNow(change: Float, motion: MotionInfo?): Boolean {
        if (!planner.movementMode()) return true
        // a popup, a death taunt or a frozen picture: the words matter now (a death screen used to be read 3 s late)
        if (planner.wantsText()) return true
        if (readBurst > 0) {
            readBurst--
            return true
        }
        if (stepsSinceRead >= 5) return true // safety net: look at the words every few steps
        if (change > 0.35f) {
            readBurst = 3
            return true // the whole picture changed: new screen
        }
        // a clear jump that is not the camera sliding along with us: something appeared on top of the game (the words of a
        // death taunt fade in a second AFTER the screen changed, so the next few steps read the text too)
        if (change > 0.08f && (motion?.coherence ?: 0f) < 0.3f) {
            readBurst = 3
            return true
        }
        val lostTheSlide = prevCoherence >= 0.35f && (motion?.coherence ?: 0f) < 0.15f
        if (lostTheSlide) readBurst = 3
        return lostTheSlide // the camera stopped following us: a popup, a pause, a death screen
    }

    override fun onActionRefused() {
        planner.cancelLast()
    }

    private fun analyze(frame: Bitmap): Reading {
        val t0 = SystemClock.elapsedRealtime()
        val lines = ocr.read(frame)
        val t1 = SystemClock.elapsedRealtime()
        val blobs = findBlobs(frame)
        val t2 = SystemClock.elapsedRealtime()
        reads++
        if (reads <= 3 || reads % 25 == 0) {
            DebugLog.add("read #$reads: OCR ${t1 - t0}ms (${lines.size} lines), blobs ${t2 - t1}ms (${blobs.size})")
        }
        // what the bot actually reads, so a wrong decision can be traced to the text it saw
        if (reads <= 8 || reads % 10 == 0) {
            val seen = lines.take(14).joinToString(" | ") { "${it.text.take(22)}@${(it.cx * 100).toInt()},${(it.cy * 100).toInt()}" }
            DebugLog.add("TEXT #$reads: $seen")
        }
        return Reading(lines, blobs, seq = reads)
    }

    /**
     * Lava, thorn walls, enemies, gems and the health bar, all from the colours of ONE 192 px wide copy of the screenshot
     * (the colours were measured at that size). The hazards use a 96 px wide copy made from it.
     */
    private fun perceive(frame: Bitmap, aspect: Float, blocked: List<Zone>): Pair<HazardInfo?, ThreatMap?> {
        return try {
            val gw = 192
            val gh = (gw * aspect).roundToInt().coerceIn(64, 512)
            val small = FrameTools.shrink(frame, gw, gh)
            val px = IntArray(gw * gh)
            small.getPixels(px, 0, gw, 0, 0, gw, gh)
            if (small !== frame) small.recycle()
            val hw = gw / 2
            val hh = gh / 2
            val half = IntArray(hw * hh)
            for (y in 0 until hh) for (x in 0 until hw) {
                var r = 0
                var g = 0
                var b = 0
                for (dy in 0..1) for (dx in 0..1) {
                    val c = px[(2 * y + dy) * gw + 2 * x + dx]
                    r += (c shr 16) and 0xFF
                    g += (c shr 8) and 0xFF
                    b += c and 0xFF
                }
                half[y * hw + x] = (0xFF shl 24) or ((r / 4) shl 16) or ((g / 4) shl 8) or (b / 4)
            }
            val hz = Hazards.analyze(half, hw, hh, aspect)
            val th = Threats.analyze(px, gw, gh, aspect, hz, blocked)
            if (steps % 12 == 0) {
                DebugLog.add("hazards: ${hz?.describe() ?: "-"} | threats: ${th?.describe() ?: "-"}")
            }
            Pair(hz, th)
        } catch (t: Throwable) {
            Pair(null, null)
        }
    }

    private fun findBlobs(frame: Bitmap): List<Blob> {
        val gw = 48
        val gh = (gw * frame.height.toFloat() / frame.width).roundToInt().coerceIn(16, 128)
        val small = FrameTools.shrink(frame, gw, gh)
        val px = IntArray(gw * gh)
        small.getPixels(px, 0, gw, 0, 0, gw, gh)
        if (small !== frame) small.recycle()
        return Blobs.find(px, gw, gh)
    }

    override fun close() {
        ocr.close()
    }
}
