package com.zirexhub.autoplayer

import android.graphics.Bitmap
import kotlin.math.roundToInt

/**
 * The offline brain: reads the screen text with on-device OCR, spots button-like colour areas,
 * and lets the [Planner] decide. No internet, no API key, nothing leaves the phone.
 */
class SmartBrain : Brain {
    private val planner = Planner()
    private val ocr = TextReader()
    private var lastReading: Reading? = null

    override fun decide(frame: Bitmap, ctx: AgentContext): Decision {
        val change = ctx.changeScore
        val cached = lastReading
        // Screen did not change: reuse what we already read (saves the slow OCR on loading screens).
        val reading = if (change != null && change < 0.002f && cached != null) cached else analyze(frame)
        lastReading = reading
        return planner.decide(reading, change, ctx.stuckCount)
    }

    private fun analyze(frame: Bitmap): Reading {
        val lines = ocr.read(frame)
        return Reading(lines, findBlobs(frame))
    }

    private fun findBlobs(frame: Bitmap): List<Blob> {
        val gw = 48
        val gh = (gw * frame.height.toFloat() / frame.width).roundToInt().coerceIn(16, 128)
        val small = Bitmap.createScaledBitmap(frame, gw, gh, true)
        val px = IntArray(gw * gh)
        small.getPixels(px, 0, gw, 0, 0, gw, gh)
        if (small !== frame) small.recycle()
        return Blobs.find(px, gw, gh)
    }

    override fun close() {
        ocr.close()
    }
}
