package com.zirexhub.autoplayer

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.roundToInt

/**
 * The offline brain: reads the screen text with on-device OCR, spots button-like colour areas,
 * and lets the [Planner] decide. No internet, no API key, nothing leaves the phone.
 */
class SmartBrain : Brain {
    private val planner = Planner()
    private val ocr = TextReader()
    private var lastReading: Reading? = null
    private var reads = 0

    override fun decide(frame: Bitmap, ctx: AgentContext): Decision {
        val change = ctx.changeScore
        val cached = lastReading
        // Screen did not change: reuse what we already read (saves the slow OCR on loading screens).
        val fresh = if (change != null && change < 0.002f && cached != null) cached else analyze(frame)
        lastReading = fresh
        // The no-tap zones can change (chip moved), so always attach the current ones.
        val reading = Reading(fresh.lines, fresh.blobs, ctx.blocked)
        return planner.decide(reading, change, ctx.stuckCount)
    }

    override fun onActionRefused() {
        planner.cancelLast()
    }

    private fun analyze(frame: Bitmap): Reading {
        val t0 = SystemClock.elapsedRealtime()
        val lines = ocr.read(frame)
        val t1 = SystemClock.elapsedRealtime()
        val blobs = findBlobs(frame)
        val t2 = SystemClock.elapsedRealtime()
        reads++
        if (reads <= 3 || reads % 25 == 0) {
            DebugLog.add("read #$reads: OCR ${t1 - t0}ms (${lines.size} lines), blobs ${t2 - t1}ms (${blobs.size})")
        }
        return Reading(lines, blobs)
    }

    private fun findBlobs(frame: Bitmap): List<Blob> {
        val gw = 48
        val gh = (gw * frame.height.toFloat() / frame.width).roundToInt().coerceIn(16, 128)
        val small = Bitmap.createScaledBitmap(frame, gw, gh, true)
        val px = IntArray(gw * gh)
        small.getPixels(px, 0, gw, 0, 0, gw, gh)
        if (small !== frame) small.recycle()
        return Blobs.find(px, gw, gh)
    }

    override fun close() {
        ocr.close()
    }
}
