package com.zirexhub.autoplayer

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.roundToInt

/**
 * The offline brain: reads the screen text with on-device OCR, watches how the picture moves, spots
 * button-like colour areas, and lets the [Planner] decide. No internet, no API key, nothing leaves the phone.
 *
 * In a live game that is played with a joystick it skips the slow text reading on most steps (the words
 * on screen are the same HUD every time) so it can look, think and push the joystick much more often.
 * It reads the text again every few steps and whenever the picture suddenly changes shape (a popup,
 * a death screen), which is when buttons appear.
 */
class SmartBrain : Brain {
    private val planner = Planner()
    private val ocr = TextReader()
    private var lastReading: Reading? = null
    private var reads = 0
    private var stepsSinceRead = 0
    private var steps = 0
    private var prevGray: Gray? = null
    private var prevCoherence = 0f
    private var lastStyleLog = ""

    override fun decide(frame: Bitmap, ctx: AgentContext): Decision {
        steps++
        val change = ctx.changeScore
        val now = SystemClock.elapsedRealtime()

        // How did the scene move since the last step? (also tells us whether our joystick push worked)
        val gray = FrameTools.gray(frame)
        val motion = prevGray?.let { Motion.analyze(it, gray) }
        prevGray = gray

        val cached = lastReading
        val needRead = cached == null || change == null || (change >= 0.002f && readNow(change, motion))
        val fresh = if (needRead) analyze(frame) else cached!!
        stepsSinceRead = if (needRead) 0 else stepsSinceRead + 1
        lastReading = fresh
        prevCoherence = motion?.coherence ?: 0f

        // The no-tap zones can change (chip moved), so always attach the current ones.
        val aspect = frame.height.toFloat() / frame.width
        val reading = Reading(fresh.lines, fresh.blobs, ctx.blocked, aspect)
        // The service counts "stuck" from the coarse change score, which also reads a standing character in a dark
        // running game as frozen. A picture that still moves a little when looked at closely is not stuck.
        val stuck = if (motion != null && motion.meanDiff >= 1.0f) 0 else ctx.stuckCount
        val decision = planner.decide(reading, change, stuck, motion, now)

        for (n in planner.takeNotes()) DebugLog.add(n)
        val style = planner.styleStatus()
        if (style != lastStyleLog && !style.startsWith("Learning")) {
            lastStyleLog = style
            DebugLog.add("STYLE: $style | ${planner.styleDetails()}")
        } else if (steps % 25 == 0) {
            DebugLog.add("style check: ${planner.styleDetails()} motion=${motion?.let { "(${it.dx},${it.dy}) coh=${"%.2f".format(it.coherence)}" } ?: "-"}")
        }
        return decision
    }

    /** Is it worth the slow text reading on this step? */
    private fun readNow(change: Float, motion: MotionInfo?): Boolean {
        if (!planner.movementMode()) return true
        if (stepsSinceRead >= 5) return true // safety net: look at the words every few steps
        if (change > 0.35f) return true // the whole picture changed: new screen
        val lostTheSlide = prevCoherence >= 0.35f && (motion?.coherence ?: 0f) < 0.15f
        return lostTheSlide // the camera stopped following us: a popup, a pause, a death screen
    }

    override fun onActionRefused() {
        planner.cancelLast()
    }

    private fun analyze(frame: Bitmap): Reading {
        val t0 = SystemClock.elapsedRealtime()
        val lines = ocr.read(frame)
        val t1 = SystemClock.elapsedRealtime()
        val blobs = findBlobs(frame)
        val t2 = SystemClock.elapsedRealtime()
        reads++
        if (reads <= 3 || reads % 25 == 0) {
            DebugLog.add("read #$reads: OCR ${t1 - t0}ms (${lines.size} lines), blobs ${t2 - t1}ms (${blobs.size})")
        }
        // what the bot actually reads, so a wrong decision can be traced to the text it saw
        if (reads <= 8 || reads % 10 == 0) {
            val seen = lines.take(14).joinToString(" | ") { "${it.text.take(22)}@${(it.cx * 100).toInt()},${(it.cy * 100).toInt()}" }
            DebugLog.add("TEXT #$reads: $seen")
        }
        return Reading(lines, blobs)
    }

    private fun findBlobs(frame: Bitmap): List<Blob> {
        val gw = 48
        val gh = (gw * frame.height.toFloat() / frame.width).roundToInt().coerceIn(16, 128)
        val small = FrameTools.shrink(frame, gw, gh)
        val px = IntArray(gw * gh)
        small.getPixels(px, 0, gw, 0, 0, gw, gh)
        if (small !== frame) small.recycle()
        return Blobs.find(px, gw, gh)
    }

    override fun close() {
        ocr.close()
    }
}
