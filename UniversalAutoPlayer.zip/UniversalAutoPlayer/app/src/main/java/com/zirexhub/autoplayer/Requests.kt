package com.zirexhub.autoplayer

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class BuiltRequest(
    val url: String,
    val headers: Map<String, String>,
    val body: String,
    val method: String = "POST",
)

/** Builds the HTTP request for each wire format and pulls the text out of the reply. Pure, no Android. */
object Requests {

    fun build(
        p: Provider,
        baseUrl: String,
        apiKey: String,
        model: String,
        system: String,
        userText: String,
        imageB64: String?,
    ): BuiltRequest {
        val base = baseUrl.trim().trimEnd('/')
        return when (p.protocol) {
            Protocol.ANTHROPIC -> anthropic(base, apiKey, model, system, userText, imageB64)
            Protocol.OPENAI -> openai(base, apiKey, model, system, userText, imageB64)
            Protocol.GEMINI -> gemini(base, apiKey, model, system, userText, imageB64)
        }
    }

    private fun anthropic(
        base: String, key: String, model: String, system: String, user: String, img: String?,
    ): BuiltRequest {
        val content = JSONArray()
        if (img != null) {
            content.put(
                JSONObject().put("type", "image").put(
                    "source",
                    JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", img),
                ),
            )
        }
        content.put(JSONObject().put("type", "text").put("text", user))
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 800)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val url = if (base.endsWith("/v1")) "$base/messages" else "$base/v1/messages"
        return BuiltRequest(
            url,
            mapOf(
                "content-type" to "application/json",
                "x-api-key" to key,
                "anthropic-version" to "2023-06-01",
            ),
            body.toString(),
        )
    }

    private fun openai(
        base: String, key: String, model: String, system: String, user: String, img: String?,
    ): BuiltRequest {
        val userContent = JSONArray().put(JSONObject().put("type", "text").put("text", user))
        if (img != null) {
            userContent.put(
                JSONObject().put("type", "image_url").put(
                    "image_url",
                    JSONObject().put("url", "data:image/jpeg;base64,$img"),
                ),
            )
        }
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system))
            .put(JSONObject().put("role", "user").put("content", userContent))
        // No max_tokens on purpose: newer OpenAI models reject it and the JSON reply is short anyway.
        val body = JSONObject().put("model", model).put("messages", messages)
        val url = if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
        val headers = LinkedHashMap<String, String>()
        headers["content-type"] = "application/json"
        if (key.isNotBlank()) headers["Authorization"] = "Bearer $key"
        return BuiltRequest(url, headers, body.toString())
    }

    private fun gemini(
        base: String, key: String, model: String, system: String, user: String, img: String?,
    ): BuiltRequest {
        val parts = JSONArray()
        if (img != null) {
            parts.put(
                JSONObject().put(
                    "inlineData",
                    JSONObject().put("mimeType", "image/jpeg").put("data", img),
                ),
            )
        }
        parts.put(JSONObject().put("text", user))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0.3))
        val m = model.trim().removePrefix("models/")
        return BuiltRequest(
            "$base/models/$m:generateContent",
            mapOf("content-type" to "application/json", "x-goog-api-key" to key),
            body.toString(),
        )
    }

    /** GET request that lists the models an account can use. */
    fun modelsRequest(p: Provider, baseUrl: String, apiKey: String): BuiltRequest {
        val base = baseUrl.trim().trimEnd('/')
        return when (p.protocol) {
            Protocol.GEMINI -> BuiltRequest("$base/models?pageSize=200", mapOf("x-goog-api-key" to apiKey), "", "GET")
            Protocol.ANTHROPIC -> BuiltRequest(
                if (base.endsWith("/v1")) "$base/models?limit=100" else "$base/v1/models?limit=100",
                mapOf("x-api-key" to apiKey, "anthropic-version" to "2023-06-01"),
                "",
                "GET",
            )
            Protocol.OPENAI -> BuiltRequest(
                "$base/models",
                if (apiKey.isNotBlank()) mapOf("Authorization" to "Bearer $apiKey") else emptyMap(),
                "",
                "GET",
            )
        }
    }

    private val NOT_CHAT = listOf(
        "embed", "tts", "whisper", "dall-e", "moderation", "transcribe", "realtime", "imagen", "veo", "audio",
    )

    /** Model IDs (newest-looking first) that can chat, from a models-list reply. */
    fun parseModels(protocol: Protocol, reply: String): List<String> {
        val root = JSONObject(reply)
        val out = ArrayList<String>()
        if (protocol == Protocol.GEMINI) {
            val arr = root.optJSONArray("models") ?: return out
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val name = o.optString("name").removePrefix("models/")
                val methods = o.optJSONArray("supportedGenerationMethods")
                var ok = methods == null
                if (methods != null) {
                    for (j in 0 until methods.length()) if (methods.opt(j) == "generateContent") ok = true
                }
                if (ok && name.isNotBlank()) out.add(name)
            }
        } else {
            val arr = root.optJSONArray("data") ?: return out
            for (i in 0 until arr.length()) {
                val id = arr.optJSONObject(i)?.optString("id") ?: continue
                if (id.isNotBlank()) out.add(id)
            }
        }
        return out.distinct().filter { id -> NOT_CHAT.none { it in id.lowercase() } }.sortedDescending()
    }

    /** Pulls the model's text out of a successful reply. */
    fun extractText(protocol: Protocol, reply: String): String {
        val root = JSONObject(reply)
        when (protocol) {
            Protocol.ANTHROPIC -> {
                val blocks = root.optJSONArray("content") ?: throw IOException("Empty reply")
                val sb = StringBuilder()
                for (i in 0 until blocks.length()) {
                    val b = blocks.optJSONObject(i) ?: continue
                    if (b.optString("type") == "text") sb.append(b.optString("text"))
                }
                return sb.toString()
            }
            Protocol.OPENAI -> {
                val choices = root.optJSONArray("choices")
                val msg = choices?.optJSONObject(0)?.optJSONObject("message")
                    ?: throw IOException("Empty reply: ${reply.take(120)}")
                val c = msg.opt("content")
                if (c is String) return c
                if (c is JSONArray) {
                    val sb = StringBuilder()
                    for (i in 0 until c.length()) {
                        val part = c.optJSONObject(i) ?: continue
                        sb.append(part.optString("text"))
                    }
                    return sb.toString()
                }
                throw IOException("Empty reply: ${reply.take(120)}")
            }
            Protocol.GEMINI -> {
                val cand = root.optJSONArray("candidates")?.optJSONObject(0)
                    ?: throw IOException("No answer (blocked or empty): ${reply.take(160)}")
                val parts = cand.optJSONObject("content")?.optJSONArray("parts")
                    ?: throw IOException("No answer (finish reason ${cand.optString("finishReason")})")
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val part = parts.optJSONObject(i) ?: continue
                    sb.append(part.optString("text"))
                }
                return sb.toString()
            }
        }
    }

    /** Best-effort readable message from an error body. */
    fun errorMessage(text: String): String = try {
        val t = text.trim()
        if (t.startsWith("[")) {
            JSONArray(t).getJSONObject(0).getJSONObject("error").getString("message")
        } else {
            val o = JSONObject(t)
            val e = o.opt("error")
            when {
                e is JSONObject -> e.optString("message").ifBlank { t.take(160) }
                e is String -> e
                else -> o.optString("message").ifBlank { t.take(160) }
            }
        }
    } catch (_: Exception) {
        text.take(160)
    }
}
