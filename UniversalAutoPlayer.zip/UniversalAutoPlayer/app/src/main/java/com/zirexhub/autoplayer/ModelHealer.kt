package com.zirexhub.autoplayer

/**
 * AI companies retire and rename models all the time ("gemini-2.5-flash is no longer available").
 * Given the model that failed, the models this account can use, and the provider's complaint, this
 * ranks the best replacements: first any model the complaint names, then the newest model of the same
 * family ("gemini" + "flash"), stable versions before previews. Pure Kotlin, no Android.
 */
object ModelHealer {

    /** Words that mark models that cannot play a game from screenshots (speech, image generation...). */
    private val SKIP = setOf("tts", "audio", "live", "embed", "embedding", "image", "images", "imagen", "veo", "whisper")

    private val HINT = Regex("models/([A-Za-z0-9._\\-]+)")
    private val SPLIT = Regex("[^A-Za-z0-9]+")
    private val DIGITS = Regex("[0-9]+")

    /** Family words of a model ID: letters-only words, "gemini-2.5-flash-lite" -> [gemini, flash, lite]. */
    fun tokens(id: String): List<String> =
        id.lowercase().split(SPLIT).filter { it.length >= 2 && it.none { c -> c.isDigit() } && it != "models" }

    /** The first two numbers of the ID, "gemini-3.8-flash" -> [3, 8]. */
    private fun version(id: String): List<Int> =
        DIGITS.findAll(id).take(2).map { it.value.take(9).toInt() }.toList()

    private fun compareVersion(a: List<Int>, b: List<Int>): Int {
        val n = maxOf(a.size, b.size)
        for (i in 0 until n) {
            val x = a.getOrElse(i) { -1 }
            val y = b.getOrElse(i) { -1 }
            if (x != y) return x.compareTo(y)
        }
        return 0
    }

    private fun isPreview(id: String): Boolean {
        val low = id.lowercase()
        return "preview" in low || "-exp" in low || "experimental" in low
    }

    /** Stable before preview, newer before older, shorter (no date suffix) before longer. */
    private val ORDER = Comparator<String> { a, b ->
        val pa = isPreview(a)
        val pb = isPreview(b)
        if (pa != pb) return@Comparator if (pa) 1 else -1
        val c = compareVersion(version(b), version(a))
        if (c != 0) return@Comparator c
        a.length.compareTo(b.length)
    }

    /**
     * Candidates best first, never the failing [current] model itself. Empty if nothing sensible is found,
     * in which case the app asks the user to pick from the list instead of guessing.
     */
    fun rank(current: String, available: List<String>, errorText: String): List<String> {
        val out = LinkedHashSet<String>()
        val byLower = HashMap<String, String>()
        for (id in available) byLower[id.lowercase()] = id

        // 1. The provider often says it outright: "please use models/gemini-3.8-flash".
        for (m in HINT.findAll(errorText)) {
            val id = m.groupValues[1].trimEnd('.', ',', ')', '-')
            val real = byLower[id.lowercase()] ?: continue
            if (!real.equals(current, ignoreCase = true)) out.add(real)
        }

        // 2. Same family, then models that contain the family plus extras (like "-lite").
        val want = tokens(current)
        if (want.isNotEmpty()) {
            val wantSet = want.toSet()
            val usable = available.filter { id ->
                !id.equals(current, ignoreCase = true) && tokens(id).none { it in SKIP }
            }
            out.addAll(usable.filter { tokens(it).toSet() == wantSet }.sortedWith(ORDER))
            out.addAll(usable.filter { tokens(it).toSet().containsAll(wantSet) }.sortedWith(ORDER))
        }
        return out.toList()
    }
}
