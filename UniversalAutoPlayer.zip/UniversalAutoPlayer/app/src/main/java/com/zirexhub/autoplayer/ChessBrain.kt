package com.zirexhub.autoplayer

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs

/**
 * Chess with no AI and no internet, for both modes (see [ChessAuto] for how it sees and thinks).
 *
 * It sits in front of another brain ([inner]: the offline bot in offline mode, the AI hybrid in AI mode). Every step it looks for
 * an 8x8 board; when it can follow a chess game it decides the step itself (a move, or waiting for the opponent) and the inner
 * brain is not asked at all, so the offline bot never pokes at a board screen and no AI call is made. In every other case
 * (another game, a menu, a game that was already under way when PLAY was pressed, a finished game with a "new game" button)
 * the step goes to the inner brain as before. When the screen shows the starting position again, a new game is followed.
 */
class ChessBrain(val inner: Brain) : Brain {

    private val clock = { SystemClock.elapsedRealtime() }
    private val auto = ChessAuto(clock) { DebugLog.add(it) }
    private val board = BoardTracker(clock) { DebugLog.add(it) }

    /** Set by the service: the bot's own chip covers part of the board; it is moved away (true = it was moved). */
    @Volatile var onBoardCovered: ((Zone) -> Boolean)? = null

    private var prevBoard: Gray? = null
    private var noBoardUntil = Long.MIN_VALUE / 2
    private var boardSeenAt = Long.MIN_VALUE / 2
    private var chipMovedAt = Long.MIN_VALUE / 2
    private var lastFromInner = true
    private var announced = false

    override fun decide(frame: Bitmap, ctx: AgentContext): Decision {
        val mine = try {
            chessStep(frame, ctx)
        } catch (t: Throwable) {
            DebugLog.add("offline chess failed (${t.javaClass.simpleName}: ${t.message?.take(100)}): the other brain plays this step")
            null
        }
        if (mine != null) {
            lastFromInner = false
            return mine
        }
        lastFromInner = true
        return inner.decide(frame, ctx)
    }

    private fun chessStep(frame: Bitmap, ctx: AgentContext): Decision? {
        val now = clock()
        if (!auto.ready && now < noBoardUntil) return null
        val boardGray = FrameTools.gray(frame, BOARD_W, BOARD_H)
        val found = try {
            GridFinder.find(boardGray, ctx.blocked)
        } catch (_: Throwable) {
            null
        }
        val grid = board.gridFor(found, FrameTools.thumb(frame))
        if (grid == null || grid.cols != 8 || grid.rows != 8) {
            prevBoard = null
            if (auto.ready && now - boardSeenAt > BOARD_GONE_MS) {
                DebugLog.add("offline chess: no board for a while, the game is forgotten")
                auto.reset()
            }
            noBoardUntil = now + NO_BOARD_RECHECK_MS
            return null
        }
        boardSeenAt = now

        // the bot's own chip over the board: move it away, and do not judge the squares under it meanwhile
        val covered = BooleanArray(64)
        var anyCovered = false
        for (r in 0 until 8) for (c in 0 until 8) {
            val l = grid.l + (grid.r - grid.l) * c / 8f
            val rr = grid.l + (grid.r - grid.l) * (c + 1) / 8f
            val t = grid.t + (grid.b - grid.t) * r / 8f
            val b = grid.t + (grid.b - grid.t) * (r + 1) / 8f
            if (ctx.blocked.any { it.intersects(l, t, rr, b) }) {
                covered[r * 8 + c] = true
                anyCovered = true
            }
        }
        val cover = onBoardCovered
        if (anyCovered && cover != null && now - chipMovedAt > CHIP_RETRY_MS) {
            chipMovedAt = now
            val moved = try {
                cover(Zone(grid.l, grid.t, grid.r, grid.b))
            } catch (_: Throwable) {
                false
            }
            if (moved) {
                DebugLog.add("my chip covered part of the board: moved it off the board, looking again")
                prevBoard = null
                return Decision(GameAction.Wait(500L), "offline chess: moving my chip off the board", "wait(500ms)")
            }
        }

        val img = FrameTools.boardImage(frame, grid, CELL)
        val before = prevBoard
        prevBoard = img
        val settled = before != null && still(before, img)

        return when (val out = auto.step(img, grid, settled, if (anyCovered) covered else null)) {
            is ChessAuto.Out.Play -> {
                if (!announced) {
                    announced = true
                    DebugLog.add("offline chess: following a chess game without the AI")
                }
                Decision(out.actions, out.note, out.label, verifyTap = true)
            }
            is ChessAuto.Out.Hold -> Decision(GameAction.Wait(HOLD_MS), "offline chess: ${out.why}", "wait(${HOLD_MS}ms)")
            is ChessAuto.Out.Over -> {
                DebugLog.add("offline chess: ${out.why}")
                null
            }
            is ChessAuto.Out.Lost -> {
                DebugLog.add("offline chess: lost the game (${out.why}); the other brain plays until a new game starts")
                null
            }
            ChessAuto.Out.NotReady -> {
                noBoardUntil = now + NOT_READY_RECHECK_MS
                null
            }
        }
    }

    /** Two pictures of the same board: almost no pixel changed (a piece sliding across changes hundreds). */
    private fun still(a: Gray, b: Gray): Boolean {
        if (a.w != b.w || a.h != b.h) return false
        var n = 0
        for (i in a.px.indices) if (abs(a.px[i] - b.px[i]) > PIXEL_CHANGE) n++
        return n <= a.px.size * STILL_SHARE
    }

    override fun onActionRefused() {
        if (lastFromInner) {
            inner.onActionRefused()
        } else {
            auto.cancelSent()
        }
    }

    override fun close() {
        inner.close()
    }

    private companion object {
        const val BOARD_W = 180
        const val BOARD_H = 420
        const val CELL = 24
        const val HOLD_MS = 350L
        const val PIXEL_CHANGE = 16
        const val STILL_SHARE = 0.002f
        const val BOARD_GONE_MS = 20_000L
        const val NO_BOARD_RECHECK_MS = 1_200L
        const val NOT_READY_RECHECK_MS = 700L
        const val CHIP_RETRY_MS = 15_000L
    }
}
