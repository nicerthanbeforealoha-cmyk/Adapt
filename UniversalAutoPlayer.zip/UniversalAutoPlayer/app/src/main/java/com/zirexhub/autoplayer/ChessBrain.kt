package com.zirexhub.autoplayer

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs

/**
 * Chess with no AI and no internet, for both modes (see [ChessAuto] for how it sees and thinks).
 *
 * It sits in front of another brain ([inner]: the offline bot in offline mode, the AI hybrid in AI mode). Every step it looks for
 * an 8x8 board; when it can follow a chess game it decides the step itself (a move, or waiting for the opponent) and the inner
 * brain is not asked at all, so the offline bot never pokes at a board screen and no AI call is made. In every other case
 * (another game, a menu, a game that was already under way when PLAY was pressed, a finished game with a "new game" button)
 * the step goes to the inner brain as before. When the screen shows the starting position again, a new game is followed.
 *
 * [holdBoard] (offline mode): while a chess game is under way the inner brain is NEVER given the screen, even when the picture
 * cannot be read for a while (a promotion box, an ad, a toast). The offline bot presses buttons such as RESTART, and in a real
 * game it did exactly that in the middle of a promotion. It only gets the screen back when the game is over by the rules, or
 * when nothing was readable for a long time.
 */
class ChessBrain(val inner: Brain, private val holdBoard: Boolean = false) : Brain {

    private val clock = { SystemClock.elapsedRealtime() }
    private val auto = ChessAuto(clock) { DebugLog.add(it) }
    private val board = BoardTracker(clock) { DebugLog.add(it) }
    private var ocr: TextReader? = null

    /** Set by the service: the bot's own chip covers part of the board; it is moved away (true = it was moved). */
    @Volatile var onBoardCovered: ((Zone) -> Boolean)? = null

    private var prevBoard: Gray? = null
    private var noBoardUntil = Long.MIN_VALUE / 2
    private var boardSeenAt = Long.MIN_VALUE / 2
    private var chipMovedAt = Long.MIN_VALUE / 2
    private var lastFromInner = true
    private var lastWasPromote = false
    private var announced = false
    private var guardUntil = Long.MIN_VALUE / 2
    private var boardNow = false
    private var promoBefore: Gray? = null
    private val promoTried = HashSet<String>()

    override fun decide(frame: Bitmap, ctx: AgentContext): Decision {
        val mine = try {
            chessStep(frame, ctx)
        } catch (t: Throwable) {
            DebugLog.add("offline chess failed (${t.javaClass.simpleName}: ${t.message?.take(100)}): the other brain plays this step")
            null
        }
        if (mine != null) {
            lastFromInner = false
            return mine
        }
        // a game that could not be read for a moment: wait, do not let the offline bot press RESTART
        if (holdBoard && boardNow && clock() < guardUntil) {
            lastFromInner = false
            lastWasPromote = true // a refusal of this wait changes nothing
            return Decision(GameAction.Wait(HOLD_MS * 2), "offline chess: the picture cannot be read, waiting (touching nothing)", "wait(${HOLD_MS * 2}ms)")
        }
        lastFromInner = true
        return inner.decide(frame, ctx)
    }

    private fun chessStep(frame: Bitmap, ctx: AgentContext): Decision? {
        val now = clock()
        boardNow = false
        if (!auto.ready && now < noBoardUntil) return null
        val boardGray = FrameTools.gray(frame, BOARD_W, BOARD_H)
        val found = try {
            GridFinder.find(boardGray, ctx.blocked)
        } catch (_: Throwable) {
            null
        }
        val grid = board.gridFor(found, FrameTools.thumb(frame))
        if (grid == null || grid.cols != 8 || grid.rows != 8) {
            prevBoard = null
            if (auto.ready) {
                if (now - boardSeenAt > BOARD_GONE_MS) {
                    DebugLog.add("offline chess: no board for a while, the game is forgotten")
                    auto.reset()
                } else if (holdBoard) {
                    // a box over the board (a promotion choice, an ad): wait, touch nothing, it comes back
                    lastWasPromote = true
                    return Decision(GameAction.Wait(HOLD_MS * 2), "offline chess: the board is hidden, waiting (touching nothing)", "wait(${HOLD_MS * 2}ms)")
                }
            }
            noBoardUntil = now + NO_BOARD_RECHECK_MS
            return null
        }
        boardSeenAt = now
        boardNow = true

        // the bot's own chip over the board: move it away, and do not judge the squares under it meanwhile
        val covered = BooleanArray(64)
        var anyCovered = false
        for (r in 0 until 8) for (c in 0 until 8) {
            val l = grid.l + (grid.r - grid.l) * c / 8f
            val rr = grid.l + (grid.r - grid.l) * (c + 1) / 8f
            val t = grid.t + (grid.b - grid.t) * r / 8f
            val b = grid.t + (grid.b - grid.t) * (r + 1) / 8f
            if (ctx.blocked.any { it.intersects(l, t, rr, b) }) {
                covered[r * 8 + c] = true
                anyCovered = true
            }
        }
        val cover = onBoardCovered
        if (anyCovered && cover != null && now - chipMovedAt > CHIP_RETRY_MS) {
            chipMovedAt = now
            val moved = try {
                cover(Zone(grid.l, grid.t, grid.r, grid.b))
            } catch (_: Throwable) {
                false
            }
            if (moved) {
                DebugLog.add("my chip covered part of the board: moved it off the board, looking again")
                prevBoard = null
                lastWasPromote = true
                return Decision(GameAction.Wait(500L), "offline chess: moving my chip off the board", "wait(500ms)")
            }
        }

        val img = FrameTools.boardImage(frame, grid, CELL)
        val before = prevBoard
        prevBoard = img
        val settled = before != null && still(before, img)

        lastWasPromote = false
        return when (val out = auto.step(img, grid, settled, if (anyCovered) covered else null)) {
            is ChessAuto.Out.Play -> {
                if (!announced) {
                    announced = true
                    DebugLog.add("offline chess: following a chess game without the AI")
                }
                if (out.promotion) {
                    // the screen before the press, to find the choice box that may open
                    promoBefore = boardGray
                    promoTried.clear()
                }
                Decision(out.actions, out.note, out.label, verifyTap = true)
            }
            is ChessAuto.Out.Promote -> {
                lastWasPromote = true
                promote(frame, boardGray, grid, out)
            }
            is ChessAuto.Out.Hold -> {
                lastWasPromote = true
                Decision(GameAction.Wait(HOLD_MS), "offline chess: ${out.why}", "wait(${HOLD_MS}ms)")
            }
            is ChessAuto.Out.Over -> {
                DebugLog.add("offline chess: ${out.why}")
                null
            }
            is ChessAuto.Out.Lost -> {
                DebugLog.add("offline chess: lost the game (${out.why})" + if (holdBoard) ": waiting ${GUARD_MS / 1000}s for a new game before the offline bot gets the screen" else "")
                guardUntil = now + GUARD_MS
                null
            }
            ChessAuto.Out.NotReady -> {
                noBoardUntil = now + NOT_READY_RECHECK_MS
                null
            }
        }
    }

    /**
     * Our pawn reached the last row and the app wants a piece. The queen is pressed, found in up to three ways, each tried once
     * before any is tried again: the target square (many apps list the queen there), a "Queen" text button (read by OCR), the first
     * icon of the box that opened (found by comparing the screen with the one before the move).
     */
    private fun promote(frame: Bitmap, boardGray: Gray, grid: Grid, out: ChessAuto.Out.Promote): Decision {
        val order = if (out.attempt <= 1) listOf("target", "text", "box") else listOf("text", "box", "target")
        var x = grid.cx(out.col)
        var y = grid.cy(out.row)
        var how = "target"
        var found = false
        for (way in order) {
            if (way in promoTried) continue
            promoTried.add(way)
            when (way) {
                "target" -> found = true
                "text" -> {
                    val line = try {
                        val reader = ocr ?: TextReader().also { ocr = it }
                        reader.read(frame).firstOrNull { l -> QUEEN_WORDS.any { l.text.lowercase().contains(it) } }
                    } catch (_: Throwable) {
                        null
                    }
                    if (line != null) {
                        x = line.cx
                        y = line.cy
                        found = true
                    }
                }
                "box" -> {
                    val spot = promoBefore?.let { PromoPopup.find(it, boardGray) }
                    if (spot != null) {
                        x = spot.x
                        y = spot.y
                        found = true
                    }
                }
            }
            if (found) {
                how = way
                break
            }
        }
        if (!found) promoTried.clear() // every way was tried: start again with the target square
        val f = { v: Float -> "%.2f".format(java.util.Locale.US, v) }
        DebugLog.add("offline chess: promotion, pressing the queen by $how (try ${out.attempt}) at ${f(x)},${f(y)}")
        val tap = GameAction.Tap(x, y, 1, "queen($how)", true)
        return Decision(listOf(tap), "offline chess: promotion, choosing the queen ($how)", tap.label, verifyTap = false)
    }

    /** Two pictures of the same board: almost no pixel changed (a piece sliding across changes hundreds). */
    private fun still(a: Gray, b: Gray): Boolean {
        if (a.w != b.w || a.h != b.h) return false
        var n = 0
        for (i in a.px.indices) if (abs(a.px[i] - b.px[i]) > PIXEL_CHANGE) n++
        return n <= a.px.size * STILL_SHARE
    }

    override fun onActionRefused() {
        if (lastFromInner) {
            inner.onActionRefused()
        } else if (!lastWasPromote) {
            auto.cancelSent()
        }
    }

    override fun close() {
        try {
            ocr?.close()
        } catch (_: Throwable) {
        }
        inner.close()
    }

    private companion object {
        const val BOARD_W = 180
        const val BOARD_H = 420
        const val CELL = 24
        const val HOLD_MS = 350L
        const val PIXEL_CHANGE = 16
        const val STILL_SHARE = 0.002f
        const val BOARD_GONE_MS = 30_000L
        const val NO_BOARD_RECHECK_MS = 1_200L
        const val NOT_READY_RECHECK_MS = 700L
        const val CHIP_RETRY_MS = 15_000L
        const val GUARD_MS = 45_000L
        val QUEEN_WORDS = listOf("queen", "dame", "reina", "regina", "dama", "donna", "rainha", "königin", "koenigin")
    }
}
