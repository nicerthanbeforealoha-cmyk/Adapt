package com.zirexhub.autoplayer

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * A tiny on-device log so "it stopped and I do not know why" can be answered. It survives crashes
 * because every line is appended to a file. View it with "Show debug log" in the app.
 */
object DebugLog {
    private const val MAX_BYTES = 96 * 1024

    private var file: File? = null
    private val ring = ArrayList<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun init(c: Context) {
        if (file == null) file = File(c.applicationContext.filesDir, "zirex-debug.log")
    }

    @Synchronized
    fun add(msg: String) {
        val line = fmt.format(Date()) + " " + msg.replace('\n', ' ').take(400)
        ring.add(line)
        while (ring.size > 300) ring.removeAt(0)
        val f = file ?: return
        try {
            if (f.length() > MAX_BYTES) f.writeText(ring.takeLast(150).joinToString("\n") + "\n")
            f.appendText(line + "\n")
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun dump(maxLines: Int = 150): String {
        val f = file
        val lines: List<String> = try {
            if (f != null && f.exists()) f.readLines() else ring.toList()
        } catch (_: Exception) {
            ring.toList()
        }
        return lines.takeLast(maxLines).joinToString("\n").ifBlank { "(log is empty)" }
    }

    @Synchronized
    fun clear() {
        ring.clear()
        try {
            file?.writeText("")
        } catch (_: Exception) {
        }
    }
}
