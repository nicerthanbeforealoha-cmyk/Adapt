plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zirexhub.autoplayer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.zirexhub.autoplayer"
        // API 30 is the first version where an AccessibilityService can take screenshots.
        minSdk = 30
        targetSdk = 34
        versionCode = 10
        versionName = "2.8"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // On-device OCR (bundled model, works offline). This is how the offline bot reads the screen.
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
}
