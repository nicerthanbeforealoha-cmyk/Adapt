plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zirexhub.autoplayer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.zirexhub.autoplayer"
        // API 30 is the first version where an AccessibilityService can take screenshots.
        minSdk = 30
        targetSdk = 34
        versionCode = 11
        versionName = "2.9"
    }

    // The same signature on every build. GitHub's servers otherwise make a NEW random debug key on every run, and Android
    // then refuses to update the installed app ("App not installed" / "conflicts with an existing package").
    // The key is a plain debug key (password "android"), only used to sign this debug APK.
    val fixedKey = file("debug-signing.p12")
    if (fixedKey.exists()) {
        signingConfigs.getByName("debug") {
            storeFile = fixedKey
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
            storeType = "pkcs12"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // On-device OCR (bundled model, works offline). This is how the offline bot reads the screen.
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
}
